plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jhatpat.downloader"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jhatpat.downloader"
        minSdk = 24
        targetSdk = 34
        versionCode = 41
        versionName = "6.0"
    }

    signingConfigs {
        create("jhatpat") {
            storeFile = file("jhatpat.jks")
            storePassword = "jhatpat123"
            keyAlias = "jhatpat"
            keyPassword = "jhatpat123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("jhatpat")
        }
        debug {
            signingConfig = signingConfigs.getByName("jhatpat")
        }
    }

    // Har phone ke liye alag chhota APK (arm64 = naye phone, armeabi-v7a = purane phone)
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Download engine (yt-dlp) + FFmpeg - YouTube aur 1000+ sites support
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
