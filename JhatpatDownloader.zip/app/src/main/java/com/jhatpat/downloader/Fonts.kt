package com.jhatpat.downloader

import android.graphics.Typeface
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

data class AppFont(val key: String, val name: String, val family: String?)

/** Poore app ka text font badalne ka system (bina font file ke, Android ke built-in fonts) */
object Fonts {
    val all = listOf(
        AppFont("default", "Default", null),
        AppFont("serif", "Serif", "serif"),
        AppFont("mono", "Monospace", "monospace"),
        AppFont("condensed", "Condensed", "sans-serif-condensed"),
        AppFont("medium", "Medium", "sans-serif-medium"),
        AppFont("black", "Bold Black", "sans-serif-black"),
        AppFont("light", "Light", "sans-serif-light")
    )

    private fun base(): Typeface? {
        val fam = all.firstOrNull { it.key == Prefs.font }?.family ?: return null
        return try { Typeface.create(fam, Typeface.NORMAL) } catch (e: Exception) { null }
    }

    /** Screen ke saare TextViews par chuna hua font laga do (bold/italic bachakar) */
    fun apply(root: View?) {
        val tf = base() ?: return
        walk(root, tf)
    }

    private fun walk(v: View?, tf: Typeface) {
        if (v == null) return
        if (v is TextView) {
            val style = v.typeface?.style ?: Typeface.NORMAL
            try { v.typeface = Typeface.create(tf, style) } catch (_: Exception) { }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i), tf)
    }
}
