package com.jhatpat.downloader

import android.os.Bundle
import android.view.View
import android.widget.EditText

/** Sign in (naam + mobile/email) - phone me hi save hota hai */
class SignInActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)
        val etName = findViewById<EditText>(R.id.etName)
        val etContact = findViewById<EditText>(R.id.etContact)
        etName.setText(Prefs.userName)
        etContact.setText(Prefs.userContact)
        findViewById<View>(R.id.btnClose).setOnClickListener { finish() }
        findViewById<View>(R.id.btnSignIn).setOnClickListener {
            val n = etName.text.toString().trim()
            val c = etContact.text.toString().trim()
            if (n.length < 2) { etName.error = Lang.t("name"); return@setOnClickListener }
            if (c.length < 5) { etContact.error = Lang.t("mobile"); return@setOnClickListener }
            Prefs.userName = n
            Prefs.userContact = c
            Util.toast(this, "${Lang.t("welcome")}, $n!")
            finish()
        }
    }
}
