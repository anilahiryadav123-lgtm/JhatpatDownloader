package com.jhatpat.downloader

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList

class DTask(
    val id: String,
    var title: String,
    var url: String,
    var thumb: String?,
    var kind: String,          // video | audio
    var label: String,         // 720p / MP3
    var format: String,
    var audioConv: String?,
    var status: String = QUEUED,
    var progress: Float = 0f,
    var eta: Long = 0,
    var speed: String = "",
    var size: Long = 0,
    var fileUri: String? = null,
    var filePath: String? = null,
    var mime: String? = null,
    var error: String? = null,
    val created: Long = System.currentTimeMillis(),
    var bitrate: String? = null,
    var fileName: String? = null,
    var hidden: Boolean = false
) {
    val isActive get() = status == QUEUED || status == RUNNING
    /** App band hone se ruka tha (auto resume ke liye) */
    var interrupted = false

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("title", title); put("url", url); put("thumb", thumb ?: "")
        put("kind", kind); put("label", label); put("format", format); put("audioConv", audioConv ?: "")
        put("status", status); put("progress", progress.toDouble()); put("size", size)
        put("fileUri", fileUri ?: ""); put("filePath", filePath ?: ""); put("mime", mime ?: "")
        put("error", error ?: ""); put("created", created)
        put("bitrate", bitrate ?: ""); put("fileName", fileName ?: ""); put("hidden", hidden)
    }

    companion object {
        const val QUEUED = "queued"
        const val RUNNING = "running"
        const val PAUSED = "paused"
        const val DONE = "done"
        const val FAILED = "failed"

        fun fromJson(o: JSONObject): DTask {
            fun s(k: String) = o.optString(k, "").ifBlank { null }
            return DTask(
                id = o.getString("id"), title = o.optString("title"), url = o.optString("url"),
                thumb = s("thumb"), kind = o.optString("kind", "video"), label = o.optString("label"),
                format = o.optString("format", "b"), audioConv = s("audioConv"),
                status = o.optString("status", PAUSED), progress = o.optDouble("progress", 0.0).toFloat(),
                size = o.optLong("size", 0), fileUri = s("fileUri"), filePath = s("filePath"),
                mime = s("mime"), error = s("error"), created = o.optLong("created", System.currentTimeMillis()),
                bitrate = s("bitrate"), fileName = s("fileName"), hidden = o.optBoolean("hidden", false)
            )
        }
    }
}

/** Saare downloads ki list (phone me save rehti hai) */
object DownloadRepo {
    private lateinit var prefs: SharedPreferences
    private val tasks = CopyOnWriteArrayList<DTask>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()
    private val main = Handler(Looper.getMainLooper())
    private var notifyPosted = false

    fun init(ctx: Context) {
        prefs = ctx.getSharedPreferences("jp_downloads", Context.MODE_PRIVATE)
        try {
            val arr = JSONArray(prefs.getString("list", "[]"))
            for (i in 0 until arr.length()) {
                val t = DTask.fromJson(arr.getJSONObject(i))
                // App band hua tha to chal rahe downloads "paused" ho jaate hain
                if (t.isActive) { t.status = DTask.PAUSED; t.interrupted = true }
                tasks.add(t)
            }
        } catch (_: Exception) { }
    }

    fun all(): List<DTask> = tasks.sortedByDescending { it.created }
    fun active(): List<DTask> = all().filter { it.status != DTask.DONE }
    fun done(): List<DTask> = all().filter { it.status == DTask.DONE && !it.hidden }
    fun hiddenList(): List<DTask> = all().filter { it.status == DTask.DONE && it.hidden }
    fun get(id: String): DTask? = tasks.firstOrNull { it.id == id }

    fun add(t: DTask) { tasks.add(t); save(); changed() }
    fun remove(id: String) { tasks.removeIf { it.id == id }; save(); changed() }

    fun save() {
        val arr = JSONArray()
        tasks.forEach { arr.put(it.toJson()) }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    fun addListener(l: () -> Unit) { listeners.add(l) }
    fun removeListener(l: () -> Unit) { listeners.remove(l) }

    /** UI ko batana ki list badli (throttled) */
    fun changed() {
        synchronized(this) {
            if (notifyPosted) return
            notifyPosted = true
        }
        main.postDelayed({
            synchronized(this) { notifyPosted = false }
            listeners.forEach { try { it() } catch (_: Exception) { } }
        }, 150)
    }
}
