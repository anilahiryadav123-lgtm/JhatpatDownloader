package com.jhatpat.downloader

import android.app.Notification
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class DownloadService : Service() {

    private val pool = Executors.newFixedThreadPool(3)
    private val running = ConcurrentHashMap<String, Boolean>()
    private val stopped = ConcurrentHashMap<String, String>() // id -> reason (pause/cancel)
    private var lastNotify = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        val id = intent?.getStringExtra("id")
        when (intent?.action) {
            ACT_START -> if (id != null) launch(id)
            ACT_PAUSE -> if (id != null) stopTask(id, "pause")
            ACT_CANCEL -> if (id != null) stopTask(id, "cancel")
        }
        checkStop()
        return START_NOT_STICKY
    }

    private fun startFg() {
        val n = buildProgressNotif()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC else 0
        try { ServiceCompat.startForeground(this, NOTIF_ID, n, type) } catch (_: Exception) { }
    }

    private fun maxParallel(): Int = Prefs.maxTasks.coerceIn(1, 5)

    private fun launch(id: String) {
        val t = DownloadRepo.get(id) ?: return
        if (running.containsKey(id)) return
        t.status = DTask.QUEUED; t.error = null
        DownloadRepo.save(); DownloadRepo.changed()
        pump()
    }

    @Synchronized
    private fun pump() {
        val slots = maxParallel() - running.size
        if (slots <= 0) return
        DownloadRepo.all().reversed().filter { it.status == DTask.QUEUED && !running.containsKey(it.id) }
            .take(slots).forEach { t ->
                running[t.id] = true
                stopped.remove(t.id)
                pool.execute { run(t) }
            }
    }

    private fun tmpDir(id: String): File {
        val base = getExternalFilesDir(null) ?: filesDir
        return File(base, "tmp/$id")
    }

    private fun run(t: DTask) {
        t.status = DTask.RUNNING; DownloadRepo.changed()
        try {
            if (Prefs.wifiOnly && !Util.isWifi(this)) {
                stopped[t.id] = "pause"
                t.error = "WiFi ka intezaar (Settings → Download Only in WiFi)"
                throw RuntimeException("wifi")
            }
            if (!Engine.ensureInit(this)) throw RuntimeException("Engine error: ${Engine.initError}")
            val dir = tmpDir(t.id).apply { mkdirs() }
            val req = YoutubeDLRequest(t.url)
            req.addOption("--no-playlist")
            req.addOption("--no-mtime")
            req.addOption("--newline")
            req.addOption("--socket-timeout", "30")
            req.addOption("--retries", "10")
            req.addOption("--fragment-retries", "10")
            Engine.applyAntiBot(req, this, t.url)
            if (Prefs.fastDownload) {
                // ⚡ Fast mode: 16 tukdon me ek saath download + YouTube throttle se bachav
                req.addOption("--concurrent-fragments", "16")
                req.addOption("--http-chunk-size", "10M")
                req.addOption("--buffer-size", "1M")
                req.addOption("--throttled-rate", "100K")
            } else {
                req.addOption("--concurrent-fragments", "1")
            }
            val custom = t.fileName?.replace(Regex("[\\\\/:*?\"<>|%]"), "_")?.trim()?.take(120)
            req.addOption("-o", dir.absolutePath + "/" + (if (custom.isNullOrBlank()) "%(title).80s [%(id)s]" else custom) + ".%(ext)s")
            if (t.kind == "audio") {
                req.addOption("-f", t.format)
                req.addOption("-x")
                req.addOption("--audio-format", t.audioConv ?: "mp3")
                req.addOption("--audio-quality", t.bitrate ?: when (Prefs.musicQuality) { "low" -> "128K"; "high" -> "320K"; else -> "192K" })
            } else {
                req.addOption("-f", t.format)
                // Top resolution par h264/mp4 ko prefer karo (best quality + har phone me chale, AV1 ki dikkat nahi)
                req.addOption("-S", "res,vcodec:h264,ext:mp4:m4a,acodec:m4a")
                req.addOption("--merge-output-format", "mp4")
                val sub = when (Prefs.subtitle) {
                    "system" -> java.util.Locale.getDefault().language
                    "en", "hi" -> Prefs.subtitle
                    else -> ""
                }
                if (sub.isNotEmpty()) {
                    req.addOption("--write-subs")
                    req.addOption("--write-auto-subs")
                    req.addOption("--sub-langs", "$sub.*,$sub")
                    req.addOption("--embed-subs")
                }
            }
            val speedRx = Regex("at\\s+~?\\s*([\\d.]+\\s*[KMG]?i?B/s)")
            val sizeRx = Regex("of\\s+~?\\s*([\\d.]+\\s*[KMG]?i?B)")
            YoutubeDL.getInstance().execute(req, t.id) { progress, eta, line ->
                if (progress > 0) t.progress = progress
                t.eta = eta
                speedRx.find(line)?.let { t.speed = it.groupValues[1] }
                sizeRx.find(line)?.let { t.error = null; sizeText[t.id] = it.groupValues[1] }
                DownloadRepo.changed()
                notifyProgress()
            }
            // Final file dhundho
            val f = dir.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") && !it.name.contains(".temp") && !it.name.endsWith(".json") && !it.name.endsWith(".vtt") && !it.name.endsWith(".srt") }
                ?.maxByOrNull { it.length() }
                ?: throw RuntimeException("File nahi bani")
            t.size = f.length()
            t.mime = Util.mimeOf(f.name)
            try {
                val (uri, path) = Util.publish(this, f)
                t.fileUri = uri; t.filePath = path
            } catch (e: Exception) {
                // Gallery me save fail -> app folder me hi rakh do
                t.fileUri = android.net.Uri.fromFile(f).toString(); t.filePath = f.absolutePath
            }
            dir.listFiles()?.forEach { if (it.absolutePath != t.filePath) it.delete() }
            if (t.filePath?.startsWith(dir.absolutePath) != true) dir.delete()
            t.status = DTask.DONE; t.progress = 100f; t.speed = ""; t.error = null
            if (Prefs.notifyDone) notifyDone(t)
        } catch (e: Throwable) {
            val reason = stopped[t.id]
            when (reason) {
                "pause" -> { t.status = DTask.PAUSED; t.interrupted = false }
                "cancel" -> { t.status = DTask.FAILED; tmpDir(t.id).deleteRecursively() }
                else -> {
                    t.status = DTask.FAILED
                    t.error = cleanError(e.message ?: e.toString())
                }
            }
            t.speed = ""
        } finally {
            running.remove(t.id)
            if (stopped[t.id] == "cancel") DownloadRepo.remove(t.id)
            stopped.remove(t.id)
            DownloadRepo.save(); DownloadRepo.changed()
            pump()
            checkStop()
        }
    }

    private fun cleanError(msg: String): String {
        val line = msg.lines().lastOrNull { it.contains("ERROR") } ?: msg.lines().firstOrNull { it.isNotBlank() } ?: msg
        return line.replace("ERROR:", "").trim().take(200)
    }

    private fun stopTask(id: String, reason: String) {
        val t = DownloadRepo.get(id) ?: return
        if (running.containsKey(id)) {
            stopped[id] = reason
            try { YoutubeDL.getInstance().destroyProcessById(id) } catch (_: Exception) { }
        } else {
            if (reason == "cancel") { tmpDir(id).deleteRecursively(); DownloadRepo.remove(id) }
            else { t.status = DTask.PAUSED; DownloadRepo.save(); DownloadRepo.changed() }
        }
    }

    private fun checkStop() {
        if (running.isEmpty() && DownloadRepo.all().none { it.status == DTask.QUEUED }) {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).putExtra("tab", "downloads")
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        return PendingIntent.getActivity(this, 1, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun buildProgressNotif(): Notification {
        val act = DownloadRepo.all().filter { it.status == DTask.RUNNING }
        val title = if (act.size <= 1) (act.firstOrNull()?.title ?: "Jhatpat Downloader") else "${act.size} downloads chal rahe hain"
        val p = if (act.isEmpty()) 0 else act.map { it.progress }.average().toInt()
        val speed = act.firstOrNull()?.speed ?: ""
        return NotificationCompat.Builder(this, App.CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle(title)
            .setContentText(if (act.isEmpty()) "Taiyar ho raha hai..." else "$p%  $speed")
            .setProgress(if (Prefs.notifyProgress) 100 else 0, p, act.isEmpty() && Prefs.notifyProgress)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setColor(0xFFFF7A00.toInt())
            .setContentIntent(openAppIntent())
            .build()
    }

    private fun notifyProgress() {
        val now = System.currentTimeMillis()
        if (now - lastNotify < 1000 || !Prefs.notifyProgress) return
        lastNotify = now
        try { getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildProgressNotif()) } catch (_: Exception) { }
    }

    private fun notifyDone(t: DTask) {
        val n = NotificationCompat.Builder(this, App.CH_DONE)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("Download complete ✓")
            .setContentText(t.title)
            .setAutoCancel(true)
            .setColor(0xFFFF7A00.toInt())
            .setContentIntent(openAppIntent())
            .build()
        try { getSystemService(NotificationManager::class.java).notify(t.id.hashCode(), n) } catch (_: Exception) { }
    }

    override fun onDestroy() {
        pool.shutdown()
        super.onDestroy()
    }

    companion object {
        const val NOTIF_ID = 4242
        const val ACT_START = "start"
        const val ACT_PAUSE = "pause"
        const val ACT_CANCEL = "cancel"
        val sizeText = ConcurrentHashMap<String, String>()

        private fun send(ctx: Context, action: String, id: String) {
            val i = Intent(ctx, DownloadService::class.java).setAction(action).putExtra("id", id)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun enqueue(ctx: Context, info: MediaInfo, opt: DlOption, customName: String? = null) {
            val t = DTask(
                id = "jp" + System.currentTimeMillis(),
                title = info.title, url = info.url, thumb = info.thumb,
                kind = opt.kind, label = opt.label + " " + opt.ext,
                format = opt.format, audioConv = opt.audioConv, size = opt.sizeBytes,
                bitrate = opt.bitrate, fileName = customName
            )
            if (!customName.isNullOrBlank()) t.title = customName
            DownloadRepo.add(t)
            send(ctx, ACT_START, t.id)
            Util.toast(ctx, "Download shuru: ${opt.label}")
        }

        fun resume(ctx: Context, id: String) = send(ctx, ACT_START, id)
        fun pause(ctx: Context, id: String) = send(ctx, ACT_PAUSE, id)
        fun cancel(ctx: Context, id: String) = send(ctx, ACT_CANCEL, id)
    }
}
