package com.jhatpat.downloader

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import java.util.Collections

class BrowserActivity : BaseActivity() {

    private lateinit var web: WebView
    private lateinit var etUrl: EditText
    private lateinit var pb: ProgressBar
    private lateinit var fab: ExtendedFloatingActionButton
    private lateinit var fullContainer: FrameLayout
    private lateinit var tvDlCount: TextView
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private val sniffed: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet())
    private var pulsing = false
    private var tabId = -1L
    private val dlListener: () -> Unit = { updateDlCount() }

    private val mediaRx = Regex("\\.(mp4|m3u8|webm|mkv|mov|mp3|m4a|3gp)(\\?|$)", RegexOption.IGNORE_CASE)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        web = findViewById(R.id.web)
        etUrl = findViewById(R.id.etUrl)
        pb = findViewById(R.id.pbLoad)
        fab = findViewById(R.id.fabDownload)
        fullContainer = findViewById(R.id.fullContainer)
        tvDlCount = findViewById(R.id.tvDlCount)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Bridge(), "JhatpatBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                if (Filter.blocked(u)) { showBlocked(); return true }
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                if (u.startsWith("intent://")) {
                    val fb = Regex("S\\.browser_fallback_url=([^;]+)").find(u)?.groupValues?.get(1)
                    if (fb != null) view.loadUrl(Uri.decode(fb))
                    return true
                }
                // Dusre apps wale links (vnd.youtube, whatsapp...) browser me hi rahein
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                if (Filter.blocked(url)) { view.stopLoading(); showBlocked(); return }
                sniffed.clear()
                setUrlText(url)
                updateFab(url)
                injectAdKiller(view, url)   // ad data jad se hatao (jaldi)
            }

            override fun onPageFinished(view: WebView, url: String) {
                setUrlText(url)
                Prefs.addHistory(view.title ?: url, url)
                Tabs.update(tabId, url, view.title)
                injectYouTubeButton()
                injectAdBlock()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                setUrlText(url)
                updateFab(url)
                injectYouTubeButton()
                injectAdBlock()
            }

            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url.toString()
                // Ads block: vigyapan wale server band (VidMate jaisa bina ads)
                if (isAd(u)) return WebResourceResponse("text/plain", "utf-8", java.io.ByteArrayInputStream(ByteArray(0)))
                if (!u.contains("googlevideo.com") && !u.contains("ytimg") && mediaRx.containsMatchIn(u)) {
                    if (sniffed.add(u)) runOnUiThread { updateFab(web.url ?: "") }
                }
                return null
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                pb.progress = p
                pb.visibility = if (p >= 100) View.GONE else View.VISIBLE
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view; customCallback = callback
                fullContainer.addView(view, FrameLayout.LayoutParams(-1, -1))
                fullContainer.visibility = View.VISIBLE
                fab.visibility = View.GONE
                setFullscreen(true)
            }

            override fun onHideCustomView() { exitFullscreen() }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                DownloadSheet(this).show(url, URLUtil.guessFileName(url, cd, mime))
            } else {
                try {
                    val name = URLUtil.guessFileName(url, cd, mime)
                    val r = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mime)
                        .addRequestHeader("User-Agent", ua)
                        .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "JhatpatDownloader/$name")
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                    Util.toast(this, "Download: $name")
                } catch (e: Exception) {
                    Util.toast(this, "Download nahi hua")
                }
            }
        }

        fab.setOnClickListener { startDownload() }
        setupDraggableFab()

        etUrl.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_GO) {
                load(etUrl.text.toString())
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(etUrl.windowToken, 0)
                etUrl.clearFocus()
                true
            } else false
        }
        findViewById<View>(R.id.btnRefresh).setOnClickListener { web.reload() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { v -> pageMenu(v) }
        fab.text = Lang.t("download")
        findViewById<View>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.btnHome).setOnClickListener { finish() }
        findViewById<View>(R.id.ivLogo).setOnClickListener { finish() }
        findViewById<View>(R.id.btnDls).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).putExtra("tab", "downloads")
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }
        findViewById<View>(R.id.btnMenuBottom).setOnClickListener { v -> pageMenu(v) }
        findViewById<View>(R.id.btnTabs).setOnClickListener {
            captureThumb()
            Tabs.update(tabId, web.url, web.title)
            startActivity(Intent(this, TabsActivity::class.java))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState)
            if (tabId < 0) tabId = Tabs.currentId
        } else initTab(intent)
        updateTabCount()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        initTab(intent)
        updateTabCount()
    }

    /** Tab khole: maujooda tab switch ho ya naya bane */
    private fun initTab(i: Intent) {
        val wantId = i.getLongExtra("tabId", -1L)
        val q = i.getStringExtra("q")
        if (wantId > 0 && Tabs.get(wantId) != null) {
            // Purana tab switch
            tabId = wantId
            Tabs.setCurrent(wantId)
            load(q ?: Tabs.get(wantId)!!.url)
        } else {
            // Naya tab
            val url = q ?: "https://www.google.com"
            tabId = Tabs.open(url)
            load(url)
        }
    }

    private fun updateTabCount() {
        findViewById<TextView>(R.id.tvTabCount)?.text = Tabs.count().coerceAtLeast(1).toString()
    }

    /** WebView ka chhota screenshot le lo (tab preview ke liye) */
    private fun captureThumb() {
        try {
            if (web.width <= 0 || web.height <= 0 || tabId < 0) return
            val scale = 0.4f
            val w = (web.width * scale).toInt().coerceAtLeast(1)
            val h = (web.height * scale).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565)
            val c = android.graphics.Canvas(bmp)
            c.scale(scale, scale)
            web.draw(c)
            Tabs.thumb(tabId, bmp)
        } catch (_: Throwable) { }
    }

    private fun load(q: String) {
        val t = q.trim()
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            Util.isUrl(t) -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t) + (if (Prefs.filterSearch) "&safe=active" else "")
        }
        if (Filter.blocked(url)) { showBlocked(); return }
        web.loadUrl(url)
    }

    private fun showBlocked() {
        val html = "<html><body style='font-family:sans-serif;text-align:center;padding:60px 20px;background:#fff;color:#333'>" +
            "<div style='font-size:64px'>🔒</div><h2>Restricted Mode</h2><p>Yeh website Jhatpat Downloader me block hai.</p>" +
            "<p style='color:#888'>Settings → Content → Restricted Mode</p></body></html>"
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null)
    }

    /** ⋮ menu: Subscribe (bookmark), Share, Copy link, Open in other browser */
    /** Tabs button — naya tab / home */
    private fun tabsMenu(v: View) {
        val pm = androidx.appcompat.widget.PopupMenu(this, v)
        pm.menu.add(0, 1, 0, "➕  New tab")
        pm.menu.add(0, 2, 0, "🏠  Home")
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", "https://www.google.com"))
                2 -> finish()
            }
            true
        }
        pm.show()
    }

    private fun pageMenu(v: View) {
        val url = web.url ?: return
        val pm = androidx.appcompat.widget.PopupMenu(this, v)
        pm.menu.add(0, 1, 0, if (Prefs.isBookmarked(url)) "★ Subscribed (hatayein)" else "☆ ${Lang.t("bookmarks")} / Bookmark")
        pm.menu.add(0, 2, 0, Lang.t("share"))
        pm.menu.add(0, 3, 0, "Copy link")
        pm.menu.add(0, 4, 0, "Open in Chrome / other browser")
        pm.menu.add(0, 5, 0, Lang.t("history"))
        pm.menu.add(0, 6, 0, Lang.t("download"))
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> Util.toast(this, if (Prefs.toggleBookmark(web.title ?: url, url)) "✓ Saved" else "Removed")
                2 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url), Lang.t("share")))
                3 -> {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                    Prefs.lastClip = url
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", url))
                    Util.toast(this, "Copied")
                }
                4 -> try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) { }
                5 -> startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", "history"))
                6 -> startDownload()
            }
            true
        }
        pm.show()
    }

    private fun setUrlText(url: String) {
        if (!etUrl.hasFocus()) etUrl.setText(url)
    }

    /** Download button ko ungli se kahin bhi (left/right, upar/neeche) khiska sakte hain */
    @SuppressLint("ClickableViewAccessibility")
    private fun setupDraggableFab() {
        // Pehle se save ki hui jagah lagao
        fab.post {
            val parent = fab.parent as? View ?: return@post
            val px = Prefs.fabX; val py = Prefs.fabY
            if (py >= 0) fab.y = py.toFloat().coerceIn(0f, (parent.height - fab.height).toFloat())
            if (px >= 0) fab.x = px.toFloat().coerceIn(0f, (parent.width - fab.width).toFloat())
        }
        var dX = 0f; var dY = 0f; var startX = 0f; var startY = 0f; var moved = false
        fab.setOnTouchListener { v, e ->
            val parent = v.parent as? View ?: return@setOnTouchListener false
            when (e.action) {
                android.view.MotionEvent.ACTION_DOWN -> {
                    dX = v.x - e.rawX; dY = v.y - e.rawY
                    startX = e.rawX; startY = e.rawY; moved = false
                    true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    val nx = (e.rawX + dX).coerceIn(0f, (parent.width - v.width).toFloat())
                    val ny = (e.rawY + dY).coerceIn(0f, (parent.height - v.height).toFloat())
                    v.x = nx; v.y = ny
                    if (kotlin.math.abs(e.rawX - startX) > 12 || kotlin.math.abs(e.rawY - startY) > 12) moved = true
                    true
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (!moved) { v.performClick() }
                    else {
                        // Paas wale kinare (left/right) par chipka do
                        val toLeft = v.x + v.width / 2 < parent.width / 2
                        val targetX = if (toLeft) dpF(16) else (parent.width - v.width - dpF(16))
                        v.animate().x(targetX).setDuration(150).start()
                        Prefs.fabX = targetX.toInt(); Prefs.fabY = v.y.toInt()
                    }
                    true
                }
                else -> false
            }
        }
    }

    private fun dpF(v: Int) = v * resources.displayMetrics.density

    private fun startDownload() {
        val url = web.url ?: return
        DownloadSheet(this).show(url, web.title, sniffed.toList().reversed())
    }

    /** Video wale page par Download button chamakta hai */
    private fun isVideoPage(url: String): Boolean {
        val u = url.lowercase()
        return (u.contains("youtube.com/watch") || u.contains("youtube.com/shorts/") || u.contains("youtu.be/") ||
            u.contains("instagram.com/reel") || u.contains("instagram.com/p/") || u.contains("instagram.com/tv/") ||
            u.contains("facebook.com/watch") || u.contains("/videos/") || u.contains("facebook.com/reel") || u.contains("fb.watch") ||
            (u.contains("x.com/") && u.contains("/status/")) || (u.contains("twitter.com/") && u.contains("/status/")) ||
            u.contains("dailymotion.com/video") || Regex("vimeo\\.com/\\d+").containsMatchIn(u) ||
            u.contains("sharechat.com/video") || u.contains("sharechat.com/post") || u.contains("mojapp.in/") && u.contains("video") ||
            u.contains("pinterest.") && u.contains("/pin/") || u.contains("reddit.com/r/") && u.contains("/comments/") ||
            u.contains("soundcloud.com/") && u.count { it == '/' } >= 4 || u.contains("twitch.tv/videos") || u.contains("clips.twitch.tv") ||
            u.contains("ted.com/talks/") || u.contains("bilibili.tv/") && u.contains("/video/")) || sniffed.isNotEmpty()
    }

    private fun updateFab(url: String) {
        if (customView != null) return
        if (isVideoPage(url)) {
            // Sirf video/media wale page par hi button dikhao (Vidmate jaisa)
            fab.visibility = View.VISIBLE
            fab.extend()
            fab.text = if (sniffed.isNotEmpty() && !url.contains("youtube")) "${Lang.t("download")} (${sniffed.size})" else Lang.t("download")
            startPulse()
        } else {
            // Google / search / normal page par download button nahi
            fab.visibility = View.GONE
            pulsing = false
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        fun beat() {
            if (!pulsing || isFinishing) { fab.scaleX = 1f; fab.scaleY = 1f; return }
            fab.animate().scaleX(1.08f).scaleY(1.08f).setDuration(450).setInterpolator(AccelerateDecelerateInterpolator())
                .withEndAction {
                    fab.animate().scaleX(1f).scaleY(1f).setDuration(450).withEndAction { fab.postDelayed({ beat() }, 600) }.start()
                }.start()
        }
        beat()
    }

    private val adHosts = listOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com", "google-analytics.com",
        "googletagservices.com", "googletagmanager.com", "adservice.google", "/pagead/", "/api/stats/ads",
        "/ptracking", "/get_midroll_", "innovid.com", "moatads.com", "adsafeprotected.com",
        "pubads", "securepubads", "amazon-adsystem.com", "adnxs.com", "/gen_204?", "youtube.com/api/stats/qoe",
        "youtube.com/pcs/activeview", "youtube.com/generate_204"
    )

    private fun isAd(u: String): Boolean {
        val l = u.lowercase()
        // YouTube ke apne video (googlevideo) kabhi block mat karo
        if (l.contains("googlevideo.com")) return false
        return adHosts.any { l.contains(it) }
    }

    /** YouTube ke ads: skip button auto-daba, ad jaldi aage badha, ad banner chhupa */
    /**
     * Asli YouTube ad-block: YouTube ki player response (JSON) se hi
     * adPlacements/playerAds/adSlots hata deta hai -> koi video ad aata hi nahi.
     * fetch aur XMLHttpRequest dono ko patch karte hain, page shuru hote hi.
     */
    private fun injectAdKiller(view: WebView, url: String) {
        if (!url.contains("youtube.com")) return
        val js = """
            (function(){
              if (window.__jpKill) return; window.__jpKill = true;
              function clean(t){
                try{
                  if(typeof t!=='string') return t;
                  if(t.indexOf('adPlacements')<0 && t.indexOf('playerAds')<0 && t.indexOf('adSlots')<0) return t;
                  var o=JSON.parse(t);
                  var strip=function(x){ if(x&&typeof x==='object'){ delete x.adPlacements; delete x.playerAds; delete x.adSlots; delete x.adBreakHeartbeatParams; for(var k in x){ strip(x[k]); } } };
                  strip(o); return JSON.stringify(o);
                }catch(e){ return t; }
              }
              var of=window.fetch;
              if(of){ window.fetch=function(){ return of.apply(this,arguments).then(function(r){
                 try{ var u=(r&&r.url)||''; if(u.indexOf('/youtubei/v1/player')>-1 || u.indexOf('/youtubei/v1/next')>-1){ return r.clone().text().then(function(tx){ return new Response(clean(tx), {status:r.status,statusText:r.statusText,headers:r.headers}); }); } }catch(e){} return r;
              }); }; }
              var oo=XMLHttpRequest.prototype.open, os=XMLHttpRequest.prototype.send;
              XMLHttpRequest.prototype.open=function(m,u){ this.__ju=u; return oo.apply(this,arguments); };
              XMLHttpRequest.prototype.send=function(){
                var xhr=this;
                if(xhr.__ju && (xhr.__ju.indexOf('/youtubei/v1/player')>-1 || xhr.__ju.indexOf('/youtubei/v1/next')>-1)){
                  var od=Object.getOwnPropertyDescriptor(XMLHttpRequest.prototype,'responseText');
                  xhr.addEventListener('readystatechange',function(){
                    if(xhr.readyState===4){
                      try{ var c=clean(xhr.responseText);
                        Object.defineProperty(xhr,'responseText',{get:function(){return c;}});
                        Object.defineProperty(xhr,'response',{get:function(){return c;}});
                      }catch(e){}
                    }
                  });
                }
                return os.apply(this,arguments);
              };
            })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun injectAdBlock() {
        val u = web.url ?: return
        if (!u.contains("youtube.com")) return
        val js = """
            (function(){
              if (window.__jpAd) return; window.__jpAd = true;
              var css = document.createElement('style');
              css.innerHTML = '.video-ads,.ytp-ad-module,.ytp-ad-overlay-container,.ytp-ad-player-overlay,.ytp-ad-player-overlay-layout,ytm-companion-slot,ytd-action-companion-ad-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-ad-slot-renderer,.ytp-ad-image-overlay,#player-ads,#masthead-ad,.ad-container,ytm-promoted-video-renderer,.companion-ad,.ytp-ad-overlay-slot{display:none!important;height:0!important}';
              document.documentElement.appendChild(css);
              function isAd(){
                try{
                  var p=document.querySelector('.html5-video-player,.ytp-ad-player-overlay,#movie_player');
                  if(p && p.classList && p.classList.contains('ad-showing')) return true;
                  if(document.querySelector('.ytp-ad-player-overlay, .ytp-ad-text, .ytp-ad-preview-container')) return true;
                  // mobile: "Sponsored" text
                  var s=document.querySelector('.ytp-ad-simple-ad-badge, .ytp-ad-badge, ytm-companion-slot-renderer');
                  if(s) return true;
                }catch(e){}
                return false;
              }
              function kill(){
                try{
                  var v=document.querySelector('video');
                  if(v && isAd()){
                    v.muted=true;
                    try{ v.playbackRate=16; }catch(e){}
                    if(isFinite(v.duration) && v.duration>0){ v.currentTime=v.duration; }
                    if(v.paused){ v.play&&v.play(); }
                  } else if(v){ try{ if(v.playbackRate>2) v.playbackRate=1; }catch(e){} }
                  // skip buttons (sabhi tarah ke)
                  ['.ytp-ad-skip-button','.ytp-ad-skip-button-modern','.ytp-skip-ad-button','.ytp-ad-skip-button-container button','button.ytp-ad-skip-button-modern'].forEach(function(sel){
                    var b=document.querySelector(sel); if(b) b.click();
                  });
                  var ov=document.querySelector('.ytp-ad-overlay-close-button,.ytp-ad-overlay-close-container'); if(ov) ov.click();
                }catch(e){}
              }
              setInterval(kill, 150);
              kill();
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    /** YouTube page me video ke neeche Vidmate jaisi line: Save, Popup, Play Audio, Share, Download */
    private fun injectYouTubeButton() {
        val u = web.url ?: return
        if (!u.contains("youtube.com")) return
        val js = """
            (function(){
              if (window.__jpObs) return;
              var ICONS = {
                save:'<path d="M14 10H3v2h11v-2zm0-4H3v2h11V6zm4 8v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zM3 16h7v-2H3v2z"/>',
                popup:'<path d="M19 7h-8v6h8V7zm2-4H3c-1.1 0-2 .9-2 2v14c0 1.1.9 1.98 2 1.98h18c1.1 0 2-.88 2-1.98V5c0-1.1-.9-2-2-2zm0 16.01H3V4.98h18v14.03z"/>',
                audio:'<path d="M12 1c-4.97 0-9 4.03-9 9v7c0 1.66 1.34 3 3 3h3v-8H5v-2c0-3.87 3.13-7 7-7s7 3.13 7 7v2h-4v8h3c1.66 0 3-1.34 3-3v-7c0-4.97-4.03-9-9-9z"/>',
                share:'<path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/>',
                download:'<path d="M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z"/>'
              };
              var ITEMS = [['save','Save',''],['popup','Popup',''],['audio','Play Audio',''],['share','Share','#25D366'],['download','Download','#FF1E3C']];
              function add(){
                if (!/\/(watch|shorts)/.test(location.pathname)) { var o=document.getElementById('jp-bar'); if(o) o.remove(); return; }
                if (document.getElementById('jp-bar')) return;
                var anchor = document.querySelector('ytm-slim-video-metadata-section-renderer, ytm-slim-video-information-renderer, .slim-video-information-renderer, #player-container-id, .player-container');
                if (!anchor) return;
                var bar = document.createElement('div');
                bar.id = 'jp-bar';
                bar.style.cssText = 'display:flex;justify-content:space-around;padding:12px 4px 10px;margin:4px 0;border-bottom:1px solid rgba(128,128,128,.25);font-family:Roboto,Arial,sans-serif;position:relative;z-index:9';
                ITEMS.forEach(function(it){
                  var b = document.createElement('div');
                  b.style.cssText = 'display:flex;flex-direction:column;align-items:center;min-width:60px;cursor:pointer';
                  var col = it[2] || 'currentColor';
                  b.innerHTML = '<svg viewBox="0 0 24 24" width="30" height="30" fill="'+col+'">'+ICONS[it[0]]+'</svg>'+
                    '<span style="font-size:13px;margin-top:5px;color:var(--yt-spec-text-primary,#0f0f0f)">'+it[1]+'</span>';
                  b.style.color = 'var(--yt-spec-text-primary,#0f0f0f)';
                  b.onclick = function(e){
                    e.preventDefault(); e.stopPropagation();
                    if (it[0]==='popup') { try { var v=document.querySelector('video'); if (v && v.paused) v.play(); } catch(x){} }
                    JhatpatBridge.action(it[0], location.href, document.title);
                  };
                  bar.appendChild(b);
                });
                if (anchor.id === 'player-container-id' || anchor.classList.contains('player-container')) anchor.parentNode.insertBefore(bar, anchor.nextSibling);
                else anchor.parentNode.insertBefore(bar, anchor.nextSibling);
              }
              window.__jpObs = new MutationObserver(function(){ add(); });
              window.__jpObs.observe(document.body, {childList:true, subtree:true});
              add();
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    /** Background me audio chale: page ko lage ki wo dikh raha hai */
    private val keepAliveJs = "(function(){try{Object.defineProperty(document,'hidden',{get:function(){return false},configurable:true});" +
        "Object.defineProperty(document,'visibilityState',{get:function(){return 'visible'},configurable:true});" +
        "window.addEventListener('visibilitychange',function(e){e.stopImmediatePropagation()},true);}catch(e){}})();"

    private var bgAudio = false

    inner class Bridge {
        @JavascriptInterface
        fun download(url: String, title: String?) {
            runOnUiThread { DownloadSheet(this@BrowserActivity).show(url, title, sniffed.toList()) }
        }

        @JavascriptInterface
        fun action(name: String, url: String, title: String?) {
            runOnUiThread { doAction(name, url, title ?: url) }
        }
    }

    private fun doAction(name: String, url: String, title: String) {
        when (name) {
            "save" -> Util.toast(this, if (Prefs.toggleBookmark(title, url)) "✓ Saved (Me → ${Lang.t("bookmarks")})" else "Removed")
            "popup" -> enterPopup()
            "audio" -> {
                bgAudio = true
                web.evaluateJavascript(keepAliveJs, null)
                Util.toast(this, "🎧 Audio background me chalega")
                moveTaskToBack(true)
            }
            "share" -> startActivity(Intent.createChooser(
                Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "$title\n$url"), Lang.t("share")))
            "download" -> DownloadSheet(this).show(url, title, sniffed.toList())
        }
    }

    /** Popup (Picture-in-Picture) */
    private fun enterPopup() {
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            try {
                web.evaluateJavascript(keepAliveJs, null)
                val p = android.app.PictureInPictureParams.Builder()
                    .setAspectRatio(android.util.Rational(16, 9)).build()
                enterPictureInPictureMode(p)
                return
            } catch (_: Exception) { }
        }
        Util.toast(this, "Is phone me Popup support nahi hai")
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: android.content.res.Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        findViewById<View>(R.id.etUrl).let { (it.parent as View).visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE }
        findViewById<View>(R.id.btnBack).let { (it.parent as View).visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE }
        fab.visibility = if (isInPictureInPictureMode) View.GONE else View.VISIBLE
        if (isInPictureInPictureMode) {
            // Video ko page ke upar le aao
            web.evaluateJavascript("window.scrollTo(0,0);", null)
        }
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        fullContainer.removeView(v)
        fullContainer.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        setFullscreen(false)
        updateFab(web.url ?: "")
    }

    private fun setFullscreen(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun updateDlCount() {
        val n = DownloadRepo.all().count { it.isActive }
        tvDlCount.visibility = if (n > 0) View.VISIBLE else View.GONE
        tvDlCount.text = n.toString()
    }

    override fun onResume() {
        super.onResume()
        bgAudio = false
        web.onResume()
        DownloadRepo.addListener(dlListener)
        updateDlCount()
        updateTabCount()
    }

    override fun onPause() {
        super.onPause()
        captureThumb()
        Tabs.update(tabId, web.url, web.title)
        val pip = android.os.Build.VERSION.SDK_INT >= 24 && isInPictureInPictureMode
        if (!bgAudio && !pip) web.onPause()
        DownloadRepo.removeListener(dlListener)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        pulsing = false
        web.destroy()
        super.onDestroy()
    }
}
