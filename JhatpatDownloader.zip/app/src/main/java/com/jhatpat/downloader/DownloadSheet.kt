package com.jhatpat.downloader

import android.app.Activity
import android.content.res.ColorStateList
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Environment
import android.os.StatFs
import android.text.SpannableString
import android.text.Spanned
import android.text.style.RelativeSizeSpan
import android.text.style.StyleSpan
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Vidmate jaisa download panel: Music + Video quality chuno -> bada DOWNLOAD button */
class DownloadSheet(private val act: Activity) {

    private val dialog = BottomSheetDialog(act)
    private val root: View = LayoutInflater.from(act).inflate(R.layout.sheet_download, null)
    private val ivThumb: ImageView = root.findViewById(R.id.ivThumb)
    private val tvTitle: TextView = root.findViewById(R.id.tvTitle)
    private val tvMeta: TextView = root.findViewById(R.id.tvMeta)
    private val tvDur: TextView = root.findViewById(R.id.tvDur)
    private val boxLoading: View = root.findViewById(R.id.boxLoading)
    private val boxError: View = root.findViewById(R.id.boxError)
    private val tvError: TextView = root.findViewById(R.id.tvError)
    private val boxOptions: LinearLayout = root.findViewById(R.id.boxOptions)
    private val btnDownload: View = root.findViewById(R.id.btnDownload)
    private var sniffed: List<String> = emptyList()
    private var pageTitle: String? = null

    private var info: MediaInfo? = null
    private var selected: Pair<MediaInfo, DlOption>? = null
    private val radios = ArrayList<Pair<RadioButton, TextView>>()
    private var customName: String? = null
    private val accent = act.attrColor(R.attr.jpAccent3)

    init {
        Lang.apply(root)
        dialog.setContentView(root)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.behavior.skipCollapsed = true
        dialog.setOnShowListener {
            dialog.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
                ?.setBackgroundColor(android.graphics.Color.TRANSPARENT)
        }
        root.findViewById<TextView>(R.id.tvDownloadBtn).text = Lang.t("download").uppercase()
        btnDownload.setOnClickListener {
            val sel = selected ?: return@setOnClickListener Util.toast(act, "Quality chunein")
            // Asli video name + photo use karo (placeholder "YouTube"/"Video" nahi)
            val mi = sel.first.copy(title = bestTitle(sel.first.title), thumb = bestThumb(sel.first.thumb))
            DownloadService.enqueue(act, mi, sel.second, customName)
            dialog.dismiss()
        }
        root.findViewById<View>(R.id.btnRename).setOnClickListener { rename() }
        root.findViewById<View>(R.id.btnChange).setOnClickListener { changePath() }
        showPath()
    }

    private var userPicked = false
    private var suppressPick = false

    fun show(url: String, pageTitle: String? = null, sniffedMedia: List<String> = emptyList()) {
        sniffed = sniffedMedia
        this.pageTitle = cleanTitle(pageTitle)
        if (!this.pageTitle.isNullOrBlank()) tvTitle.text = this.pageTitle
        tvMeta.text = url
        root.findViewById<View>(R.id.btnRetry).setOnClickListener { load(url) }
        dialog.show()
        // Har site par quality list TURANT dikhao (bina intezaar) — 18+ sites par bhi fast
        showInfo(Engine.fixedOptions(url, pageTitle), instant = true)
        refine(url)
    }

    /** Peeche se asli title/thumbnail/size le aao */
    private fun refine(url: String) {
        Thread {
            try {
                val i = Engine.analyze(act, url)
                act.runOnUiThread {
                    if (act.isFinishing) return@runOnUiThread
                    // Title/thumb/duration hamesha update
                    tvTitle.text = customName ?: i.title
                    tvMeta.text = listOfNotNull(i.site, i.uploader).joinToString("  •  ")
                    val d = Util.duration(i.duration)
                    tvDur.visibility = if (d.isBlank()) View.GONE else View.VISIBLE
                    tvDur.text = d
                    ImageLoader.load(i.thumb, ivThumb)
                    // Asli MB size + 2K/4K bhar do (user ki choice bani rahegi)
                    showInfo(i, instant = false)
                }
            } catch (e: Throwable) {
                act.runOnUiThread {
                    if (act.isFinishing) return@runOnUiThread
                    // Instant list pehle se dikh rahi hai to usi se download hoga
                    if (boxLoading.visibility == View.VISIBLE) {
                        val msg = (e.message ?: "").lines().lastOrNull { it.contains("ERROR") } ?: "Error"
                        showError(msg.replace("ERROR:", "").trim())
                    }
                }
            }
        }.start()
    }

    private fun showPath() {
        root.findViewById<TextView>(R.id.tvPath).text = "Path: " + Util.pathLabel(act)
        try {
            val st = StatFs(Environment.getExternalStorageDirectory().path)
            val total = st.totalBytes
            val free = st.availableBytes
            root.findViewById<TextView>(R.id.tvFree).text = "${Util.size(free)} FREE/${Util.size(total)}"
            root.findViewById<ProgressBar>(R.id.pbStorage).progress = if (total > 0) ((total - free) * 100 / total).toInt() else 0
        } catch (_: Exception) { }
    }

    private fun changePath() {
        val opts = listOf(
            "jhatpat" to "Phone storage / JhatpatDownloader",
            "gallery" to "Gallery: Movies + Music",
            "download" to "Download / JhatpatDownloader"
        )
        AlertDialog.Builder(act).setTitle(Lang.t("dl_path"))
            .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), opts.indexOfFirst { it.first == Prefs.pathMode }) { d, w ->
                d.dismiss()
                val mode = opts[w].first
                if (mode == "jhatpat" && !Util.hasAllFiles(act) && act is BaseActivity) StorageDialog.show(act) { }
                Prefs.pathMode = mode
                showPath()
            }.show()
    }

    private fun rename() {
        val et = EditText(act)
        et.setText(customName ?: info?.title ?: tvTitle.text)
        et.setSelectAllOnFocus(true)
        val wrap = LinearLayout(act).apply { setPadding(act.dp(20), act.dp(8), act.dp(20), 0); addView(et, LinearLayout.LayoutParams(-1, -2)) }
        AlertDialog.Builder(act).setTitle("Rename").setView(wrap)
            .setPositiveButton(Lang.t("ok")) { _, _ ->
                val n = et.text.toString().trim()
                if (n.isNotEmpty()) { customName = n; tvTitle.text = n }
            }
            .setNegativeButton(Lang.t("cancel"), null).show()
    }

    private fun load(url: String) {
        boxLoading.visibility = View.VISIBLE
        boxError.visibility = View.GONE
        boxOptions.removeAllViews()
        radios.clear(); selected = null; userPicked = false; updateButton()
        refine(url)
    }

    private fun showInfo(i: MediaInfo, instant: Boolean) {
        info = i
        boxLoading.visibility = View.GONE
        boxError.visibility = View.GONE
        boxOptions.removeAllViews()
        radios.clear()
        val prevLabel = selected?.second?.label
        selected = null

        val audio = i.options.filter { it.kind == "audio" }
        val video = i.options.filter { it.kind == "video" }.sortedByDescending { qualityNum(it.label) }
        section(R.drawable.ic_music, "Music", true)
        grid(i, audio)
        section(R.drawable.ic_play, "Video", false)
        grid(i, video)
        if (!instant) addSniffed(i.title)

        // Pehle jo chuna tha wahi dobara, warna 360P (Vidmate jaisa)
        val def = (if (prevLabel != null) video.firstOrNull { it.label == prevLabel } else null)
            ?: video.firstOrNull { qualityNum(it.label) == 360 }
            ?: video.lastOrNull { qualityNum(it.label) in 1..720 } ?: video.firstOrNull() ?: audio.firstOrNull()
        suppressPick = true
        radios.firstOrNull { it.first.tag == def }?.first?.performClick()
        suppressPick = false
    }

    private fun qualityNum(label: String) = label.filter { it.isDigit() }.toIntOrNull() ?: 9999

    private fun showError(msg: String) {
        boxLoading.visibility = View.GONE
        if (sniffed.isNotEmpty()) {
            // Asli page title dikhao (placeholder nahi)
            tvTitle.text = pageTitle ?: "Page par video mile"
            // Agar HLS (m3u8) stream mila hai to usme se asli quality (360p/480p/720p/1080p) nikalo
            val m3u8 = sniffed.firstOrNull { it.contains(".m3u8") }
            if (m3u8 != null) {
                boxLoading.visibility = View.VISIBLE
                Thread {
                    try {
                        val si = Engine.analyze(act, m3u8)
                        act.runOnUiThread {
                            if (act.isFinishing) return@runOnUiThread
                            if (!pageTitle.isNullOrBlank()) tvTitle.text = pageTitle
                            if (si.options.any { it.kind == "video" }) showInfo(si, instant = true)
                            else showRawSniffed()
                        }
                    } catch (_: Throwable) {
                        act.runOnUiThread { if (!act.isFinishing) showRawSniffed() }
                    }
                }.start()
                return
            }
            showRawSniffed()
            return
        }
        boxError.visibility = View.VISIBLE
        tvError.text = Lang.t("not_found") + "\n\n($msg)"
    }

    private fun showRawSniffed() {
        boxLoading.visibility = View.GONE
        addSniffed(pageTitle ?: "Video")
        suppressPick = true
        radios.firstOrNull()?.first?.performClick()
        suppressPick = false
    }

    private fun isPlaceholder(s: String?) =
        s.isNullOrBlank() || s.equals("YouTube", true) || s.equals("Video", true) || s.startsWith("Video ")

    /** Download ke liye sabse accha title chuno */
    private fun bestTitle(optTitle: String?): String {
        if (!customName.isNullOrBlank()) return customName!!
        if (!isPlaceholder(info?.title)) return info!!.title
        if (!isPlaceholder(pageTitle)) return pageTitle!!
        if (!isPlaceholder(optTitle)) return optTitle!!
        return info?.title ?: pageTitle ?: optTitle ?: "Video"
    }

    private fun bestThumb(optThumb: String?): String? {
        info?.thumb?.takeIf { it.isNotBlank() }?.let { return it }
        if (!optThumb.isNullOrBlank()) return optThumb
        // YouTube link se seedha thumbnail nikaalo
        ytId(info?.url ?: "")?.let { return "https://i.ytimg.com/vi/$it/hqdefault.jpg" }
        return null
    }

    private fun ytId(url: String): String? {
        val m = Regex("(?:v=|youtu\\.be/|shorts/|embed/)([A-Za-z0-9_-]{11})").find(url)
        return m?.groupValues?.get(1)
    }

    /** Page/stream title saaf karo (site ka naam hata do) */
    private fun cleanTitle(t: String?): String? {
        if (t.isNullOrBlank()) return null
        var s = t.substringBefore(" - ").substringBefore(" | ").trim()
        if (s.length > 80) s = s.take(80)
        return s.ifBlank { null }
    }

    private fun addSniffed(title: String) {
        if (sniffed.isEmpty()) return
        section(R.drawable.ic_search, Lang.t("found_on_page").replace("🔎", "").trim(), false)
        val list = sniffed.take(8).mapIndexed { idx, u ->
            val ext = u.substringBefore('?').substringAfterLast('.', "mp4").take(4).uppercase()
            val mi = MediaInfo(u, "$title ${idx + 1}", null, 0, null, "Web", emptyList())
            mi to DlOption("Video ${idx + 1}", "", "video", "b", null, 0, ext)
        }
        val g = newGrid()
        list.forEach { (mi, o) -> cell(g, mi, o) }
        boxOptions.addView(g)
    }

    private fun section(icon: Int, title: String, round: Boolean) {
        val row = LinearLayout(act).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(0, act.dp(10), 0, act.dp(8))
        }
        val iv = ImageView(act).apply {
            setImageResource(icon)
            imageTintList = ColorStateList.valueOf(0xFFFFFFFF.toInt())
            setPadding(act.dp(6), act.dp(6), act.dp(6), act.dp(6))
            background = GradientDrawable().apply {
                if (round) shape = GradientDrawable.OVAL else cornerRadius = act.dp(6).toFloat()
                setColor(accent)
            }
        }
        row.addView(iv, LinearLayout.LayoutParams(act.dp(30), act.dp(30)))
        row.addView(TextView(act).apply {
            text = title; textSize = 20f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(act.getColor(R.color.text)); setPadding(act.dp(14), 0, 0, 0)
        })
        boxOptions.addView(row)
    }

    private fun newGrid() = GridLayout(act).apply { columnCount = 2 }

    private fun grid(i: MediaInfo, opts: List<DlOption>) {
        val g = newGrid()
        opts.forEach { cell(g, i, it) }
        boxOptions.addView(g)
    }

    private fun cell(g: GridLayout, i: MediaInfo, o: DlOption) {
        val box = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; setPadding(0, act.dp(4), 0, act.dp(8)) }
        val rb = RadioButton(act)
        val label = o.label
        val sp = SpannableString("$label (${o.ext})")
        sp.setSpan(StyleSpan(Typeface.BOLD), 0, label.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        sp.setSpan(RelativeSizeSpan(0.8f), label.length, sp.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        rb.text = sp
        rb.textSize = 17f
        rb.tag = o
        rb.buttonTintList = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(accent, 0xFF9E9EA8.toInt())
        )
        rb.setTextColor(act.getColor(R.color.text))
        val size = TextView(act).apply {
            text = Util.size(o.sizeBytes).replace(" ", "").ifBlank { "—" }
            textSize = 14f
            setTextColor(act.getColor(R.color.text2))
            setPadding(act.dp(32), 0, 0, 0)
        }
        box.addView(rb)
        box.addView(size)
        val pick = {
            radios.forEach { (r, s) ->
                val on = r === rb
                r.isChecked = on
                r.setTextColor(if (on) accent else act.getColor(R.color.text))
                s.setTextColor(if (on) accent else act.getColor(R.color.text2))
            }
            selected = i to o
            updateButton()
        }
        rb.setOnClickListener { if (!suppressPick) userPicked = true; pick() }
        box.setOnClickListener { if (!suppressPick) userPicked = true; pick() }
        radios.add(rb to size)
        val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
        lp.width = 0
        g.addView(box, lp)
    }

    private fun updateButton() {
        btnDownload.alpha = if (selected == null) 0.5f else 1f
    }
}
