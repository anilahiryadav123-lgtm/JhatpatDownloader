package com.jhatpat.downloader

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.util.TypedValue
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

data class ThemeColor(val key: String, val name: String, val color: Int, val style: Int)

object Themes {
    val all = listOf(
        ThemeColor("jhatpat", "Jhatpat", 0xFFFF7A00.toInt(), R.style.Accent_jhatpat),
        ThemeColor("red", "Red", 0xFFF0002A.toInt(), R.style.Accent_red),
        ThemeColor("blue", "Blue", 0xFF2979FF.toInt(), R.style.Accent_blue),
        ThemeColor("green", "Green", 0xFF22C55E.toInt(), R.style.Accent_green),
        ThemeColor("purple", "Purple", 0xFF8B5CF6.toInt(), R.style.Accent_purple),
        ThemeColor("pink", "Pink", 0xFFEC4899.toInt(), R.style.Accent_pink),
        ThemeColor("teal", "Teal", 0xFF14B8A6.toInt(), R.style.Accent_teal),
        ThemeColor("gold", "Gold", 0xFFF59E0B.toInt(), R.style.Accent_gold),
        ThemeColor("indigo", "Indigo", 0xFF6366F1.toInt(), R.style.Accent_indigo),
        ThemeColor("cyan", "Cyan", 0xFF06B6D4.toInt(), R.style.Accent_cyan)
    )

    fun current(): ThemeColor = all.firstOrNull { it.key == Prefs.theme } ?: all[0]
}

fun Context.attrColor(attr: Int): Int {
    val tv = TypedValue()
    theme.resolveAttribute(attr, tv, true)
    return tv.data
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Har screen par theme rang + din/raat + bhasha lagata hai */
open class BaseActivity : AppCompatActivity() {
    private var themeKey = ""
    private var langKey = ""
    private var fontKey = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        themeKey = Prefs.theme
        langKey = Prefs.lang
        fontKey = Prefs.font
        theme.applyStyle(Themes.current().style, true)
        super.onCreate(savedInstanceState)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.isAppearanceLightStatusBars = !night
        c.isAppearanceLightNavigationBars = !night
    }

    override fun setContentView(layoutResID: Int) {
        super.setContentView(layoutResID)
        translate()
    }

    override fun setContentView(view: View?) {
        super.setContentView(view)
        translate()
    }

    fun translate() {
        findViewById<View>(android.R.id.content)?.let { Lang.apply(it); Fonts.apply(it) }
    }

    override fun onResume() {
        super.onResume()
        // Theme ya bhasha badli ho to screen dobara banao
        if (themeKey != Prefs.theme || langKey != Prefs.lang || fontKey != Prefs.font) recreate()
    }
}
