package com.jhatpat.downloader

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat

/** Vidmate jaisa "Allow access to all files" dialog */
object StorageDialog {
    fun show(act: BaseActivity, onDone: () -> Unit) {
        Prefs.askedStorage = true
        if (Util.hasAllFiles(act)) { onDone(); return }
        val v = LayoutInflater.from(act).inflate(R.layout.dialog_storage, null)
        Lang.apply(v)
        val d = AlertDialog.Builder(act).setView(v).setCancelable(true).create()
        d.window?.setBackgroundDrawableResource(android.R.color.transparent)
        v.findViewById<android.view.View>(R.id.btnConfirm).setOnClickListener {
            d.dismiss()
            request(act)
            onDone()
        }
        d.show()
    }

    fun request(act: BaseActivity) {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                act.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + act.packageName)))
            } catch (e: Exception) {
                try { act.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) } catch (_: Exception) { }
            }
        } else {
            ActivityCompat.requestPermissions(act, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE), 8)
        }
        Prefs.pathMode = "jhatpat"
    }
}
