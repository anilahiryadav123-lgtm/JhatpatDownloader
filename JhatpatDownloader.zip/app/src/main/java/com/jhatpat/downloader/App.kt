package com.jhatpat.downloader

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        installCrashGuard()
        androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(Prefs.nightMode)
        DownloadRepo.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Downloading", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Download complete", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        Engine.initAsync(this)
    }

    /** Koi crash aaye to app band hone ke bajay dobara khul jaaye */
    private fun installCrashGuard() {
        val def = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                // UI thread crash -> app ko restart karo (user ko force-close na dikhe)
                if (t == mainLooperThread()) {
                    val i = packageManager.getLaunchIntentForPackage(packageName)
                    i?.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    startActivity(i)
                    android.os.Process.killProcess(android.os.Process.myPid())
                    Runtime.getRuntime().exit(0)
                } else {
                    // Background thread crash -> chup-chaap ignore (app chalta rahe)
                }
            } catch (_: Throwable) {
                def?.uncaughtException(t, e)
            }
        }
    }

    private fun mainLooperThread(): Thread = mainLooper.thread

    companion object {
        lateinit var instance: App
        const val CH_PROGRESS = "jp_progress"
        const val CH_DONE = "jp_done"
    }
}
