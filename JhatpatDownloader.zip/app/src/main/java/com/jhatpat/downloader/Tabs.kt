package com.jhatpat.downloader

import android.graphics.Bitmap

/** Multi-tab browser ka saara hisaab (ek hi WebView, par kai tabs ki list) */
object Tabs {
    data class Tab(
        val id: Long,
        var url: String,
        var title: String = "New tab",
        var thumb: Bitmap? = null
    )

    val list = ArrayList<Tab>()
    var currentId: Long = -1L
        private set

    private var seq = 1L

    /** Naya tab banao aur current bana do */
    fun open(url: String): Long {
        val t = Tab(seq++, url)
        list.add(t)
        currentId = t.id
        return t.id
    }

    fun get(id: Long): Tab? = list.firstOrNull { it.id == id }

    fun setCurrent(id: Long) { if (get(id) != null) currentId = id }

    fun update(id: Long, url: String?, title: String?) {
        val t = get(id) ?: return
        if (!url.isNullOrBlank()) t.url = url
        if (!title.isNullOrBlank()) t.title = title
    }

    fun thumb(id: Long, bmp: Bitmap?) { get(id)?.thumb = bmp }

    /** Tab band karo. Agar current band hua to naya current chuno. Bache hue tab ka id return. */
    fun close(id: Long): Long {
        val idx = list.indexOfFirst { it.id == id }
        if (idx < 0) return currentId
        list.removeAt(idx)
        if (currentId == id) {
            currentId = list.lastOrNull()?.id ?: -1L
        }
        return currentId
    }

    fun count() = list.size
}
