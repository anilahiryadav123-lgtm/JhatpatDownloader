package com.jhatpat.downloader

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Home screen widget: Search, YouTube, Paste link, Downloads, Sites */
class QuickWidget : AppWidgetProvider() {
    override fun onUpdate(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_quick)
        fun pi(action: String, code: Int): PendingIntent {
            val i = Intent(ctx, MainActivity::class.java).putExtra("open", action)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            return PendingIntent.getActivity(ctx, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
        rv.setOnClickPendingIntent(R.id.wSearch, pi("search", 11))
        rv.setOnClickPendingIntent(R.id.wYoutube, pi("youtube", 12))
        rv.setOnClickPendingIntent(R.id.wPaste, pi("paste", 13))
        rv.setOnClickPendingIntent(R.id.wDownloads, pi("downloads", 14))
        rv.setOnClickPendingIntent(R.id.wSites, pi("sites", 15))
        ids.forEach { mgr.updateAppWidget(it, rv) }
    }
}
