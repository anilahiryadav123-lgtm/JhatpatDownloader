package com.jhatpat.downloader

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Vidmate jaisa pehli baar ka screen: Bhasha chunein -> Smarter / Cleaner / Faster */
class OnboardingActivity : BaseActivity() {

    private var step = 0
    private val slides = listOf(
        Triple("smarter", "smarter_d", R.drawable.ic_flame),
        Triple("cleaner", "cleaner_d", R.drawable.ic_check_circle),
        Triple("faster", "faster_d", R.drawable.ic_bolt)
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboarding)

        val rv = findViewById<RecyclerView>(R.id.rvLang)
        rv.layoutManager = GridLayoutManager(this, 3)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_lang, p, false)) {}

            override fun getItemCount() = Lang.all.size

            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val l = Lang.all[pos]
                h.itemView.background = GradientDrawable().apply {
                    setColor(l.color); cornerRadius = dp(6).toFloat()
                }
                h.itemView.findViewById<TextView>(R.id.tvLang).text = l.native
                h.itemView.findViewById<TextView>(R.id.tvLangBig).text = l.native.take(1)
                h.itemView.findViewById<View>(R.id.tvCheck).visibility =
                    if (l.code == Prefs.lang) View.VISIBLE else View.GONE
                h.itemView.setOnClickListener {
                    Prefs.lang = l.code
                    notifyDataSetChanged()
                    it.postDelayed({ showIntro() }, 250)
                }
            }
        }
        findViewById<View>(R.id.btnLangSkip).setOnClickListener { showIntro() }
        findViewById<View>(R.id.btnSkip).setOnClickListener { finishOnboarding() }
        findViewById<View>(R.id.btnNext).setOnClickListener {
            if (step < slides.size - 1) { step++; showSlide() } else finishOnboarding()
        }
    }

    private fun showIntro() {
        translate()
        findViewById<View>(R.id.boxLang).visibility = View.GONE
        findViewById<View>(R.id.boxIntro).visibility = View.VISIBLE
        step = 0
        showSlide()
    }

    private fun showSlide() {
        val (title, desc, icon) = slides[step]
        findViewById<TextView>(R.id.tvIntroTitle).text = Lang.t(title)
        findViewById<TextView>(R.id.tvIntroDesc).text = Lang.t(desc)
        findViewById<TextView>(R.id.btnNext).text = Lang.t(if (step == slides.size - 1) "start" else "next")
        val big = findViewById<ImageView>(R.id.ivBig)
        big.setImageResource(icon)
        big.scaleX = 0.6f; big.scaleY = 0.6f; big.alpha = 0f
        big.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(380).start()
        listOf(R.id.ivSmall1, R.id.ivSmall2).forEachIndexed { i, id ->
            val v = findViewById<View>(id)
            v.translationY = 40f; v.alpha = 0f
            v.animate().translationY(0f).alpha(1f).setStartDelay(120L + i * 80).setDuration(400).start()
        }
        val dots = findViewById<LinearLayout>(R.id.dots)
        dots.removeAllViews()
        for (i in slides.indices) {
            val d = View(this)
            val lp = LinearLayout.LayoutParams(dp(if (i == step) 10 else 8), dp(if (i == step) 10 else 8))
            lp.marginEnd = dp(8)
            d.layoutParams = lp
            d.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(if (i == step) attrColor(R.attr.jpAccent2) else 0xFFCCCCCC.toInt())
            }
            dots.addView(d)
        }
    }

    private fun finishOnboarding() {
        Prefs.onboarded = true
        startActivity(Intent(this, MainActivity::class.java).putExtra("first", true))
        finish()
    }
}
