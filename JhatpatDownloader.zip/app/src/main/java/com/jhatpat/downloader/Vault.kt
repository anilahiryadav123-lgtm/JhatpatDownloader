package com.jhatpat.downloader

import android.app.Activity
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.io.File
import java.security.MessageDigest

/** Private folder: 4 ank ka password, chhupi hui videos */
object Vault {
    @Volatile var unlocked = false

    private fun hash(pin: String): String =
        MessageDigest.getInstance("SHA-256").digest(("jhatpat:" + pin).toByteArray())
            .joinToString("") { "%02x".format(it) }

    val hasPin: Boolean get() = Prefs.pinHash.isNotEmpty()
    fun check(pin: String) = hash(pin) == Prefs.pinHash
    fun setPin(pin: String) { Prefs.pinHash = hash(pin) }

    private fun dir(act: Activity) = File(act.filesDir, "private").apply { mkdirs() }

    /** Video/MP3 ko private folder me chhupao (Gallery se hat jaati hai) */
    fun hide(act: Activity, tasks: List<DTask>, done: () -> Unit) {
        val d = AlertDialog.Builder(act).setMessage("🔒 Hide ho raha hai...").setCancelable(false).show()
        Thread {
            var ok = 0
            tasks.forEach { t ->
                try {
                    val src = Uri.parse(t.fileUri ?: return@forEach)
                    val ext = (t.filePath ?: "").substringAfterLast('.', "mp4").take(5)
                    val dest = File(dir(act), "${t.id}.$ext")
                    act.contentResolver.openInputStream(src)!!.use { inp -> dest.outputStream().use { inp.copyTo(it, 256 * 1024) } }
                    Util.deleteFile(act, t)
                    t.fileUri = Uri.fromFile(dest).toString()
                    t.filePath = dest.absolutePath
                    t.hidden = true
                    ok++
                } catch (_: Exception) { }
            }
            DownloadRepo.save(); DownloadRepo.changed()
            act.runOnUiThread { d.dismiss(); Util.toast(act, "✓ $ok file Private me chhup gayi"); done() }
        }.start()
    }

    /** Wapas Gallery me lao */
    fun unhide(act: Activity, tasks: List<DTask>, done: () -> Unit) {
        val d = AlertDialog.Builder(act).setMessage("🔓 Unhide ho raha hai...").setCancelable(false).show()
        Thread {
            tasks.forEach { t ->
                try {
                    val f = File(t.filePath ?: return@forEach)
                    val nice = File(f.parentFile, safeName(t.title) + "." + f.extension)
                    val src = if (f.renameTo(nice)) nice else f
                    val (uri, path) = Util.publish(act, src)
                    t.fileUri = uri; t.filePath = path; t.hidden = false
                } catch (_: Exception) { }
            }
            DownloadRepo.save(); DownloadRepo.changed()
            act.runOnUiThread { d.dismiss(); Util.toast(act, "✓ Gallery me wapas aa gayi"); done() }
        }.start()
    }

    private fun safeName(s: String) = s.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(100).ifBlank { "video" }
}

/**
 * Sundar PIN screen (number pad).
 * mode "set" = naya password (2 baar), "check" = kholna
 */
class PinDialog(private val act: Activity, private val mode: String, private val onSuccess: () -> Unit) {
    private val v = LayoutInflater.from(act).inflate(R.layout.dialog_pin, null)
    private val dots = v.findViewById<LinearLayout>(R.id.dots)
    private val title = v.findViewById<TextView>(R.id.tvPinTitle)
    private val msg = v.findViewById<TextView>(R.id.tvPinMsg)
    private val dialog = AlertDialog.Builder(act).setView(v).create()
    private var pin = ""
    private var first: String? = null

    fun show() {
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        dialog.setOnShowListener {
            dialog.window?.let { w ->
                w.setLayout(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT)
                w.setBackgroundDrawableResource(R.color.bg)
            }
        }
        if (mode == "set") {
            title.text = "Set Password"
            msg.text = "Create a 4-digit PIN to lock your private videos.\nOnly you can open them."
        } else {
            title.text = "Enter Password"
            msg.text = "Enter your 4-digit PIN to open the private folder"
        }
        buildKeys()
        drawDots()
        dialog.show()
    }

    private fun buildKeys() {
        val grid = v.findViewById<GridLayout>(R.id.keypad)
        val accent = act.attrColor(R.attr.jpAccent2)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "✕", "0", "⌫")
        keys.forEach { k ->
            val special = k == "✕" || k == "⌫"
            val b = TextView(act).apply {
                text = k; gravity = Gravity.CENTER; textSize = if (special) 22f else 26f
                setTextColor(if (special) accent else act.getColor(R.color.text))
                setTypeface(typeface, Typeface.BOLD)
                background = android.graphics.drawable.StateListDrawable().apply {
                    val pressed = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor((accent and 0x00FFFFFF) or 0x33000000) }
                    val normal = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        if (special) setColor(0x00000000) else setColor(act.getColor(R.color.surface2))
                    }
                    addState(intArrayOf(android.R.attr.state_pressed), pressed)
                    addState(intArrayOf(), normal)
                }
                setOnClickListener { press(k) }
            }
            // Har key ek barabar circle (width == height) — dekhne me saaf
            val lp = GridLayout.LayoutParams()
            lp.width = act.dp(74)
            lp.height = act.dp(74)
            lp.setMargins(act.dp(10), act.dp(10), act.dp(10), act.dp(10))
            grid.addView(b, lp)
        }
    }

    private fun drawDots() {
        dots.removeAllViews()
        val accent = act.attrColor(R.attr.jpAccent2)
        for (i in 0 until 4) {
            val d = View(act)
            val filled = i < pin.length
            val lp = LinearLayout.LayoutParams(act.dp(if (filled) 18 else 16), act.dp(if (filled) 18 else 16))
            lp.setMargins(act.dp(11), 0, act.dp(11), 0)
            d.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                if (filled) setColor(accent) else { setColor(act.getColor(R.color.surface2)); setStroke(act.dp(2), accent) }
            }
            dots.addView(d, lp)
        }
    }

    private fun press(k: String) {
        when (k) {
            "✕" -> { dialog.dismiss(); return }
            "⌫" -> pin = pin.dropLast(1)
            else -> if (pin.length < 4) pin += k
        }
        drawDots()
        if (pin.length == 4) dots.postDelayed({ complete() }, 150)
    }

    private fun shake(text: String) {
        msg.text = text
        msg.setTextColor(act.attrColor(R.attr.jpAccent3))
        dots.animate().translationX(20f).setDuration(60).withEndAction {
            dots.animate().translationX(-20f).setDuration(60).withEndAction { dots.animate().translationX(0f).setDuration(60).start() }.start()
        }.start()
        pin = ""; drawDots()
    }

    private fun complete() {
        if (mode == "set") {
            if (first == null) {
                first = pin; pin = ""
                title.text = "Confirm PIN"
                msg.text = "Enter the same 4 digits again"
                drawDots()
            } else if (first == pin) {
                Vault.setPin(pin); Vault.unlocked = true
                Util.toast(act, "✓ PIN set successfully")
                dialog.dismiss(); onSuccess()
            } else {
                first = null; title.text = "Set Password"
                shake("PINs did not match. Try again.")
            }
        } else {
            if (Vault.check(pin)) {
                Vault.unlocked = true
                dialog.dismiss(); onSuccess()
            } else shake("Wrong PIN ❌")
        }
    }
}
