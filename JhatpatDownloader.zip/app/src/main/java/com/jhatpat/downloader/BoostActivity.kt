package com.jhatpat.downloader

import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.view.animation.LinearInterpolator
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/** Vidmate jaisa green "Phone boost" screen - rocket + percentage */
class BoostActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_boost)
        window.statusBarColor = getColor(R.color.boost_green)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val rocket = findViewById<View>(R.id.rocket)
        val ring = findViewById<View>(R.id.ring)
        val tvP = findViewById<TextView>(R.id.tvPercent)
        val tvL = findViewById<TextView>(R.id.tvLabel)

        // Memory free karo
        val before = Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }
        ImageLoader.clear()
        try { android.webkit.WebView(this).clearCache(false) } catch (_: Exception) { }

        // Rocket halka sa upar-neeche
        rocket.animate().translationY(-18f).setDuration(600).withEndAction {
            rocket.animate().translationY(0f).setDuration(600).start()
        }.start()
        ring.animate().rotationBy(360f).setDuration(3000).setInterpolator(LinearInterpolator()).start()

        val target = (65..92).random()
        ValueAnimator.ofInt(0, target).apply {
            duration = 1800
            addUpdateListener { tvP.text = "${it.animatedValue}%" }
            start()
        }
        tvP.postDelayed({
            System.gc()
            val after = Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }
            val freed = (before - after).coerceAtLeast(1_000_000)
            rocket.animate().translationY(-1400f).setDuration(700).withEndAction {
                tvL.text = "Phone boosted ✓"
                tvP.text = Util.size(freed) + " freed"
                tvP.textSize = 30f
                rocket.translationY = 0f
                rocket.postDelayed({ if (!isFinishing) finish() }, 1100)
            }.start()
        }, 2000)
    }
}
