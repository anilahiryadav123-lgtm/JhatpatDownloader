package com.jhatpat.downloader

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

/** Jhatpat ka apna custom video / MP3 player (Vidmate jaisa) */
class PlayerActivity : AppCompatActivity() {
    private lateinit var video: VideoView
    private lateinit var title: TextView
    private lateinit var art: ImageView
    private lateinit var controls: View
    private lateinit var btnPlay: ImageButton
    private lateinit var seek: SeekBar
    private lateinit var tvCur: TextView
    private lateinit var tvTotal: TextView
    private lateinit var btnUnlock: ImageButton
    private val brand by lazy { findViewById<View>(R.id.brand) }

    private var pos = 0
    private var queue: List<DTask> = emptyList()
    private var index = 0
    private var locked = false
    private var landscape = false
    private var dragging = false
    private val ui = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() {
            if (!dragging && video.isPlaying) {
                val d = video.duration.coerceAtLeast(0)
                seek.max = d
                seek.progress = video.currentPosition
                tvCur.text = fmt(video.currentPosition)
                tvTotal.text = fmt(d)
            }
            ui.postDelayed(this, 500)
        }
    }
    private val hideRun = Runnable { if (!locked) setControls(false) }

    private fun showBrand() {
        brand.clearAnimation()
        brand.visibility = View.VISIBLE
        brand.alpha = 1f
        brand.bringToFront()
        brand.postDelayed({
            brand.animate().alpha(0f).setDuration(600).withEndAction { brand.visibility = View.GONE }.start()
        }, 15000)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Prefs.brightness >= 0) {
            val lp = window.attributes
            lp.screenBrightness = Prefs.brightness.coerceIn(5, 100) / 100f
            window.attributes = lp
        }
        video = findViewById(R.id.video)
        title = findViewById(R.id.tvTitle)
        art = findViewById(R.id.ivArt)
        controls = findViewById(R.id.controls)
        btnPlay = findViewById(R.id.btnPlayPause)
        seek = findViewById(R.id.seek)
        tvCur = findViewById(R.id.tvCur)
        tvTotal = findViewById(R.id.tvTotal)
        btnUnlock = findViewById(R.id.btnUnlock)

        val ids = intent.getStringArrayListExtra("queue")
        if (ids != null) queue = ids.mapNotNull { DownloadRepo.get(it) }
        else {
            val uri = intent.getStringExtra("uri") ?: run { finish(); return }
            val t = DownloadRepo.all().firstOrNull { it.fileUri == uri }
                ?: DTask("tmp", intent.getStringExtra("title") ?: "", "", null, "video", "", "", null,
                    fileUri = uri, mime = intent.getStringExtra("mime"))
            queue = listOf(t)
        }
        if (queue.isEmpty()) { finish(); return }
        index = savedInstanceState?.getInt("index", 0) ?: 0
        pos = savedInstanceState?.getInt("pos", 0) ?: 0

        wireControls()
        setupGestures()

        video.setOnPreparedListener {
            if (pos > 0) video.seekTo(pos)
            if (Prefs.autoPlay || queue.size > 1) video.start()
            btnPlay.setImageResource(if (video.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
            seek.max = video.duration.coerceAtLeast(0)
            tvTotal.text = fmt(video.duration)
            setControls(true)
            showBrand()
        }
        video.setOnCompletionListener {
            if (index < queue.size - 1) { index++; pos = 0; playCurrent() }
            else btnPlay.setImageResource(R.drawable.ic_play)
        }
        video.setOnErrorListener { _, _, _ ->
            Util.toast(this, "Yeh file yahan nahi chali, dusre player me khul rahi hai")
            Util.openWith(this, queue[index]); finish(); true
        }
        playCurrent()
        ui.post(tick)
    }

    private fun wireControls() {
        findViewById<View>(R.id.btnPlayerBack).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        btnPlay.setOnClickListener { togglePlay() }
        findViewById<View>(R.id.btnPrev).setOnClickListener {
            if (index > 0) { index--; pos = 0; playCurrent() } else video.seekTo(0)
            resetHide()
        }
        findViewById<View>(R.id.btnNext).setOnClickListener {
            if (index < queue.size - 1) { index++; pos = 0; playCurrent() }
            resetHide()
        }
        findViewById<View>(R.id.btnBack10).setOnClickListener { seekBy(-10000); resetHide() }
        findViewById<View>(R.id.btnFwd10).setOnClickListener { seekBy(10000); resetHide() }
        findViewById<View>(R.id.btnFullscreen).setOnClickListener { toggleFullscreen(); resetHide() }
        findViewById<View>(R.id.btnLock).setOnClickListener { setLocked(true) }
        btnUnlock.setOnClickListener { setLocked(false) }
        findViewById<View>(R.id.btnCast).setOnClickListener { Util.toast(this, "Cast: TV/dusre device par (jald aa raha hai)") }
        findViewById<View>(R.id.btnPlaylist).setOnClickListener { playlistMenu() }
        findViewById<View>(R.id.btnPlayerMenu).setOnClickListener { v -> moreMenu(v) }

        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) { if (fromUser) tvCur.text = fmt(p) }
            override fun onStartTrackingTouch(sb: SeekBar) { dragging = true; ui.removeCallbacks(hideRun) }
            override fun onStopTrackingTouch(sb: SeekBar) { dragging = false; video.seekTo(sb.progress); resetHide() }
        })
    }

    private fun togglePlay() {
        if (video.isPlaying) { video.pause(); btnPlay.setImageResource(R.drawable.ic_play); ui.removeCallbacks(hideRun) }
        else { video.start(); btnPlay.setImageResource(R.drawable.ic_pause); resetHide() }
    }

    private fun seekBy(ms: Int) {
        val d = video.duration
        val np = (video.currentPosition + ms).coerceIn(0, if (d > 0) d else video.currentPosition + ms)
        video.seekTo(np)
    }

    private fun setControls(show: Boolean) {
        controls.visibility = if (show) View.VISIBLE else View.GONE
        ui.removeCallbacks(hideRun)
        if (show) ui.postDelayed(hideRun, 3500)
    }

    private fun resetHide() { setControls(true) }

    private fun setLocked(lock: Boolean) {
        locked = lock
        controls.visibility = if (lock) View.GONE else View.VISIBLE
        btnUnlock.visibility = if (lock) View.VISIBLE else View.GONE
        if (!lock) resetHide()
        Util.toast(this, if (lock) "🔒 Locked" else "🔓 Unlocked")
    }

    private fun toggleFullscreen() {
        landscape = !landscape
        requestedOrientation = if (landscape) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
    }

    private fun playlistMenu() {
        if (queue.size <= 1) { Util.toast(this, "Playlist me sirf yahi video hai"); return }
        val names = queue.mapIndexed { i, t -> (if (i == index) "▶ " else "") + t.title }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Playlist (${queue.size})")
            .setItems(names) { _, w -> index = w; pos = 0; playCurrent() }
            .show()
    }

    private fun moreMenu(v: View) {
        val pm = androidx.appcompat.widget.PopupMenu(this, v)
        pm.menu.add(0, 1, 0, "Share")
        pm.menu.add(0, 2, 0, "Open with")
        pm.setOnMenuItemClickListener {
            val t = queue.getOrNull(index) ?: return@setOnMenuItemClickListener true
            when (it.itemId) { 1 -> Util.share(this, t); 2 -> Util.openWith(this, t) }
            true
        }
        pm.show()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                if (locked) return false
                if (e.x < video.width / 2) { seekBy(-10000); Util.toast(this@PlayerActivity, "⏪ 10s") }
                else { seekBy(10000); Util.toast(this@PlayerActivity, "10s ⏩") }
                return true
            }
            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (locked) return true
                setControls(controls.visibility != View.VISIBLE)
                return true
            }
        })
        video.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
    }

    private fun playCurrent() {
        val t = queue[index]
        val audio = (t.mime ?: "").startsWith("audio/") || t.kind == "audio"
        title.text = if (queue.size > 1) "${index + 1}/${queue.size}  •  ${t.title}" else t.title
        title.isSelected = true
        art.visibility = if (audio) View.VISIBLE else View.GONE
        if (audio) art.bringToFront()
        video.setVideoURI(Uri.parse(t.fileUri))
    }

    private fun fmt(ms: Int): String {
        if (ms <= 0) return "00:00"
        val s = ms / 1000; val h = s / 3600; val m = (s % 3600) / 60; val sec = s % 60
        return if (h > 0) String.format("%d:%02d:%02d", h, m, sec) else String.format("%02d:%02d", m, sec)
    }

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized) { pos = video.currentPosition; video.pause() }
        ui.removeCallbacks(tick)
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onDestroy() {
        super.onDestroy()
        ui.removeCallbacksAndMessages(null)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pos", pos)
        outState.putInt("index", index)
    }
}
