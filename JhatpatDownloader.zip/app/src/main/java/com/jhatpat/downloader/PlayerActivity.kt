package com.jhatpat.downloader

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

/** Jhatpat ka apna video / MP3 player (Playlist bhi chalata hai) */
class PlayerActivity : AppCompatActivity() {
    private lateinit var video: VideoView
    private lateinit var title: TextView
    private lateinit var art: ImageView
    private lateinit var mc: MediaController
    private var pos = 0
    private var queue: List<DTask> = emptyList()
    private var index = 0
    private val brand by lazy { findViewById<android.view.View>(R.id.brand) }

    /** Video chalte hi 4 second ke liye "Jhatpat Downloader" dikhao, phir gayab */
    private fun showBrand() {
        brand.clearAnimation()
        brand.visibility = android.view.View.VISIBLE
        brand.alpha = 1f
        brand.bringToFront()
        brand.postDelayed({
            brand.animate().alpha(0f).setDuration(600).withEndAction {
                brand.visibility = android.view.View.GONE
            }.start()
        }, 15000)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (Prefs.brightness >= 0) {
            val lp = window.attributes
            lp.screenBrightness = Prefs.brightness.coerceIn(5, 100) / 100f
            window.attributes = lp
        }
        video = findViewById(R.id.video)
        title = findViewById(R.id.tvTitle)
        art = findViewById(R.id.ivArt)
        mc = MediaController(this)
        mc.setAnchorView(video)
        video.setMediaController(mc)

        val ids = intent.getStringArrayListExtra("queue")
        if (ids != null) {
            queue = ids.mapNotNull { DownloadRepo.get(it) }
        } else {
            val uri = intent.getStringExtra("uri")
            if (uri == null) { finish(); return }
            val t = DownloadRepo.all().firstOrNull { it.fileUri == uri }
                ?: DTask("tmp", intent.getStringExtra("title") ?: "", "", null, "video", "", "", null,
                    fileUri = uri, mime = intent.getStringExtra("mime"))
            queue = listOf(t)
        }
        if (queue.isEmpty()) { finish(); return }
        index = savedInstanceState?.getInt("index", 0) ?: 0
        pos = savedInstanceState?.getInt("pos", 0) ?: 0

        setupGestures()

        video.setOnPreparedListener {
            if (pos > 0) video.seekTo(pos)
            if (Prefs.autoPlay || queue.size > 1) video.start()
            mc.show(3000)
            showBrand()
        }
        video.setOnCompletionListener {
            if (index < queue.size - 1) { index++; pos = 0; playCurrent() }
        }
        video.setOnErrorListener { _, _, _ ->
            Util.toast(this, "Yeh file yahan nahi chali, dusre player me khul rahi hai")
            Util.openWith(this, queue[index])
            finish(); true
        }
        playCurrent()
    }

    /** Double-tap: left = 10s peeche, right = 10s aage (Vidmate/YouTube jaisa) */
    @android.annotation.SuppressLint("ClickableViewAccessibility")
    private fun setupGestures() {
        val gd = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: android.view.MotionEvent): Boolean {
                if (!video.isPlaying && video.currentPosition <= 0) return false
                val mid = video.width / 2
                val cur = video.currentPosition
                if (e.x < mid) {
                    video.seekTo((cur - 10000).coerceAtLeast(0))
                    Util.toast(this@PlayerActivity, "⏪ 10s")
                } else {
                    val dur = video.duration
                    video.seekTo(if (dur > 0) (cur + 10000).coerceAtMost(dur) else cur + 10000)
                    Util.toast(this@PlayerActivity, "10s ⏩")
                }
                return true
            }
            override fun onSingleTapConfirmed(e: android.view.MotionEvent): Boolean {
                if (mc.isShowing) mc.hide() else mc.show(3000)
                return true
            }
        })
        video.setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
    }

    private fun playCurrent() {
        val t = queue[index]
        val audio = (t.mime ?: "").startsWith("audio/") || t.kind == "audio"
        title.text = if (queue.size > 1) "${index + 1}/${queue.size}  •  ${t.title}" else t.title
        art.visibility = if (audio) View.VISIBLE else View.GONE
        if (audio) { art.bringToFront(); title.bringToFront() }
        video.setVideoURI(Uri.parse(t.fileUri))
    }

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized) { pos = video.currentPosition; video.pause() }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pos", pos)
        outState.putInt("index", index)
    }
}
