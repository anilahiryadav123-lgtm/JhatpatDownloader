package com.jhatpat.downloader

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.widget.ImageView
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/** Download hui video file se asli photo (frame) nikal kar dikhata hai */
object VideoThumbs {
    private val cache = ConcurrentHashMap<String, Bitmap>()
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, t: DTask, iv: ImageView) {
        val key = t.id
        iv.tag = key
        cache[key]?.let { iv.setImageBitmap(it); return }
        val isVideo = (t.mime ?: "").startsWith("video") || t.kind == "video"
        if (!isVideo) return
        val uri = t.fileUri ?: t.filePath ?: return
        pool.execute {
            try {
                val mmr = MediaMetadataRetriever()
                if (uri.startsWith("content://")) mmr.setDataSource(ctx, Uri.parse(uri))
                else mmr.setDataSource(uri)
                var bmp = mmr.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: mmr.frameAtTime
                try { mmr.release() } catch (_: Exception) {}
                if (bmp != null) {
                    // Memory bachao - chhota kar lo
                    val maxW = 400
                    if (bmp.width > maxW) {
                        val h = (bmp.height * maxW / bmp.width.toFloat()).toInt().coerceAtLeast(1)
                        bmp = Bitmap.createScaledBitmap(bmp, maxW, h, true)
                    }
                    cache[key] = bmp
                    val fb = bmp
                    main.post { if (iv.tag == key) iv.setImageBitmap(fb) }
                }
            } catch (_: Exception) { }
        }
    }
}
