package com.jhatpat.downloader

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.PopupMenu
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout

/** Vidmate jaisa My Files: Downloads / Videos / Music / 🔒 Private + select, Hide, Delete */
class MyFilesActivity : BaseActivity() {

    private var tab = 0
    private var items: List<DTask> = emptyList()
    private val selected = LinkedHashSet<String>()
    private var selecting = false
    private lateinit var adapter: FileAdapter
    private val listener: () -> Unit = { refresh() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_myfiles)
        tab = intent.getIntExtra("tab", 0)

        val tabs = findViewById<TabLayout>(R.id.tabs)
        listOf("Downloads", "Videos", "Music", "Private").forEach { tabs.addTab(tabs.newTab().setText(it)) }
        // Private tab par saaf gold lock icon (emoji nahi)
        tabs.getTabAt(3)?.apply {
            setIcon(R.drawable.ic_lock)
            icon?.setTint(0xFFFFC400.toInt())
        }
        tabs.getTabAt(tab)?.select()
        tabs.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(t: TabLayout.Tab?) { tab = t?.position ?: 0; exitSelect(); refresh() }
            override fun onTabUnselected(t: TabLayout.Tab?) {}
            override fun onTabReselected(t: TabLayout.Tab?) {}
        })

        val rv = findViewById<RecyclerView>(R.id.rvFiles)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter()
        rv.adapter = adapter
        rv.itemAnimator = null

        // Ungli se left/right swipe -> Downloads/Videos/Music/Private ke beech jao
        val swipe = android.view.GestureDetector(this, object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: android.view.MotionEvent?, e2: android.view.MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dx = e2.x - e1.x; val dy = e2.y - e1.y
                if (Math.abs(dx) > 120 && Math.abs(dx) > Math.abs(dy) * 1.6 && Math.abs(vx) > 250) {
                    val next = if (dx < 0) tab + 1 else tab - 1   // left=next, right=prev
                    if (next in 0..3) { tabs.getTabAt(next)?.select(); return true }
                }
                return false
            }
        })
        rv.addOnItemTouchListener(object : RecyclerView.OnItemTouchListener {
            override fun onInterceptTouchEvent(r: RecyclerView, e: android.view.MotionEvent): Boolean { swipe.onTouchEvent(e); return false }
            override fun onTouchEvent(r: RecyclerView, e: android.view.MotionEvent) { swipe.onTouchEvent(e) }
            override fun onRequestDisallowInterceptTouchEvent(d: Boolean) {}
        })

        findViewById<View>(R.id.btnBack).setOnClickListener { onBackPressedDispatcher.onBackPressed() }
        findViewById<View>(R.id.btnSelect).setOnClickListener { if (selecting) exitSelect() else startSelect(null) }
        findViewById<TextView>(R.id.btnSelectAll).setOnClickListener {
            if (selected.size == items.size) selected.clear() else { selected.clear(); selected.addAll(items.map { it.id }) }
            updateBars()
        }
        findViewById<View>(R.id.actHide).setOnClickListener { hideOrUnhide() }
        findViewById<View>(R.id.actDelete).setOnClickListener { deleteSelected() }
        findViewById<View>(R.id.actShare).setOnClickListener { shareSelected() }
        findViewById<View>(R.id.btnLock).setOnClickListener { unlockFlow() }
        findViewById<View>(R.id.btnLockNow).setOnClickListener { Vault.unlocked = false; refresh() }
        findViewById<View>(R.id.btnPrivateSites).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", "private_sites"))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { if (selecting) exitSelect() else finish() }
        })

        intent.getStringExtra("select")?.let { startSelect(it) }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        DownloadRepo.addListener(listener)
        refresh()
    }

    override fun onPause() {
        super.onPause()
        DownloadRepo.removeListener(listener)
    }

    override fun onDestroy() {
        Vault.unlocked = false
        super.onDestroy()
    }

    private fun isAudio(t: DTask) = (t.mime ?: "").startsWith("audio/") || t.kind == "audio"

    private fun refresh() {
        val lock = findViewById<View>(R.id.boxLock)
        val empty = findViewById<TextView>(R.id.tvEmpty)
        val privateTab = tab == 3
        findViewById<View>(R.id.barPrivate).visibility = if (privateTab && Vault.unlocked) View.VISIBLE else View.GONE
        if (privateTab && !Vault.unlocked) {
            lock.visibility = View.VISIBLE
            val set = Vault.hasPin
            findViewById<TextView>(R.id.tvLockTitle).text = if (set) "Private Folder" else "Set Password"
            findViewById<TextView>(R.id.tvLockMsg).text = if (set)
                "Aapki chhupi hui videos yahan hain.\nKholne ke liye password daalein."
            else "Lock videos as private with a 4-digit passcode, only you can access"
            findViewById<TextView>(R.id.btnLock).text = if (set) "UNLOCK" else "SET PASSWORD"
            items = emptyList()
        } else {
            lock.visibility = View.GONE
            val done = DownloadRepo.done()
            items = when (tab) {
                1 -> done.filter { !isAudio(it) }
                2 -> done.filter { isAudio(it) }
                3 -> DownloadRepo.hiddenList()
                else -> done
            }
        }
        selected.retainAll(items.map { it.id }.toSet())
        empty.visibility = if (items.isEmpty() && lock.visibility != View.VISIBLE) View.VISIBLE else View.GONE
        empty.text = if (privateTab) "🔒\nKoi private file nahi.\nDownloads me file chunein → Hide" else "📂\nKoi file nahi"
        adapter.notifyDataSetChanged()
        updateBars()
    }

    private fun unlockFlow() {
        PinDialog(this, if (Vault.hasPin) "check" else "set") { refresh() }.show()
    }

    private fun startSelect(firstId: String?) {
        selecting = true
        selected.clear()
        firstId?.let { selected.add(it) }
        updateBars()
    }

    private fun exitSelect() {
        selecting = false
        selected.clear()
        updateBars()
    }

    private fun updateBars() {
        findViewById<View>(R.id.barActions).visibility = if (selecting) View.VISIBLE else View.GONE
        val sa = findViewById<TextView>(R.id.btnSelectAll)
        sa.visibility = if (selecting) View.VISIBLE else View.GONE
        sa.text = if (selected.size == items.size && items.isNotEmpty()) "Unselect" else "Select all"
        findViewById<TextView>(R.id.tvTitle).text = if (selecting) "${selected.size} selected" else Lang.t("my_files")
        val unhide = tab == 3
        findViewById<TextView>(R.id.tvHide).text = if (unhide) "Unhide" else "Hide"
        findViewById<ImageView>(R.id.ivHide).setImageResource(if (unhide) R.drawable.ic_unlock else R.drawable.ic_lock)
        adapter.notifyDataSetChanged()
    }

    private fun chosen() = items.filter { it.id in selected }

    private fun hideOrUnhide() {
        val list = chosen()
        if (list.isEmpty()) return Util.toast(this, "Pehle file chunein")
        if (tab == 3) {
            Vault.unhide(this, list) { exitSelect(); refresh() }
            return
        }
        val go = { Vault.hide(this, list) { exitSelect(); refresh() } }
        if (!Vault.hasPin) {
            Util.toast(this, "Pehle Private folder ka password set karein")
            PinDialog(this, "set") { go() }.show()
        } else go()
    }

    private fun deleteSelected() {
        val list = chosen()
        if (list.isEmpty()) return Util.toast(this, "Pehle file chunein")
        AlertDialog.Builder(this)
            .setTitle("${list.size} file delete karein?")
            .setMessage("Yeh phone se hamesha ke liye hat jayengi.")
            .setPositiveButton(Lang.t("delete")) { _, _ ->
                list.forEach { Util.deleteFile(this, it); DownloadRepo.remove(it.id) }
                exitSelect(); refresh()
            }
            .setNegativeButton(Lang.t("cancel"), null).show()
    }

    private fun shareSelected() {
        val uris = ArrayList(chosen().mapNotNull { Util.shareUri(this, it) })
        if (uris.isEmpty()) return Util.toast(this, "Pehle file chunein")
        val i = Intent(Intent.ACTION_SEND_MULTIPLE).setType("*/*")
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(uris))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, Lang.t("share")))
    }

    private fun itemMenu(v: View, t: DTask) {
        val pm = PopupMenu(this, v)
        pm.menu.add(0, 1, 0, "Play")
        pm.menu.add(0, 2, 0, Lang.t("share"))
        pm.menu.add(0, 3, 0, if (t.hidden) "Unhide" else "Hide").apply {
            setIcon(if (t.hidden) R.drawable.ic_unlock else R.drawable.ic_lock)
            icon?.setTint(0xFFFFC400.toInt())
        }
        pm.menu.add(0, 4, 0, Lang.t("delete"))
        pm.menu.add(0, 5, 0, "Select")
        try { pm.setForceShowIcon(true) } catch (_: Throwable) {}
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> Util.play(this, t)
                2 -> Util.share(this, t)
                3 -> { selected.clear(); selected.add(t.id); hideOrUnhide() }
                4 -> { selected.clear(); selected.add(t.id); deleteSelected() }
                5 -> startSelect(t.id)
            }
            true
        }
        pm.show()
    }

    inner class FileAdapter : RecyclerView.Adapter<FileAdapter.VH>() {
        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val check: ImageView = v.findViewById(R.id.ivCheck)
            val thumb: ImageView = v.findViewById(R.id.ivThumb)
            val badge: TextView = v.findViewById(R.id.tvBadge)
            val locked: ImageView = v.findViewById(R.id.ivLocked)
            val title: TextView = v.findViewById(R.id.tvTitle)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val more: View = v.findViewById(R.id.btnMore)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_file, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            h.title.text = t.title
            h.badge.text = t.label
            h.locked.visibility = if (t.hidden) View.VISIBLE else View.GONE
            if (h.thumb.tag != t.thumb) ImageLoader.load(t.thumb, h.thumb)
            h.meta.text = "${Util.size(t.size)}  •  ${if (t.hidden) "Private" else t.filePath?.substringBeforeLast('/')?.substringAfterLast('/') ?: ""}"
            h.check.visibility = if (selecting) View.VISIBLE else View.GONE
            h.check.setImageResource(if (t.id in selected) R.drawable.check_on else R.drawable.check_off)
            h.more.visibility = if (selecting) View.GONE else View.VISIBLE
            h.itemView.setOnClickListener {
                if (selecting) {
                    if (!selected.remove(t.id)) selected.add(t.id)
                    updateBars()
                } else Util.play(this@MyFilesActivity, t)
            }
            h.itemView.setOnLongClickListener {
                if (!selecting) startSelect(t.id) else { if (!selected.remove(t.id)) selected.add(t.id); updateBars() }
                true
            }
            h.more.setOnClickListener { v -> itemMenu(v, t) }
        }
    }
}
