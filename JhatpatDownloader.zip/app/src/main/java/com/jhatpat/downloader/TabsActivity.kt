package com.jhatpat.downloader

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

/** Multi-tab overview: Grid / List / Carousel me saare khule tabs */
class TabsActivity : BaseActivity() {

    private lateinit var rv: RecyclerView
    private lateinit var tvTitle: TextView
    private val toggles = HashMap<Int, ImageView>()
    private var mode = 0  // 0 Grid, 1 List, 2 Carousel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        mode = Prefs.tabView
        if (Tabs.list.isEmpty()) { openNewTab(); return }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(getColor(R.color.bg))
            fitsSystemWindows = true
        }

        // ---- Top bar ----
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(10), dp(12))
            setBackgroundColor(getColor(R.color.surface))
        }
        tvTitle = TextView(this).apply {
            text = "Tabs (${Tabs.count()})"; textSize = 19f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(getColor(R.color.text))
        }
        top.addView(tvTitle, LinearLayout.LayoutParams(0, -2, 1f))
        top.addView(toggle(0, R.drawable.ic_grid))
        top.addView(toggle(1, R.drawable.ic_list))
        top.addView(toggle(2, R.drawable.ic_carousel))
        top.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_close)
            imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text))
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { backToBrowser() }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        // ---- Tab list ----
        rv = RecyclerView(this).apply { setPadding(dp(8), dp(8), dp(8), dp(8)); clipToPadding = false }
        root.addView(rv, LinearLayout.LayoutParams(-1, 0, 1f))

        // ---- Bottom: New tab ----
        val newBtn = TextView(this).apply {
            text = "＋  New tab"; textSize = 16f; setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(0, dp(15), 0, dp(15))
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(attrColor(R.attr.jpAccent2)) }
            setOnClickListener { openNewTab() }
        }
        val wrap = LinearLayout(this).apply { setPadding(dp(14), dp(6), dp(14), dp(16)); setBackgroundColor(getColor(R.color.surface)) }
        wrap.addView(newBtn, LinearLayout.LayoutParams(-1, -2))
        root.addView(wrap, LinearLayout.LayoutParams(-1, -2))

        setContentView(root)
        applyMode()
    }

    private fun toggle(m: Int, icon: Int): ImageView {
        val iv = ImageView(this).apply {
            setImageResource(icon)
            setPadding(dp(8), dp(8), dp(8), dp(8))
            setOnClickListener { mode = m; Prefs.tabView = m; applyMode() }
        }
        toggles[m] = iv
        return iv.also { it.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(2) } }
    }

    private fun applyMode() {
        toggles.forEach { (m, iv) ->
            val on = m == mode
            iv.imageTintList = android.content.res.ColorStateList.valueOf(if (on) attrColor(R.attr.jpAccent2) else getColor(R.color.text2))
            iv.background = if (on) GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(getColor(R.color.surface2)) } else null
        }
        rv.layoutManager = when (mode) {
            1 -> LinearLayoutManager(this)
            2 -> LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            else -> GridLayoutManager(this, 2)
        }
        rv.adapter = TabAdapter()
        tvTitle.text = "Tabs (${Tabs.count()})"
    }

    private fun openNewTab() {
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("q", "https://www.google.com")
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun openTab(t: Tabs.Tab) {
        Tabs.setCurrent(t.id)
        startActivity(Intent(this, BrowserActivity::class.java)
            .putExtra("tabId", t.id).putExtra("q", t.url)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        finish()
    }

    private fun backToBrowser() {
        val cur = Tabs.get(Tabs.currentId) ?: Tabs.list.lastOrNull()
        if (cur != null) openTab(cur) else openNewTab()
    }

    override fun onBackPressed() { backToBrowser() }

    inner class TabAdapter : RecyclerView.Adapter<TabAdapter.VH>() {
        inner class VH(val card: View, val thumb: ImageView, val title: TextView, val url: TextView, val close: View) :
            RecyclerView.ViewHolder(card)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH = build()

        private fun build(): VH {
            val list = mode == 1
            val card = LinearLayout(this@TabsActivity).apply {
                orientation = if (list) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                gravity = if (list) Gravity.CENTER_VERTICAL else Gravity.TOP
                background = GradientDrawable().apply { cornerRadius = dp(14).toFloat(); setColor(getColor(R.color.surface)); setStroke(dp(1), getColor(R.color.stroke)) }
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }
            val thumb = ImageView(this@TabsActivity).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                background = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(getColor(R.color.surface2)) }
            }
            val texts = LinearLayout(this@TabsActivity).apply { orientation = LinearLayout.VERTICAL }
            val title = TextView(this@TabsActivity).apply {
                textSize = 13.5f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                setTypeface(typeface, Typeface.BOLD); setTextColor(getColor(R.color.text))
            }
            val url = TextView(this@TabsActivity).apply {
                textSize = 11f; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(getColor(R.color.text2))
            }
            val close = ImageView(this@TabsActivity).apply {
                setImageResource(R.drawable.ic_close)
                imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text2))
                setPadding(dp(5), dp(5), dp(5), dp(5))
            }

            if (list) {
                card.addView(thumb, LinearLayout.LayoutParams(dp(92), dp(60)).apply { marginEnd = dp(12) })
                texts.addView(title); texts.addView(url)
                card.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(close, LinearLayout.LayoutParams(dp(32), dp(32)))
            } else {
                val carousel = mode == 2
                val tw = if (carousel) dp(190) else -1
                val th = if (carousel) dp(150) else dp(120)
                card.addView(thumb, LinearLayout.LayoutParams(tw, th))
                val bottom = LinearLayout(this@TabsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
                texts.addView(title); texts.addView(url)
                bottom.addView(texts, LinearLayout.LayoutParams(0, -2, 1f).apply { topMargin = dp(8) })
                bottom.addView(close, LinearLayout.LayoutParams(dp(30), dp(30)))
                card.addView(bottom, LinearLayout.LayoutParams(-1, -2))
            }

            val lp = if (mode == 2)
                RecyclerView.LayoutParams(dp(206), ViewGroup.LayoutParams.WRAP_CONTENT)
            else
                RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(dp(6), dp(6), dp(6), dp(6))
            card.layoutParams = lp
            return VH(card, thumb, title, url, close)
        }

        override fun getItemCount() = Tabs.list.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val t = Tabs.list[position]
            h.title.text = t.title.ifBlank { "New tab" }
            h.url.text = try { android.net.Uri.parse(t.url).host ?: t.url } catch (e: Exception) { t.url }
            if (t.thumb != null) h.thumb.setImageBitmap(t.thumb) else h.thumb.setImageDrawable(null)
            h.card.setOnClickListener { openTab(t) }
            h.close.setOnClickListener {
                Tabs.close(t.id)
                if (Tabs.list.isEmpty()) openNewTab()
                else { applyMode() }
            }
        }
    }
}
