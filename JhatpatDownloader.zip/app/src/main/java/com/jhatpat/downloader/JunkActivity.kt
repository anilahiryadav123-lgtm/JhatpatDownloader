package com.jhatpat.downloader

import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

/** Vidmate jaisa "Junk files" screen - scan, categories, Clean junk button */
class JunkActivity : AppCompatActivity() {

    data class Junk(val name: String, val size: Long, val path: File?, var checked: Boolean = true, val header: String? = null)

    private val items = ArrayList<Junk>()
    private lateinit var adapter: JunkAdapter
    private val main = Handler(Looper.getMainLooper())
    private var total = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_junk)
        window.statusBarColor = getColor(R.color.junk_orange)
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }

        val rv = findViewById<RecyclerView>(R.id.rvJunk)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = JunkAdapter()
        rv.adapter = adapter

        findViewById<View>(R.id.btnClean).setOnClickListener { clean() }
        scan()
    }

    private fun scan() {
        val tvScan = findViewById<TextView>(R.id.tvScan)
        Thread {
            val found = ArrayList<Junk>()
            val cacheDirs = listOfNotNull(cacheDir, externalCacheDir)
            var cacheTotal = 0L
            val cacheChildren = ArrayList<Junk>()
            cacheDirs.forEach { d ->
                d.listFiles()?.forEach { f ->
                    val sz = dirSize(f)
                    if (sz > 0) { cacheChildren.add(Junk(f.absolutePath, sz, f)); cacheTotal += sz }
                    main.post { tvScan.text = "Scanning: ${f.absolutePath}" }
                    Thread.sleep(8)
                }
            }
            // Temp (adhure download tukde jo active nahi)
            val tmp = File(getExternalFilesDir(null) ?: filesDir, "tmp")
            val active = DownloadRepo.all().filter { it.status != DTask.DONE }.map { it.id }.toSet()
            var tmpTotal = 0L
            val tmpChildren = ArrayList<Junk>()
            tmp.listFiles()?.forEach { f ->
                if (f.name !in active) {
                    val sz = dirSize(f)
                    if (sz > 0) { tmpChildren.add(Junk(f.absolutePath, sz, f)); tmpTotal += sz }
                }
            }
            found.add(Junk("Cache junk", cacheTotal, null, header = "cache"))
            found.addAll(cacheChildren)
            found.add(Junk("Temporary files", tmpTotal, null, header = "temp"))
            found.addAll(tmpChildren)
            val sum = cacheTotal + tmpTotal

            main.post {
                items.clear(); items.addAll(found); total = sum
                adapter.notifyDataSetChanged()
                tvScan.visibility = View.GONE
                animateTotal(sum)
                updateCleanBtn()
            }
        }.start()
    }

    private fun animateTotal(bytes: Long) {
        val mb = (bytes / (1024.0 * 1024.0))
        val tvTotal = findViewById<TextView>(R.id.tvTotal)
        val tvUnit = findViewById<TextView>(R.id.tvUnit)
        val (value, unit) = if (mb >= 1024) (mb / 1024) to "GB" else mb to "MB"
        ValueAnimator.ofFloat(0f, value.toFloat()).apply {
            duration = 1000
            addUpdateListener {
                val v = it.animatedValue as Float
                tvTotal.text = if (unit == "GB") String.format("%.1f", v) else v.toInt().toString()
                tvUnit.text = unit
            }
            start()
        }
    }

    private fun checkedBytes(): Long = items.filter { it.header == null && it.checked }.sumOf { it.size }

    private fun updateCleanBtn() {
        findViewById<TextView>(R.id.btnClean).text = "Clean junk ${Util.size(checkedBytes()).ifBlank { "0 KB" }}"
    }

    private fun clean() {
        val toDelete = items.filter { it.header == null && it.checked && it.path != null }
        if (toDelete.isEmpty()) { Util.toast(this, "Kuch nahi chuna"); return }
        val freed = toDelete.sumOf { it.size }
        Thread { toDelete.forEach { it.path?.deleteRecursively() } }.start()
        startActivity(android.content.Intent(this, BoostActivity::class.java))
        Util.toast(this, "✓ ${Util.size(freed)} saaf hua")
        finish()
    }

    private fun dirSize(f: File): Long = if (f.isDirectory) (f.listFiles()?.sumOf { dirSize(it) } ?: 0L) else f.length()

    inner class JunkAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
        override fun getItemViewType(position: Int) = if (items[position].header != null) 0 else 1

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_junk, p, false)) {}

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
            val jk = items[pos]
            val v = h.itemView
            val icon = v.findViewById<ImageView>(R.id.ivIcon)
            val name = v.findViewById<TextView>(R.id.tvName)
            val size = v.findViewById<TextView>(R.id.tvSize)
            val check = v.findViewById<ImageView>(R.id.ivCheck)
            name.text = if (jk.header == null) jk.name.replace(filesDir.parent ?: "", "") else jk.name
            size.text = Util.size(jk.size)
            if (jk.header != null) {
                name.textSize = 17f; name.setTextColor(getColor(R.color.text))
                icon.setImageResource(if (jk.header == "cache") R.drawable.ic_delete else R.drawable.ic_history)
                icon.imageTintList = ColorStateList.valueOf(if (jk.header == "cache") getColor(R.color.junk_red) else 0xFF2979FF.toInt())
                icon.setPadding(dp(5), dp(5), dp(5), dp(5))
                icon.background = android.graphics.drawable.GradientDrawable().apply {
                    shape = android.graphics.drawable.GradientDrawable.OVAL
                    setColor(0x22000000)
                }
            } else {
                name.textSize = 13f; name.setTextColor(getColor(R.color.text2))
                icon.setImageResource(R.drawable.ic_folder)
                icon.imageTintList = ColorStateList.valueOf(0xFFFFB300.toInt())
                icon.background = null
            }
            check.setImageResource(if (jk.checked) R.drawable.check_on else R.drawable.check_off)
            v.setOnClickListener {
                jk.checked = !jk.checked
                adapter.notifyDataSetChanged(); updateCleanBtn()
            }
        }
    }
}
