package com.jhatpat.downloader

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AppCompatActivity

/** App khulte hi Jhatpat Downloader ka logo (VidMate jaisa splash) */
@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        theme.applyStyle(Themes.current().style, true)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // Engine ko peeche se taiyaar karo taaki pehli download jaldi khule
        Engine.initAsync(this)

        val logo = findViewById<View>(R.id.ivLogo)
        logo.scaleX = 0.7f; logo.scaleY = 0.7f; logo.alpha = 0f
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(500).start()

        Handler(Looper.getMainLooper()).postDelayed({
            if (isFinishing) return@postDelayed
            val next = if (Prefs.onboarded) MainActivity::class.java else OnboardingActivity::class.java
            startActivity(Intent(this, next).apply {
                if (intent.action == Intent.ACTION_SEND) {
                    action = Intent.ACTION_SEND
                    putExtras(intent)
                }
            })
            finish()
        }, 1300)
    }
}
