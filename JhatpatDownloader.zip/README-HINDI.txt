JHATPAT DOWNLOADER - APK kaise banayein (sirf phone se, free)
=============================================================

1) github.com par login karein -> "+" -> New repository
   Naam: JhatpatDownloader  -> Public -> Create

2) "Add file" -> "Upload files" -> JhatpatDownloader.zip upload karein -> Commit

3) "Add file" -> "Create new file"
   Naam me likhein:   .github/workflows/build.yml
   Andar build.yml ka poora text paste karein -> Commit

4) "Actions" tab kholein -> build chalega (8-15 minute)
   Hara (green) tick aaye to -> repo ke "Releases" me jaayein
   - JhatpatDownloader-arm64.apk        -> naye phone (zyadatar yahi)
   - JhatpatDownloader-old-phones.apk   -> purane 32-bit phone

5) APK install karein ("Unknown apps" allow karein)

APP KAISE CHALAYEIN
- Home par YouTube / Google / Instagram... kholein
- Video chalayein -> laal "Download" button (neeche) ya video ke neeche
  "Jhatpat Download" button dabayein -> quality chunein (144p - 4K / MP3)
- YouTube app me: Share -> Jhatpat Downloader
- Link copy karke: Home -> "Link Paste karke Download"
- Files: Movies/JhatpatDownloader aur Music/JhatpatDownloader (Gallery me dikhengi)
- Pehli baar app kholne par engine set hone me 10-20 sec lagte hain.
- YouTube kaam na kare to: Me -> "Engine Update karein"

Note: Aisa app Play Store par allowed nahi hota (Vidmate/Snaptube bhi nahi hain).
Sirf apne ya permission wale videos download karein.
