package com.jhatpat.downloader

import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog

/** Vidmate jaisa quality chunne wala niche se khulne wala panel */
class DownloadSheet(private val act: Activity) {

    private val dialog = BottomSheetDialog(act)
    private val root: View = LayoutInflater.from(act).inflate(R.layout.sheet_download, null)
    private val ivThumb: ImageView = root.findViewById(R.id.ivThumb)
    private val tvTitle: TextView = root.findViewById(R.id.tvTitle)
    private val tvMeta: TextView = root.findViewById(R.id.tvMeta)
    private val boxLoading: View = root.findViewById(R.id.boxLoading)
    private val boxError: View = root.findViewById(R.id.boxError)
    private val tvError: TextView = root.findViewById(R.id.tvError)
    private val boxOptions: LinearLayout = root.findViewById(R.id.boxOptions)
    private var sniffed: List<String> = emptyList()

    init {
        dialog.setContentView(root)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.behavior.skipCollapsed = true
    }

    fun show(url: String, pageTitle: String? = null, sniffedMedia: List<String> = emptyList()) {
        sniffed = sniffedMedia
        if (!pageTitle.isNullOrBlank()) tvTitle.text = pageTitle
        tvMeta.text = url
        root.findViewById<View>(R.id.btnRetry).setOnClickListener { load(url) }
        dialog.show()
        load(url)
    }

    private fun load(url: String) {
        boxLoading.visibility = View.VISIBLE
        boxError.visibility = View.GONE
        boxOptions.removeAllViews()
        Thread {
            try {
                val info = Engine.analyze(act, url)
                act.runOnUiThread { if (!act.isFinishing) showInfo(info) }
            } catch (e: Throwable) {
                val msg = (e.message ?: e.toString()).lines().lastOrNull { it.contains("ERROR") }
                    ?: (e.message ?: e.toString()).lines().firstOrNull { it.isNotBlank() } ?: "Error"
                act.runOnUiThread { if (!act.isFinishing) showError(msg.replace("ERROR:", "").trim()) }
            }
        }.start()
    }

    private fun showInfo(info: MediaInfo) {
        boxLoading.visibility = View.GONE
        tvTitle.text = info.title
        val meta = listOfNotNull(
            info.site,
            info.uploader,
            Util.duration(info.duration).ifBlank { null }
        ).joinToString("  •  ")
        tvMeta.text = meta
        ImageLoader.load(info.thumb, ivThumb)

        addHeader("🎬  Video")
        info.options.filter { it.kind == "video" }.forEach { addOption(info, it) }
        addHeader("🎵  Audio")
        info.options.filter { it.kind == "audio" }.forEach { addOption(info, it) }
        addSniffed(info.title)
    }

    private fun showError(msg: String) {
        boxLoading.visibility = View.GONE
        if (sniffed.isNotEmpty()) {
            tvTitle.text = "Page par video mile"
            tvMeta.text = "Neeche se chunein"
            addSniffed("Video")
            return
        }
        boxError.visibility = View.VISIBLE
        tvError.text = "Is page par download wala video nahi mila.\nVideo wale page par jaakar (video chalakar) try karein.\n\n($msg)"
    }

    private fun addSniffed(title: String) {
        if (sniffed.isEmpty()) return
        addHeader("🔎  Page par mile videos")
        sniffed.take(8).forEachIndexed { i, u ->
            val ext = u.substringBefore('?').substringAfterLast('.', "mp4").take(4).uppercase()
            val info = MediaInfo(u, "$title ${i + 1}", null, 0, null, "Web", emptyList())
            addOption(info, DlOption("Video ${i + 1}", ext, "video", "b", null, 0))
        }
    }

    private fun addHeader(text: String) {
        val tv = TextView(act)
        tv.text = text
        tv.setTextColor(act.getColor(R.color.yellow))
        tv.textSize = 15f
        tv.setPadding(4, 18, 4, 10)
        tv.paint.isFakeBoldText = true
        boxOptions.addView(tv)
    }

    private fun addOption(info: MediaInfo, opt: DlOption) {
        val v = LayoutInflater.from(act).inflate(R.layout.item_option, boxOptions, false)
        v.findViewById<ImageView>(R.id.ivKind).setImageResource(if (opt.kind == "audio") R.drawable.ic_music else R.drawable.ic_video)
        v.findViewById<TextView>(R.id.tvLabel).text = opt.label
        val badge = v.findViewById<TextView>(R.id.tvBadge)
        if (opt.badge.isBlank()) badge.visibility = View.GONE else badge.text = opt.badge
        v.findViewById<TextView>(R.id.tvSize).text = Util.size(opt.sizeBytes).let { if (it.isBlank()) "" else "~$it" }
        v.setOnClickListener {
            DownloadService.enqueue(act, info, opt)
            dialog.dismiss()
        }
        boxOptions.addView(v)
    }
}
