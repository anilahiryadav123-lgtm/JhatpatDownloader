package com.jhatpat.downloader

data class Song(val title: String, val artist: String) {
    /** YouTube par is gaane ka search */
    val searchUrl: String
        get() = "https://m.youtube.com/results?search_query=" +
            android.net.Uri.encode("$title $artist song")
    val art: String get() = title.take(1).uppercase()
}

/** Jhatpat ka apna gaano ka catalog (display + search) */
object MusicCatalog {
    val songs = listOf(
        Song("Kesariya", "Arijit Singh"),
        Song("Tum Hi Ho", "Arijit Singh"),
        Song("Channa Mereya", "Arijit Singh"),
        Song("Raataan Lambiyan", "Jubin Nautiyal"),
        Song("Lut Gaye", "Jubin Nautiyal"),
        Song("Tum Mile", "Neha Kakkar"),
        Song("Kala Chashma", "Badshah"),
        Song("Genda Phool", "Badshah"),
        Song("Paani Paani", "Badshah"),
        Song("Brown Rang", "Yo Yo Honey Singh"),
        Song("Blue Eyes", "Yo Yo Honey Singh"),
        Song("Desi Kalakaar", "Yo Yo Honey Singh"),
        Song("Lahore", "Guru Randhawa"),
        Song("Suit Suit", "Guru Randhawa"),
        Song("High Rated Gabru", "Guru Randhawa"),
        Song("Ve Maahi", "Arijit Singh"),
        Song("Shayad", "Arijit Singh"),
        Song("Tera Ban Jaunga", "Akhil Sachdeva"),
        Song("Bekhayali", "Sachet Tandon"),
        Song("Tujhe Kitna Chahne Lage", "Arijit Singh"),
        Song("Dil Diyan Gallan", "Atif Aslam"),
        Song("Tera Hone Laga Hoon", "Atif Aslam"),
        Song("Tu Jaane Na", "Atif Aslam"),
        Song("Pehla Nasha", "Udit Narayan"),
        Song("Tum Se Hi", "Mohit Chauhan"),
        Song("Kabira", "Tochi Raina"),
        Song("Ilahi", "Arijit Singh"),
        Song("Phir Le Aya Dil", "Arijit Singh"),
        Song("Agar Tum Saath Ho", "Alka Yagnik"),
        Song("Gerua", "Arijit Singh"),
        Song("Janam Janam", "Arijit Singh"),
        Song("Hawayein", "Arijit Singh"),
        Song("Ae Dil Hai Mushkil", "Arijit Singh"),
        Song("Enna Sona", "Arijit Singh"),
        Song("Humdard", "Arijit Singh"),
        Song("Samjhawan", "Arijit Singh"),
        Song("Sunn Raha Hai", "Ankit Tiwari"),
        Song("Galliyan", "Ankit Tiwari"),
        Song("Baarish", "Ash King"),
        Song("Zaroori Tha", "Rahat Fateh Ali Khan"),
        Song("O Rangrez", "Javed Bashir"),
        Song("Jeene Laga Hoon", "Atif Aslam"),
        Song("Mann Mera", "Gajendra Verma"),
        Song("Tera Ghata", "Gajendra Verma"),
        Song("Tujhe Bhula Diya", "Mohit Chauhan"),
        Song("Phir Bhi Tumko Chaahunga", "Arijit Singh"),
        Song("Humnava Mere", "Jubin Nautiyal"),
        Song("Tum Hi Aana", "Jubin Nautiyal"),
        Song("Dil Galti Kar Baitha Hai", "Jubin Nautiyal"),
        Song("Barsaat Ki Dhun", "Jubin Nautiyal"),
        Song("Chahun Main Ya Naa", "Arijit Singh"),
        Song("Mann Bharrya", "B Praak"),
        Song("Filhaal", "B Praak"),
        Song("Dil Tod Ke", "B Praak"),
        Song("Pachtaoge", "Arijit Singh"),
        Song("Bewafa Tera Masoom Chehra", "Jubin Nautiyal"),
        Song("Kaun Tujhe", "Palak Muchhal"),
        Song("Hamari Adhuri Kahani", "Arijit Singh"),
        Song("Sanam Re", "Arijit Singh"),
        Song("Main Rang Sharbaton Ka", "Atif Aslam")
    )

    fun search(q: String): List<Song> {
        if (q.isBlank()) return songs
        val t = q.trim().lowercase()
        return songs.filter { it.title.lowercase().contains(t) || it.artist.lowercase().contains(t) }
    }
}
