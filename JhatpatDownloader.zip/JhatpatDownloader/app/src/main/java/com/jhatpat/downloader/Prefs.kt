package com.jhatpat.downloader

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/** App ki saari settings ek jagah */
object Prefs {
    private val p: SharedPreferences get() = App.instance.getSharedPreferences("jp", Context.MODE_PRIVATE)

    private fun b(k: String, d: Boolean) = p.getBoolean(k, d)
    private fun s(k: String, d: String) = p.getString(k, d) ?: d
    private fun i(k: String, d: Int) = p.getInt(k, d)
    fun put(k: String, v: Any) {
        val e = p.edit()
        when (v) {
            is Boolean -> e.putBoolean(k, v)
            is Int -> e.putInt(k, v)
            is Long -> e.putLong(k, v)
            else -> e.putString(k, v.toString())
        }
        e.apply()
    }

    // Shuruaat
    var onboarded: Boolean get() = b("onboarded", false); set(v) = put("onboarded", v)
    var askedStorage: Boolean get() = b("asked_storage", false); set(v) = put("asked_storage", v)

    // Content
    var lang: String get() = s("lang", "hi"); set(v) = put("lang", v)
    var location: String get() = s("location", "India"); set(v) = put("location", v)
    var filterRecommend: Boolean get() = b("f_rec", true); set(v) = put("f_rec", v)
    var filterBrowsing: Boolean get() = b("f_browse", false); set(v) = put("f_browse", v)
    var filterSearch: Boolean get() = b("f_search", false); set(v) = put("f_search", v)
    var filterSites: Boolean get() = b("f_sites", true); set(v) = put("f_sites", v)

    // Download
    var pathMode: String get() = s("path_mode", "gallery"); set(v) = put("path_mode", v) // gallery | jhatpat | download
    var wifiOnly: Boolean get() = b("wifi_only", false); set(v) = put("wifi_only", v)
    var maxTasks: Int get() = i("parallel", 2); set(v) = put("parallel", v)
    var fastDownload: Boolean get() = b("fast_dl", true); set(v) = put("fast_dl", v)
    var autoResume: String get() = s("auto_resume", "always"); set(v) = put("auto_resume", v) // always | wifi | never
    var subtitle: String get() = s("subtitle", "off"); set(v) = put("subtitle", v) // off | system | en | hi
    var musicQuality: String get() = s("music_q", "medium"); set(v) = put("music_q", v) // low | medium | high
    var clipDetect: Boolean get() = b("clip_detect", true); set(v) = put("clip_detect", v)
    var notifyDone: Boolean get() = b("notify_done", true); set(v) = put("notify_done", v)
    var notifyProgress: Boolean get() = b("notify_progress", true); set(v) = put("notify_progress", v)
    var notifyClip: Boolean get() = b("notify_clip", true); set(v) = put("notify_clip", v)

    // Others
    var playVideoWith: String get() = s("play_video", "jhatpat"); set(v) = put("play_video", v) // jhatpat | other
    var playAudioWith: String get() = s("play_audio", "jhatpat"); set(v) = put("play_audio", v)
    var autoPlay: Boolean get() = b("auto_play", true); set(v) = put("auto_play", v)
    var quickSearch: Boolean get() = b("quick_search", true); set(v) = put("quick_search", v)
    var brightness: Int get() = i("brightness", -1); set(v) = put("brightness", v) // -1 = system
    var theme: String get() = s("theme", "jhatpat"); set(v) = put("theme", v)
    var nightMode: Int get() = i("night", 2); set(v) = put("night", v) // 1 = day, 2 = night, -1 = system

    // Sign in (phone me hi save)
    var userName: String get() = s("user_name", ""); set(v) = put("user_name", v)
    var userContact: String get() = s("user_contact", ""); set(v) = put("user_contact", v)
    val signedIn: Boolean get() = userName.isNotBlank()

    var lastClip: String get() = s("last_clip", ""); set(v) = put("last_clip", v)
    var pinHash: String get() = s("pin_hash", ""); set(v) = put("pin_hash", v)
    var adultOk: Boolean get() = b("adult_ok", false); set(v) = put("adult_ok", v)
    var homeStyle: Int get() = i("home_style", 1); set(v) = put("home_style", v)

    // Private Sites (password ke peeche)
    fun privateSites(): List<JSONObject> = list("private_sites")
    fun addPrivateSite(name: String, url: String) {
        val l = list("private_sites").toMutableList()
        l.add(JSONObject().put("title", name).put("url", url).put("time", System.currentTimeMillis()))
        save("private_sites", l)
    }

    // History & Bookmarks
    fun history(): List<JSONObject> = list("history")
    fun bookmarks(): List<JSONObject> = list("bookmarks")

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:")) return
        val l = list("history").filter { it.optString("url") != url }.toMutableList()
        l.add(0, JSONObject().put("title", title).put("url", url).put("time", System.currentTimeMillis()))
        save("history", l.take(300))
    }

    fun toggleBookmark(title: String, url: String): Boolean {
        val l = list("bookmarks").toMutableList()
        val exists = l.any { it.optString("url") == url }
        if (exists) l.removeAll { it.optString("url") == url }
        else l.add(0, JSONObject().put("title", title).put("url", url).put("time", System.currentTimeMillis()))
        save("bookmarks", l)
        return !exists
    }

    fun isBookmarked(url: String) = list("bookmarks").any { it.optString("url") == url }
    fun clear(key: String) = put(key, "[]")
    fun removeItem(key: String, url: String) = save(key, list(key).filter { it.optString("url") != url })

    private fun list(k: String): List<JSONObject> {
        return try {
            val a = JSONArray(s(k, "[]"))
            (0 until a.length()).map { a.getJSONObject(it) }
        } catch (e: Exception) { emptyList() }
    }

    private fun save(k: String, l: List<JSONObject>) {
        val a = JSONArray(); l.forEach { a.put(it) }; put(k, a.toString())
    }
}
