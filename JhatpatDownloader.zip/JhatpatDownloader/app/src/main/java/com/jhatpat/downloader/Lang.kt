package com.jhatpat.downloader

import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView

data class Language(val code: String, val native: String, val english: String, val color: Int)

/**
 * 15 bhasha. View me android:tag="t:key" (text) ya "h:key" (hint) likho,
 * Lang.apply(view) apne aap sahi bhasha laga deta hai.
 */
object Lang {
    val all = listOf(
        Language("hi", "हिंदी", "Hindi", 0xFFA066D3.toInt()),
        Language("en", "English", "English", 0xFF5267D6.toInt()),
        Language("ta", "தமிழ்", "Tamil", 0xFFEF563D.toInt()),
        Language("te", "తెలుగు", "Telugu", 0xFF41A3E6.toInt()),
        Language("pa", "ਪੰਜਾਬੀ", "Punjabi", 0xFFF8C200.toInt()),
        Language("mr", "मराठी", "Marathi", 0xFF86BC12.toInt()),
        Language("gu", "ગુજરાતી", "Gujarati", 0xFFF07E1C.toInt()),
        Language("ml", "മലയാളം", "Malayalam", 0xFF6A66C2.toInt()),
        Language("bn", "বাংলা", "Bengali", 0xFF06A982.toInt()),
        Language("or", "ଓଡ଼ିଆ", "Odia", 0xFFA866C9.toInt()),
        Language("kn", "ಕನ್ನಡ", "Kannada", 0xFFF07D3C.toInt()),
        Language("as", "অসমীয়া", "Assamese", 0xFF8CBF26.toInt()),
        Language("bho", "भोजपुरी", "Bhojpuri", 0xFFE8574A.toInt()),
        Language("bgc", "हरयाणवी", "Haryanvi", 0xFF33BDD1.toInt()),
        Language("raj", "राजस्थानी", "Rajasthani", 0xFFF5BE14.toInt())
    )

    private val hindiFamily = setOf("bho", "bgc", "raj", "mr")

    fun t(key: String): String {
        val l = Prefs.lang
        S[l]?.get(key)?.let { return it }
        if (l in hindiFamily) S["hi"]?.get(key)?.let { return it }
        return S["en"]?.get(key) ?: key
    }

    fun apply(v: View) {
        val tag = v.tag
        if (tag is String && tag.length > 2 && tag[1] == ':') {
            val k = tag.substring(2)
            when {
                tag.startsWith("t:") && v is TextView -> v.text = t(k)
                tag.startsWith("h:") && v is EditText -> v.hint = t(k)
            }
        }
        if (v is ViewGroup) for (i in 0 until v.childCount) apply(v.getChildAt(i))
    }

    private val S: Map<String, Map<String, String>> = mapOf(
        "en" to mapOf(
            "select_lang" to "Select Language", "skip" to "Skip", "next" to "Next", "start" to "Start",
            "smarter" to "Smarter", "smarter_d" to "Finds videos just for you.",
            "cleaner" to "Cleaner", "cleaner_d" to "No ads, a cleaner download experience",
            "faster" to "Faster", "faster_d" to "Get videos in a flash",
            "home" to "HOME", "downloads" to "DOWNLOADS", "music" to "MUSIC", "me" to "ME",
            "search_hint" to "Search or enter url", "paste_dl" to "Paste link & Download",
            "popular_sites" to "Popular Sites", "sites" to "Sites", "all_sites" to "All Sites",
            "how_title" to "⚡ How to download?",
            "how_body" to "1. Open YouTube or any site\n2. Play the video\n3. Tap the red DOWNLOAD button\n4. Choose quality (144p to 4K, or MP3)\n\nOr in the YouTube app tap Share → Jhatpat Downloader.",
            "made_in_india" to "Made in India 🇮🇳", "recent" to "Recent downloads",
            "downloading" to "Downloading", "completed" to "Completed",
            "empty_dl" to "No downloads yet\nOpen a video from Home and download",
            "finding" to "Finding qualities... (first time 10-20 sec)", "video" to "🎬  Video", "audio" to "🎵  Audio",
            "found_on_page" to "🔎  Videos found on page", "retry" to "Try again",
            "not_found" to "No downloadable video found on this page.\nOpen the video page (play the video) and try again.",
            "download" to "Download", "dl_started" to "Download started",
            "sign_in" to "Sign in", "sign_out" to "Sign out", "my_files" to "My Files", "history" to "History",
            "bookmarks" to "Subscription", "playlist" to "Playlist", "share" to "Share", "theme" to "Theme",
            "update" to "Update", "feedback" to "Feedback", "help" to "Help", "settings" to "Settings",
            "junk_clean" to "Junk Clean", "boost" to "Boost",
            "content" to "Content", "content_d" to "Language, Location, Restricted Mode",
            "download_s" to "Download", "download_d" to "Path, WiFi, Subtitle, etc.",
            "notifications" to "Push Notifications", "notifications_d" to "Progress, Complete, Copied link",
            "widgets" to "Widgets", "widgets_d" to "Quick Actions on home screen",
            "others" to "Others", "others_d" to "Player, Theme, Brightness, Cache",
            "about" to "About Us", "language" to "Language of Jhatpat", "location" to "Location",
            "restricted" to "Restricted Mode",
            "f_rec" to "Recommendations Filter", "f_rec_d" to "Hide adult content in your feed",
            "f_browse" to "Browsing Content Filter", "f_browse_d" to "Block adult pages while browsing",
            "f_search" to "Search Results Filter", "f_search_d" to "Hide adult content in search results (SafeSearch)",
            "f_sites" to "Sites Filter", "f_sites_d" to "Hide adult websites in the app",
            "dl_path" to "Download path setting", "wifi_only" to "Download Only in WiFi", "max_tasks" to "Max download tasks",
            "fast_dl" to "Fast Download Option", "fast_dl_d" to "Multiple connections for one download",
            "auto_resume" to "Auto Resume downloading", "subtitle" to "Download Subtitle", "music_q" to "Download Music Quality",
            "clip_detect" to "Copied Link Detection", "clip_detect_d" to "Show download button after detecting a downloadable link from clipboard",
            "notify_done" to "Download complete notification", "notify_progress" to "Download progress notification",
            "notify_clip" to "Copied link notification",
            "play_video" to "Play Videos with", "play_audio" to "Play Audio with",
            "auto_play" to "Auto Play Videos", "auto_play_d" to "Videos play automatically when opened",
            "quick_search" to "Quick Search", "quick_search_d" to "Show Google suggestions while typing",
            "brightness" to "Adjust Brightness", "brightness_d" to "Player brightness (Day/Night)",
            "clear_cache" to "Clear Cache", "dark_mode" to "Dark Mode", "theme_color" to "Theme Colour",
            "storage_title" to "Storage permissions", "storage_body" to "Enable this permission to download videos",
            "allow_all" to "Allow access to all files", "confirm" to "Confirm",
            "copied_q" to "Copied link found. Download it?", "cancel" to "Cancel", "delete" to "Delete", "ok" to "OK",
            "add" to "Add", "always" to "Always", "wifi" to "WiFi only", "never" to "Never",
            "off" to "Off", "system_lang" to "System Language", "low" to "Low", "medium" to "Medium", "high" to "High",
            "name" to "Your name", "mobile" to "Mobile number / Email", "welcome" to "Welcome",
            "freed" to "Cleaned", "boosted" to "Phone boosted! Memory freed"
        ),
        "hi" to mapOf(
            "select_lang" to "भाषा चुनें", "skip" to "छोड़ें", "next" to "आगे", "start" to "शुरू करें",
            "smarter" to "स्मार्ट", "smarter_d" to "आपके लिए वीडियो ढूंढे",
            "cleaner" to "साफ़", "cleaner_d" to "बिना विज्ञापन, आसान डाउनलोड",
            "faster" to "तेज़", "faster_d" to "झटपट वीडियो पाएं",
            "home" to "होम", "downloads" to "डाउनलोड", "music" to "म्यूज़िक", "me" to "मैं",
            "search_hint" to "सर्च करें या लिंक डालें", "paste_dl" to "लिंक पेस्ट करके डाउनलोड",
            "popular_sites" to "लोकप्रिय साइट्स", "sites" to "साइट्स", "all_sites" to "सभी साइट्स",
            "how_title" to "⚡ डाउनलोड कैसे करें?",
            "how_body" to "1. YouTube या कोई भी साइट खोलें\n2. वीडियो चलाएं\n3. लाल DOWNLOAD बटन दबाएं\n4. क्वालिटी चुनें (144p से 4K, या MP3)\n\nया YouTube ऐप में Share → Jhatpat Downloader चुनें।",
            "made_in_india" to "मेड इन इंडिया 🇮🇳", "recent" to "हाल के डाउनलोड",
            "downloading" to "डाउनलोड हो रहा", "completed" to "पूरे हुए",
            "empty_dl" to "अभी कोई डाउनलोड नहीं\nहोम से वीडियो खोलकर डाउनलोड करें",
            "finding" to "क्वालिटी ढूंढ रहे हैं... (पहली बार 10-20 सेकंड)", "video" to "🎬  वीडियो", "audio" to "🎵  ऑडियो",
            "found_on_page" to "🔎  पेज पर मिले वीडियो", "retry" to "दोबारा कोशिश करें",
            "not_found" to "इस पेज पर डाउनलोड वाला वीडियो नहीं मिला।\nवीडियो वाले पेज पर जाकर (वीडियो चलाकर) फिर कोशिश करें।",
            "download" to "डाउनलोड", "dl_started" to "डाउनलोड शुरू",
            "sign_in" to "साइन इन", "sign_out" to "साइन आउट", "my_files" to "मेरी फाइलें", "history" to "हिस्ट्री",
            "bookmarks" to "सब्सक्रिप्शन", "playlist" to "प्लेलिस्ट", "share" to "शेयर", "theme" to "थीम",
            "update" to "अपडेट", "feedback" to "फीडबैक", "help" to "मदद", "settings" to "सेटिंग्स",
            "junk_clean" to "जंक साफ़", "boost" to "बूस्ट",
            "content" to "कंटेंट", "content_d" to "भाषा, लोकेशन, सुरक्षित मोड",
            "download_s" to "डाउनलोड", "download_d" to "फ़ोल्डर, WiFi, सबटाइटल आदि",
            "notifications" to "नोटिफिकेशन", "notifications_d" to "प्रोग्रेस, पूरा, कॉपी लिंक",
            "widgets" to "विजेट", "widgets_d" to "होम स्क्रीन पर क्विक बटन",
            "others" to "अन्य", "others_d" to "प्लेयर, थीम, ब्राइटनेस, कैश",
            "about" to "हमारे बारे में", "language" to "झटपट की भाषा", "location" to "लोकेशन",
            "restricted" to "सुरक्षित मोड",
            "f_rec" to "सुझाव फ़िल्टर", "f_rec_d" to "फ़ीड में एडल्ट कंटेंट छुपाएं",
            "f_browse" to "ब्राउज़िंग फ़िल्टर", "f_browse_d" to "ब्राउज़िंग में एडल्ट पेज ब्लॉक करें",
            "f_search" to "सर्च फ़िल्टर", "f_search_d" to "सर्च में एडल्ट कंटेंट छुपाएं (SafeSearch)",
            "f_sites" to "साइट्स फ़िल्टर", "f_sites_d" to "ऐप में एडल्ट वेबसाइट छुपाएं",
            "dl_path" to "डाउनलोड फ़ोल्डर", "wifi_only" to "सिर्फ़ WiFi पर डाउनलोड", "max_tasks" to "एक साथ कितने डाउनलोड",
            "fast_dl" to "फ़ास्ट डाउनलोड", "fast_dl_d" to "एक डाउनलोड के लिए कई कनेक्शन",
            "auto_resume" to "अपने आप फिर शुरू", "subtitle" to "सबटाइटल डाउनलोड", "music_q" to "म्यूज़िक क्वालिटी",
            "clip_detect" to "कॉपी लिंक पहचान", "clip_detect_d" to "लिंक कॉपी करते ही डाउनलोड बटन दिखाएं",
            "notify_done" to "डाउनलोड पूरा होने का नोटिफिकेशन", "notify_progress" to "डाउनलोड प्रोग्रेस नोटिफिकेशन",
            "notify_clip" to "कॉपी लिंक नोटिफिकेशन",
            "play_video" to "वीडियो किससे चलाएं", "play_audio" to "ऑडियो किससे चलाएं",
            "auto_play" to "वीडियो अपने आप चलें", "auto_play_d" to "खोलते ही वीडियो चलने लगे",
            "quick_search" to "क्विक सर्च", "quick_search_d" to "टाइप करते समय Google सुझाव दिखाएं",
            "brightness" to "ब्राइटनेस", "brightness_d" to "प्लेयर की ब्राइटनेस (दिन/रात)",
            "clear_cache" to "कैश साफ़ करें", "dark_mode" to "डार्क मोड", "theme_color" to "थीम का रंग",
            "storage_title" to "स्टोरेज परमिशन", "storage_body" to "वीडियो डाउनलोड करने के लिए यह परमिशन चालू करें",
            "allow_all" to "सभी फाइलों की अनुमति दें", "confirm" to "ठीक है",
            "copied_q" to "कॉपी किया लिंक मिला। डाउनलोड करें?", "cancel" to "रद्द करें", "delete" to "डिलीट", "ok" to "ठीक है",
            "add" to "जोड़ें", "always" to "हमेशा", "wifi" to "सिर्फ़ WiFi", "never" to "कभी नहीं",
            "off" to "बंद", "system_lang" to "फ़ोन की भाषा", "low" to "कम", "medium" to "मीडियम", "high" to "हाई",
            "name" to "आपका नाम", "mobile" to "मोबाइल नंबर / ईमेल", "welcome" to "स्वागत है",
            "freed" to "साफ़ हुआ", "boosted" to "फ़ोन बूस्ट हुआ! मेमोरी खाली"
        ),
        "bho" to mapOf(
            "select_lang" to "भाषा चुनीं", "skip" to "छोड़ीं", "next" to "आगे", "start" to "शुरू करीं",
            "smarter" to "चालाक", "smarter_d" to "रउरा खातिर वीडियो खोजे",
            "cleaner" to "साफ-सुथरा", "cleaner_d" to "बिना प्रचार के, आसान डाउनलोड",
            "faster" to "तेज", "faster_d" to "झटपट वीडियो पाईं",
            "home" to "होम", "downloads" to "डाउनलोड", "me" to "हम",
            "search_hint" to "खोजीं भा लिंक डालीं", "paste_dl" to "लिंक चिपका के डाउनलोड करीं",
            "popular_sites" to "मसहूर साइट", "downloading" to "डाउनलोड होत बा", "completed" to "पूरा भइल",
            "empty_dl" to "अबहीं कवनो डाउनलोड नइखे\nहोम से वीडियो खोल के डाउनलोड करीं",
            "download" to "डाउनलोड", "my_files" to "हमार फाइल", "help" to "मदद", "settings" to "सेटिंग",
            "how_title" to "⚡ डाउनलोड कइसे करीं?", "made_in_india" to "भारत में बनल 🇮🇳"
        ),
        "bgc" to mapOf(
            "select_lang" to "भाषा चुणो", "skip" to "छोड़ो", "next" to "आग्गै", "start" to "शुरू करो",
            "smarter" to "स्याणा", "smarter_d" to "थारे खातर वीडियो टोह्वै",
            "cleaner" to "साफ", "cleaner_d" to "बिना एड, सीधा डाउनलोड",
            "faster" to "तावळा", "faster_d" to "झटपट वीडियो पाओ",
            "home" to "होम", "downloads" to "डाउनलोड", "me" to "मैं",
            "search_hint" to "टोहो या लिंक घालो", "paste_dl" to "लिंक चेप कै डाउनलोड करो",
            "popular_sites" to "मसहूर साइट", "downloading" to "डाउनलोड होण लाग रह्या", "completed" to "पूरे होगे",
            "empty_dl" to "इब्बै कोए डाउनलोड कोनी\nहोम तै वीडियो खोल कै डाउनलोड करो",
            "download" to "डाउनलोड", "my_files" to "मेरी फाइल", "help" to "मदद", "settings" to "सेटिंग",
            "how_title" to "⚡ डाउनलोड क्यूकर करां?", "made_in_india" to "भारत म्हं बण्या 🇮🇳"
        ),
        "raj" to mapOf(
            "select_lang" to "भासा चुणो", "skip" to "छोड़ो", "next" to "आगै", "start" to "सरू करो",
            "smarter" to "चतर", "smarter_d" to "थांरै सारू वीडियो सोधै",
            "cleaner" to "साफ", "cleaner_d" to "बिना एड, सोरो डाउनलोड",
            "faster" to "तेज", "faster_d" to "झटपट वीडियो पावो",
            "home" to "होम", "downloads" to "डाउनलोड", "me" to "म्हैं",
            "search_hint" to "सोधो या लिंक नाखो", "paste_dl" to "लिंक चेपर डाउनलोड करो",
            "popular_sites" to "चावी साइटां", "downloading" to "डाउनलोड हो रह्यो", "completed" to "पूरा व्हिया",
            "empty_dl" to "अबार कोई डाउनलोड कोनी\nहोम सूं वीडियो खोलर डाउनलोड करो",
            "download" to "डाउनलोड", "my_files" to "म्हारी फाइलां", "help" to "मदद", "settings" to "सेटिंग",
            "how_title" to "⚡ डाउनलोड कियां करां?", "made_in_india" to "भारत में बण्यो 🇮🇳"
        ),
        "mr" to mapOf(
            "select_lang" to "भाषा निवडा", "skip" to "वगळा", "next" to "पुढे", "start" to "सुरू करा",
            "smarter" to "हुशार", "smarter_d" to "तुमच्यासाठी व्हिडिओ शोधतो",
            "cleaner" to "स्वच्छ", "cleaner_d" to "जाहिरातींशिवाय, सोपे डाउनलोड",
            "faster" to "वेगवान", "faster_d" to "झटपट व्हिडिओ मिळवा",
            "home" to "होम", "downloads" to "डाउनलोड", "music" to "संगीत", "me" to "मी",
            "search_hint" to "शोधा किंवा लिंक टाका", "paste_dl" to "लिंक पेस्ट करून डाउनलोड",
            "popular_sites" to "लोकप्रिय साइट्स", "sites" to "साइट्स",
            "how_title" to "⚡ डाउनलोड कसे करायचे?",
            "how_body" to "1. YouTube किंवा कोणतीही साइट उघडा\n2. व्हिडिओ चालू करा\n3. लाल DOWNLOAD बटण दाबा\n4. क्वालिटी निवडा (144p ते 4K, किंवा MP3)",
            "made_in_india" to "भारतात बनवलेले 🇮🇳",
            "downloading" to "डाउनलोड होत आहे", "completed" to "पूर्ण झाले",
            "empty_dl" to "अजून कोणतेही डाउनलोड नाही\nहोम मधून व्हिडिओ उघडून डाउनलोड करा",
            "download" to "डाउनलोड", "sign_in" to "साइन इन", "my_files" to "माझ्या फाइल्स", "history" to "इतिहास",
            "playlist" to "प्लेलिस्ट", "share" to "शेअर", "theme" to "थीम", "update" to "अपडेट", "feedback" to "अभिप्राय",
            "help" to "मदत", "settings" to "सेटिंग्ज", "junk_clean" to "जंक साफ करा", "boost" to "बूस्ट",
            "content" to "कंटेंट", "download_s" to "डाउनलोड", "notifications" to "सूचना", "widgets" to "विजेट",
            "others" to "इतर", "about" to "आमच्याबद्दल", "language" to "भाषा", "dark_mode" to "डार्क मोड",
            "storage_title" to "स्टोरेज परवानगी", "storage_body" to "व्हिडिओ डाउनलोड करण्यासाठी ही परवानगी चालू करा",
            "confirm" to "ठीक आहे", "cancel" to "रद्द करा", "delete" to "हटवा"
        ),
        "pa" to mapOf(
            "select_lang" to "ਭਾਸ਼ਾ ਚੁਣੋ", "skip" to "ਛੱਡੋ", "next" to "ਅੱਗੇ", "start" to "ਸ਼ੁਰੂ ਕਰੋ",
            "smarter" to "ਸਮਾਰਟ", "smarter_d" to "ਤੁਹਾਡੇ ਲਈ ਵੀਡੀਓ ਲੱਭੇ",
            "cleaner" to "ਸਾਫ਼", "cleaner_d" to "ਬਿਨਾਂ ਇਸ਼ਤਿਹਾਰ, ਸੌਖਾ ਡਾਊਨਲੋਡ",
            "faster" to "ਤੇਜ਼", "faster_d" to "ਝਟਪਟ ਵੀਡੀਓ ਪਾਓ",
            "home" to "ਹੋਮ", "downloads" to "ਡਾਊਨਲੋਡ", "music" to "ਸੰਗੀਤ", "me" to "ਮੈਂ",
            "search_hint" to "ਖੋਜੋ ਜਾਂ ਲਿੰਕ ਪਾਓ", "paste_dl" to "ਲਿੰਕ ਪੇਸਟ ਕਰਕੇ ਡਾਊਨਲੋਡ",
            "popular_sites" to "ਮਸ਼ਹੂਰ ਸਾਈਟਾਂ", "sites" to "ਸਾਈਟਾਂ", "how_title" to "⚡ ਡਾਊਨਲੋਡ ਕਿਵੇਂ ਕਰੀਏ?",
            "made_in_india" to "ਭਾਰਤ ਵਿੱਚ ਬਣਿਆ 🇮🇳",
            "downloading" to "ਡਾਊਨਲੋਡ ਹੋ ਰਿਹਾ", "completed" to "ਪੂਰੇ ਹੋਏ",
            "empty_dl" to "ਹਾਲੇ ਕੋਈ ਡਾਊਨਲੋਡ ਨਹੀਂ", "download" to "ਡਾਊਨਲੋਡ",
            "sign_in" to "ਸਾਈਨ ਇਨ", "my_files" to "ਮੇਰੀਆਂ ਫਾਈਲਾਂ", "history" to "ਇਤਿਹਾਸ", "playlist" to "ਪਲੇਲਿਸਟ",
            "share" to "ਸਾਂਝਾ ਕਰੋ", "theme" to "ਥੀਮ", "update" to "ਅੱਪਡੇਟ", "feedback" to "ਫੀਡਬੈਕ", "help" to "ਮਦਦ",
            "settings" to "ਸੈਟਿੰਗਾਂ", "junk_clean" to "ਕਬਾੜ ਸਾਫ਼", "boost" to "ਬੂਸਟ",
            "content" to "ਸਮੱਗਰੀ", "download_s" to "ਡਾਊਨਲੋਡ", "notifications" to "ਸੂਚਨਾਵਾਂ", "widgets" to "ਵਿਜੇਟ",
            "others" to "ਹੋਰ", "about" to "ਸਾਡੇ ਬਾਰੇ", "language" to "ਭਾਸ਼ਾ", "dark_mode" to "ਡਾਰਕ ਮੋਡ",
            "storage_title" to "ਸਟੋਰੇਜ ਇਜਾਜ਼ਤ", "storage_body" to "ਵੀਡੀਓ ਡਾਊਨਲੋਡ ਲਈ ਇਹ ਇਜਾਜ਼ਤ ਚਾਲੂ ਕਰੋ",
            "confirm" to "ਠੀਕ ਹੈ", "cancel" to "ਰੱਦ ਕਰੋ", "delete" to "ਮਿਟਾਓ"
        ),
        "gu" to mapOf(
            "select_lang" to "ભાષા પસંદ કરો", "skip" to "છોડો", "next" to "આગળ", "start" to "શરૂ કરો",
            "smarter" to "સ્માર્ટ", "smarter_d" to "તમારા માટે વીડિયો શોધે", "cleaner" to "સ્વચ્છ",
            "cleaner_d" to "જાહેરાત વગર, સરળ ડાઉનલોડ", "faster" to "ઝડપી", "faster_d" to "ઝટપટ વીડિયો મેળવો",
            "home" to "હોમ", "downloads" to "ડાઉનલોડ", "me" to "હું", "search_hint" to "શોધો અથવા લિંક નાખો",
            "paste_dl" to "લિંક પેસ્ટ કરી ડાઉનલોડ", "popular_sites" to "લોકપ્રિય સાઇટ્સ",
            "downloading" to "ડાઉનલોડ થાય છે", "completed" to "પૂર્ણ", "download" to "ડાઉનલોડ",
            "my_files" to "મારી ફાઇલો", "history" to "ઇતિહાસ", "share" to "શેર", "help" to "મદદ", "settings" to "સેટિંગ્સ",
            "language" to "ભાષા", "confirm" to "ઠીક છે", "cancel" to "રદ કરો"
        ),
        "ta" to mapOf(
            "select_lang" to "மொழியைத் தேர்ந்தெடுக்கவும்", "skip" to "தவிர்", "next" to "அடுத்து", "start" to "தொடங்கு",
            "smarter" to "புத்திசாலி", "smarter_d" to "உங்களுக்கான வீடியோக்களைக் கண்டறியும்", "cleaner" to "சுத்தம்",
            "cleaner_d" to "விளம்பரமின்றி எளிய பதிவிறக்கம்", "faster" to "வேகம்", "faster_d" to "நொடியில் வீடியோக்கள்",
            "home" to "முகப்பு", "downloads" to "பதிவிறக்கம்", "me" to "நான்", "search_hint" to "தேடு அல்லது இணைப்பை உள்ளிடு",
            "paste_dl" to "இணைப்பை ஒட்டி பதிவிறக்கு", "popular_sites" to "பிரபல தளங்கள்",
            "downloading" to "பதிவிறக்குகிறது", "completed" to "முடிந்தது", "download" to "பதிவிறக்கு",
            "my_files" to "என் கோப்புகள்", "history" to "வரலாறு", "share" to "பகிர்", "help" to "உதவி", "settings" to "அமைப்புகள்",
            "language" to "மொழி", "confirm" to "சரி", "cancel" to "ரத்து"
        ),
        "te" to mapOf(
            "select_lang" to "భాషను ఎంచుకోండి", "skip" to "దాటవేయి", "next" to "తదుపరి", "start" to "ప్రారంభించు",
            "smarter" to "స్మార్ట్", "smarter_d" to "మీ కోసం వీడియోలు వెతుకుతుంది", "cleaner" to "శుభ్రం",
            "cleaner_d" to "ప్రకటనలు లేకుండా సులభ డౌన్‌లోడ్", "faster" to "వేగం", "faster_d" to "క్షణాల్లో వీడియోలు",
            "home" to "హోమ్", "downloads" to "డౌన్‌లోడ్‌లు", "me" to "నేను", "search_hint" to "వెతకండి లేదా లింక్ ఇవ్వండి",
            "paste_dl" to "లింక్ పేస్ట్ చేసి డౌన్‌లోడ్", "popular_sites" to "ప్రముఖ సైట్లు",
            "downloading" to "డౌన్‌లోడ్ అవుతోంది", "completed" to "పూర్తయింది", "download" to "డౌన్‌లోడ్",
            "my_files" to "నా ఫైల్స్", "history" to "చరిత్ర", "share" to "షేర్", "help" to "సహాయం", "settings" to "సెట్టింగ్‌లు",
            "language" to "భాష", "confirm" to "సరే", "cancel" to "రద్దు"
        ),
        "ml" to mapOf(
            "select_lang" to "ഭാഷ തിരഞ്ഞെടുക്കുക", "skip" to "ഒഴിവാക്കുക", "next" to "അടുത്തത്", "start" to "തുടങ്ങുക",
            "smarter" to "സ്മാർട്ട്", "smarter_d" to "നിങ്ങൾക്കായി വീഡിയോകൾ കണ്ടെത്തുന്നു", "cleaner" to "വൃത്തിയുള്ളത്",
            "cleaner_d" to "പരസ്യമില്ലാതെ എളുപ്പ ഡൗൺലോഡ്", "faster" to "വേഗത", "faster_d" to "നിമിഷങ്ങളിൽ വീഡിയോ",
            "home" to "ഹോം", "downloads" to "ഡൗൺലോഡുകൾ", "me" to "ഞാൻ", "search_hint" to "തിരയുക അല്ലെങ്കിൽ ലിങ്ക് നൽകുക",
            "paste_dl" to "ലിങ്ക് പേസ്റ്റ് ചെയ്ത് ഡൗൺലോഡ്", "popular_sites" to "ജനപ്രിയ സൈറ്റുകൾ",
            "downloading" to "ഡൗൺലോഡ് ചെയ്യുന്നു", "completed" to "പൂർത്തിയായി", "download" to "ഡൗൺലോഡ്",
            "my_files" to "എന്റെ ഫയലുകൾ", "history" to "ചരിത്രം", "share" to "ഷെയർ", "help" to "സഹായം", "settings" to "ക്രമീകരണങ്ങൾ",
            "language" to "ഭാഷ", "confirm" to "ശരി", "cancel" to "റദ്ദാക്കുക"
        ),
        "bn" to mapOf(
            "select_lang" to "ভাষা নির্বাচন করুন", "skip" to "এড়িয়ে যান", "next" to "পরবর্তী", "start" to "শুরু করুন",
            "smarter" to "স্মার্ট", "smarter_d" to "আপনার জন্য ভিডিও খোঁজে", "cleaner" to "পরিষ্কার",
            "cleaner_d" to "বিজ্ঞাপন ছাড়া সহজ ডাউনলোড", "faster" to "দ্রুত", "faster_d" to "ঝটপট ভিডিও পান",
            "home" to "হোম", "downloads" to "ডাউনলোড", "me" to "আমি", "search_hint" to "খুঁজুন বা লিংক দিন",
            "paste_dl" to "লিংক পেস্ট করে ডাউনলোড", "popular_sites" to "জনপ্রিয় সাইট",
            "downloading" to "ডাউনলোড হচ্ছে", "completed" to "সম্পূর্ণ", "download" to "ডাউনলোড",
            "my_files" to "আমার ফাইল", "history" to "ইতিহাস", "share" to "শেয়ার", "help" to "সাহায্য", "settings" to "সেটিংস",
            "language" to "ভাষা", "confirm" to "ঠিক আছে", "cancel" to "বাতিল"
        ),
        "or" to mapOf(
            "select_lang" to "ଭାଷା ବାଛନ୍ତୁ", "skip" to "ଛାଡନ୍ତୁ", "next" to "ପରବର୍ତ୍ତୀ", "start" to "ଆରମ୍ଭ କରନ୍ତୁ",
            "smarter" to "ସ୍ମାର୍ଟ", "smarter_d" to "ଆପଣଙ୍କ ପାଇଁ ଭିଡିଓ ଖୋଜେ", "cleaner" to "ସଫା",
            "cleaner_d" to "ବିଜ୍ଞାପନ ବିନା ସହଜ ଡାଉନଲୋଡ୍", "faster" to "ଦ୍ରୁତ", "faster_d" to "ଝଟପଟ ଭିଡିଓ ପାଆନ୍ତୁ",
            "home" to "ହୋମ୍", "downloads" to "ଡାଉନଲୋଡ୍", "me" to "ମୁଁ", "search_hint" to "ଖୋଜନ୍ତୁ କିମ୍ବା ଲିଙ୍କ ଦିଅନ୍ତୁ",
            "paste_dl" to "ଲିଙ୍କ ପେଷ୍ଟ କରି ଡାଉନଲୋଡ୍", "popular_sites" to "ଲୋକପ୍ରିୟ ସାଇଟ୍",
            "downloading" to "ଡାଉନଲୋଡ୍ ହେଉଛି", "completed" to "ସମ୍ପୂର୍ଣ୍ଣ", "download" to "ଡାଉନଲୋଡ୍",
            "my_files" to "ମୋ ଫାଇଲ୍", "history" to "ଇତିହାସ", "share" to "ସେୟାର", "help" to "ସାହାଯ୍ୟ", "settings" to "ସେଟିଂସ୍",
            "language" to "ଭାଷା", "confirm" to "ଠିକ୍ ଅଛି", "cancel" to "ବାତିଲ୍"
        ),
        "kn" to mapOf(
            "select_lang" to "ಭಾಷೆ ಆಯ್ಕೆಮಾಡಿ", "skip" to "ಬಿಟ್ಟುಬಿಡಿ", "next" to "ಮುಂದೆ", "start" to "ಪ್ರಾರಂಭಿಸಿ",
            "smarter" to "ಸ್ಮಾರ್ಟ್", "smarter_d" to "ನಿಮಗಾಗಿ ವೀಡಿಯೊ ಹುಡುಕುತ್ತದೆ", "cleaner" to "ಸ್ವಚ್ಛ",
            "cleaner_d" to "ಜಾಹೀರಾತು ಇಲ್ಲದೆ ಸುಲಭ ಡೌನ್‌ಲೋಡ್", "faster" to "ವೇಗ", "faster_d" to "ಕ್ಷಣದಲ್ಲಿ ವೀಡಿಯೊ ಪಡೆಯಿರಿ",
            "home" to "ಹೋಮ್", "downloads" to "ಡೌನ್‌ಲೋಡ್", "me" to "ನಾನು", "search_hint" to "ಹುಡುಕಿ ಅಥವಾ ಲಿಂಕ್ ನೀಡಿ",
            "paste_dl" to "ಲಿಂಕ್ ಪೇಸ್ಟ್ ಮಾಡಿ ಡೌನ್‌ಲೋಡ್", "popular_sites" to "ಜನಪ್ರಿಯ ಸೈಟ್‌ಗಳು",
            "downloading" to "ಡೌನ್‌ಲೋಡ್ ಆಗುತ್ತಿದೆ", "completed" to "ಪೂರ್ಣಗೊಂಡಿದೆ", "download" to "ಡೌನ್‌ಲೋಡ್",
            "my_files" to "ನನ್ನ ಫೈಲ್‌ಗಳು", "history" to "ಇತಿಹಾಸ", "share" to "ಹಂಚಿಕೊಳ್ಳಿ", "help" to "ಸಹಾಯ", "settings" to "ಸೆಟ್ಟಿಂಗ್‌ಗಳು",
            "language" to "ಭಾಷೆ", "confirm" to "ಸರಿ", "cancel" to "ರದ್ದು"
        ),
        "as" to mapOf(
            "select_lang" to "ভাষা বাছক", "skip" to "এৰক", "next" to "পৰৱৰ্তী", "start" to "আৰম্ভ কৰক",
            "smarter" to "স্মাৰ্ট", "smarter_d" to "আপোনাৰ বাবে ভিডিঅ' বিচাৰে", "cleaner" to "পৰিষ্কাৰ",
            "cleaner_d" to "বিজ্ঞাপন নোহোৱাকৈ সহজ ডাউনলোড", "faster" to "দ্ৰুত", "faster_d" to "খৰকৈ ভিডিঅ' পাওক",
            "home" to "হোম", "downloads" to "ডাউনলোড", "me" to "মই", "search_hint" to "বিচাৰক বা লিংক দিয়ক",
            "paste_dl" to "লিংক পেষ্ট কৰি ডাউনলোড", "popular_sites" to "জনপ্ৰিয় ছাইট",
            "downloading" to "ডাউনলোড হৈ আছে", "completed" to "সম্পূৰ্ণ", "download" to "ডাউনলোড",
            "my_files" to "মোৰ ফাইল", "history" to "ইতিহাস", "share" to "শ্বেয়াৰ", "help" to "সহায়", "settings" to "ছেটিংছ",
            "language" to "ভাষা", "confirm" to "ঠিক আছে", "cancel" to "বাতিল"
        )
    )
}
