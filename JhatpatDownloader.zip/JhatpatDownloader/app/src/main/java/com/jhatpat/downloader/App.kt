package com.jhatpat.downloader

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        instance = this
        DownloadRepo.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CH_PROGRESS, "Downloading", NotificationManager.IMPORTANCE_LOW)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_DONE, "Download complete", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        Engine.initAsync(this)
    }

    companion object {
        lateinit var instance: App
        const val CH_PROGRESS = "jp_progress"
        const val CH_DONE = "jp_done"
    }
}
