package com.jhatpat.downloader

import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.MediaController
import android.widget.TextView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity

/** Jhatpat ka apna video / MP3 player */
class PlayerActivity : AppCompatActivity() {
    private lateinit var video: VideoView
    private var pos = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_player)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        video = findViewById(R.id.video)
        val title = findViewById<TextView>(R.id.tvTitle)
        val art = findViewById<ImageView>(R.id.ivArt)
        val uri = intent.getStringExtra("uri")
        if (uri == null) { finish(); return }
        title.text = intent.getStringExtra("title") ?: ""
        val mime = intent.getStringExtra("mime") ?: ""
        if (mime.startsWith("audio/")) {
            art.visibility = View.VISIBLE
            art.bringToFront()
            title.bringToFront()
        }
        val mc = MediaController(this)
        mc.setAnchorView(video)
        video.setMediaController(mc)
        video.setVideoURI(Uri.parse(uri))
        video.setOnPreparedListener { video.start(); mc.show(3000) }
        video.setOnErrorListener { _, _, _ ->
            Util.toast(this, "Yeh file yahan nahi chali, dusre player me khul rahi hai")
            DownloadRepo.all().firstOrNull { it.fileUri == uri }?.let { Util.openWith(this, it) }
            finish(); true
        }
        video.setOnClickListener { if (mc.isShowing) mc.hide() else mc.show() }
        savedInstanceState?.let { pos = it.getInt("pos", 0) }
    }

    override fun onResume() {
        super.onResume()
        if (pos > 0) { video.seekTo(pos); video.start() }
    }

    override fun onPause() {
        super.onPause()
        pos = video.currentPosition
        video.pause()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("pos", pos)
    }
}
