package com.jhatpat.downloader

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.LruCache
import android.webkit.MimeTypeMap
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

object Util {
    fun size(b: Long): String {
        if (b <= 0) return ""
        val kb = b / 1024.0
        val mb = kb / 1024.0
        val gb = mb / 1024.0
        return when {
            gb >= 1 -> String.format(Locale.US, "%.2f GB", gb)
            mb >= 1 -> String.format(Locale.US, "%.1f MB", mb)
            else -> String.format(Locale.US, "%.0f KB", kb)
        }
    }

    fun duration(sec: Long): String {
        if (sec <= 0) return ""
        val h = sec / 3600; val m = (sec % 3600) / 60; val s = sec % 60
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
        else String.format(Locale.US, "%d:%02d", m, s)
    }

    fun toast(ctx: Context, msg: String) {
        Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
    }

    fun findUrl(text: String?): String? {
        if (text.isNullOrBlank()) return null
        val m = Regex("(https?://[^\\s]+)").find(text) ?: return null
        return m.value.trimEnd('.', ',', ')', ']', '"', '\'')
    }

    fun isUrl(s: String): Boolean {
        val t = s.trim()
        if (t.contains(" ")) return false
        return t.startsWith("http://") || t.startsWith("https://") ||
            Regex("^[a-zA-Z0-9-]+(\\.[a-zA-Z0-9-]+)+(/.*)?$").matches(t)
    }

    fun mimeOf(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase(Locale.US)
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
            "mkv" -> "video/x-matroska"
            "webm" -> "video/webm"
            "opus" -> "audio/ogg"
            else -> "application/octet-stream"
        }
    }

    /** Download hui file ko Gallery / Music folder me "JhatpatDownloader" me save karna */
    fun publish(ctx: Context, f: File): Pair<String, String> {
        val mime = mimeOf(f.name)
        val isAudio = mime.startsWith("audio/")
        val isVideo = mime.startsWith("video/")
        // Vidmate jaisa: phone storage / JhatpatDownloader (All files permission ho to)
        if (Prefs.pathMode == "jhatpat" && hasAllFiles(ctx)) {
            val root = File(Environment.getExternalStorageDirectory(), "JhatpatDownloader")
            val dir = File(root, if (isAudio) "Music" else if (isVideo) "Video" else "Files").apply { mkdirs() }
            var dest = File(dir, f.name)
            var n = 1
            while (dest.exists()) { dest = File(dir, f.nameWithoutExtension + " ($n)." + f.extension); n++ }
            if (!f.renameTo(dest)) { f.copyTo(dest, true); f.delete() }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
            return Pair(Uri.fromFile(dest).toString(), dest.absolutePath)
        }
        val toDownloads = Prefs.pathMode == "download"
        if (Build.VERSION.SDK_INT >= 29) {
            val rel: String
            val col: Uri
            when {
                toDownloads -> { rel = Environment.DIRECTORY_DOWNLOADS + "/JhatpatDownloader"; col = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) }
                isVideo -> { rel = Environment.DIRECTORY_MOVIES + "/JhatpatDownloader"; col = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) }
                isAudio -> { rel = Environment.DIRECTORY_MUSIC + "/JhatpatDownloader"; col = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) }
                else -> { rel = Environment.DIRECTORY_DOWNLOADS + "/JhatpatDownloader"; col = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) }
            }
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val cr = ctx.contentResolver
            val uri = cr.insert(col, cv) ?: throw RuntimeException("Gallery me save nahi hua")
            try {
                cr.openOutputStream(uri)!!.use { out -> FileInputStream(f).use { it.copyTo(out, 256 * 1024) } }
                cv.clear(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
                cr.update(uri, cv, null, null)
            } catch (e: Exception) {
                cr.delete(uri, null, null); throw e
            }
            f.delete()
            return Pair(uri.toString(), "$rel/${f.name}")
        } else {
            val base = Environment.getExternalStoragePublicDirectory(
                when { toDownloads -> Environment.DIRECTORY_DOWNLOADS; isVideo -> Environment.DIRECTORY_MOVIES; isAudio -> Environment.DIRECTORY_MUSIC; else -> Environment.DIRECTORY_DOWNLOADS }
            )
            val dir = File(base, "JhatpatDownloader").apply { mkdirs() }
            var dest = File(dir, f.name)
            var n = 1
            while (dest.exists()) { dest = File(dir, f.nameWithoutExtension + " ($n)." + f.extension); n++ }
            if (!f.renameTo(dest)) { f.copyTo(dest, true); f.delete() }
            MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), arrayOf(mime), null)
            return Pair(Uri.fromFile(dest).toString(), dest.absolutePath)
        }
    }

    /** YouTube/Google account browser me login hai ya nahi (cookies se) */
    fun isGoogleSignedIn(): Boolean {
        return try {
            val cm = android.webkit.CookieManager.getInstance()
            val c = (cm.getCookie("https://www.youtube.com") ?: "") + (cm.getCookie("https://accounts.google.com") ?: "")
            c.contains("SAPISID") || c.contains("__Secure-3PSID") || Regex("(^|;|\s)SID=").containsMatchIn(c)
        } catch (e: Exception) { false }
    }

    fun googleSignOut(ctx: Context) {
        try {
            val cm = android.webkit.CookieManager.getInstance()
            cm.removeAllCookies(null); cm.flush()
            android.webkit.WebStorage.getInstance().deleteAllData()
            java.io.File(ctx.filesDir, "cookies.txt").delete()
        } catch (_: Exception) { }
        Prefs.googleSignedIn = false
    }

    fun hasAllFiles(ctx: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun pathLabel(ctx: Context): String = when {
        Prefs.pathMode == "jhatpat" && hasAllFiles(ctx) -> "/storage/emulated/0/JhatpatDownloader/"
        Prefs.pathMode == "jhatpat" -> "/storage/emulated/0/JhatpatDownloader/ (permission chahiye)"
        Prefs.pathMode == "download" -> "/storage/emulated/0/Download/JhatpatDownloader/"
        else -> "Movies/JhatpatDownloader + Music/JhatpatDownloader"
    }

    fun isWifi(ctx: Context): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as android.net.ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(android.net.NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun dirSize(f: File): Long = if (f.isDirectory) (f.listFiles()?.sumOf { dirSize(it) } ?: 0L) else f.length()

    /** Junk Clean: cache + adhure temp files saaf */
    fun cleanJunk(ctx: Context): Long {
        var freed = 0L
        val targets = listOfNotNull(ctx.cacheDir, ctx.externalCacheDir)
        targets.forEach { d -> d.listFiles()?.forEach { freed += dirSize(it); it.deleteRecursively() } }
        val tmp = File(ctx.getExternalFilesDir(null) ?: ctx.filesDir, "tmp")
        val activeIds = DownloadRepo.all().filter { it.status != DTask.DONE }.map { it.id }.toSet()
        tmp.listFiles()?.forEach { if (it.name !in activeIds) { freed += dirSize(it); it.deleteRecursively() } }
        try { android.webkit.WebView(ctx).clearCache(true) } catch (_: Exception) { }
        return freed
    }

    /** Video/Audio chalana: Jhatpat Player ya dusra app */
    fun play(ctx: Context, t: DTask) {
        val audio = (t.mime ?: "").startsWith("audio/")
        val other = if (audio) Prefs.playAudioWith == "other" else Prefs.playVideoWith == "other"
        if (other) { openWith(ctx, t); return }
        ctx.startActivity(Intent(ctx, PlayerActivity::class.java)
            .putExtra("uri", t.fileUri).putExtra("title", t.title).putExtra("mime", t.mime)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    /** Share / open ke liye content:// uri */
    fun shareUri(ctx: Context, t: DTask): Uri? {
        val u = t.fileUri ?: return null
        val uri = Uri.parse(u)
        if (uri.scheme == "file") {
            val p = uri.path ?: return null
            return try { FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(p)) } catch (e: Exception) { null }
        }
        return uri
    }

    fun share(ctx: Context, t: DTask) {
        val uri = shareUri(ctx, t) ?: return toast(ctx, "File nahi mili")
        val i = Intent(Intent.ACTION_SEND).apply {
            type = t.mime ?: "video/*"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_TEXT, "Downloaded with Jhatpat Downloader")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(i, "Share karein").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    fun openWith(ctx: Context, t: DTask) {
        val uri = shareUri(ctx, t) ?: return toast(ctx, "File nahi mili")
        val i = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, t.mime ?: "video/*")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { ctx.startActivity(Intent.createChooser(i, "Open with").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { }
    }

    fun deleteFile(ctx: Context, t: DTask) {
        try {
            val u = t.fileUri ?: return
            val uri = Uri.parse(u)
            if (uri.scheme == "file") File(uri.path!!).delete()
            else ctx.contentResolver.delete(uri, null, null)
        } catch (_: Exception) { }
    }
}

/** Chhota sa thumbnail loader (Glide ke bina) */
object ImageLoader {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun clear() = cache.evictAll()

    fun load(url: String?, iv: ImageView, placeholder: Int = R.drawable.logo, onLoaded: (() -> Unit)? = null) {
        iv.tag = url
        if (url.isNullOrBlank()) { if (placeholder != 0) iv.setImageResource(placeholder); return }
        cache.get(url)?.let { iv.setImageBitmap(it); onLoaded?.invoke(); return }
        if (placeholder != 0) iv.setImageResource(placeholder)
        pool.execute {
            try {
                val c = URL(url).openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 15000
                c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) Mobile")
                val bytes = c.inputStream.use { it.readBytes() }
                val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                var s = 1
                while (o.outWidth / (s * 2) >= 320) s *= 2
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s })
                // Bahut chhota (default globe) favicon ho to mat dikhao
                if (bmp != null && bmp.width >= 24) {
                    cache.put(url, bmp)
                    main.post { if (iv.tag == url) { iv.setImageBitmap(bmp); onLoaded?.invoke() } }
                }
            } catch (_: Exception) { }
        }
    }
}
