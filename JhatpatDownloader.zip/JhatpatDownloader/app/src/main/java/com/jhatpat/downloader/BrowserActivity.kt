package com.jhatpat.downloader

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import java.util.Collections

class BrowserActivity : AppCompatActivity() {

    private lateinit var web: WebView
    private lateinit var etUrl: EditText
    private lateinit var pb: ProgressBar
    private lateinit var fab: ExtendedFloatingActionButton
    private lateinit var fullContainer: FrameLayout
    private lateinit var tvDlCount: TextView
    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private val sniffed: MutableSet<String> = Collections.synchronizedSet(LinkedHashSet())
    private var pulsing = false
    private val dlListener: () -> Unit = { updateDlCount() }

    private val mediaRx = Regex("\\.(mp4|m3u8|webm|mkv|mov|mp3|m4a|3gp)(\\?|$)", RegexOption.IGNORE_CASE)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_browser)
        web = findViewById(R.id.web)
        etUrl = findViewById(R.id.etUrl)
        pb = findViewById(R.id.pbLoad)
        fab = findViewById(R.id.fabDownload)
        fullContainer = findViewById(R.id.fullContainer)
        tvDlCount = findViewById(R.id.tvDlCount)

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.loadWithOverviewMode = true
        s.useWideViewPort = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.userAgentString = s.userAgentString.replace("; wv", "").replace("Version/4.0 ", "")
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.addJavascriptInterface(Bridge(), "JhatpatBridge")

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                if (u.startsWith("http://") || u.startsWith("https://")) return false
                if (u.startsWith("intent://")) {
                    val fb = Regex("S\\.browser_fallback_url=([^;]+)").find(u)?.groupValues?.get(1)
                    if (fb != null) view.loadUrl(Uri.decode(fb))
                    return true
                }
                // Dusre apps wale links (vnd.youtube, whatsapp...) browser me hi rahein
                return true
            }

            override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
                sniffed.clear()
                setUrlText(url)
                updateFab(url)
            }

            override fun onPageFinished(view: WebView, url: String) {
                setUrlText(url)
                injectYouTubeButton()
            }

            override fun doUpdateVisitedHistory(view: WebView, url: String, isReload: Boolean) {
                setUrlText(url)
                updateFab(url)
                injectYouTubeButton()
            }

            override fun shouldInterceptRequest(view: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url.toString()
                if (!u.contains("googlevideo.com") && !u.contains("ytimg") && mediaRx.containsMatchIn(u)) {
                    if (sniffed.add(u)) runOnUiThread { updateFab(web.url ?: "") }
                }
                return null
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                pb.progress = p
                pb.visibility = if (p >= 100) View.GONE else View.VISIBLE
            }

            override fun onShowCustomView(view: View, callback: WebChromeClient.CustomViewCallback) {
                if (customView != null) { callback.onCustomViewHidden(); return }
                customView = view; customCallback = callback
                fullContainer.addView(view, FrameLayout.LayoutParams(-1, -1))
                fullContainer.visibility = View.VISIBLE
                fab.visibility = View.GONE
                setFullscreen(true)
            }

            override fun onHideCustomView() { exitFullscreen() }
        }

        web.setDownloadListener { url, ua, cd, mime, _ ->
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                DownloadSheet(this).show(url, URLUtil.guessFileName(url, cd, mime))
            } else {
                try {
                    val name = URLUtil.guessFileName(url, cd, mime)
                    val r = DownloadManager.Request(Uri.parse(url))
                        .setMimeType(mime)
                        .addRequestHeader("User-Agent", ua)
                        .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(url) ?: "")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "JhatpatDownloader/$name")
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                    Util.toast(this, "Download: $name")
                } catch (e: Exception) {
                    Util.toast(this, "Download nahi hua")
                }
            }
        }

        fab.setOnClickListener { startDownload() }

        etUrl.setOnEditorActionListener { _, a, _ ->
            if (a == EditorInfo.IME_ACTION_GO) {
                load(etUrl.text.toString())
                (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(etUrl.windowToken, 0)
                etUrl.clearFocus()
                true
            } else false
        }
        findViewById<View>(R.id.btnRefresh).setOnClickListener { web.reload() }
        findViewById<View>(R.id.btnBack).setOnClickListener { if (web.canGoBack()) web.goBack() }
        findViewById<View>(R.id.btnFwd).setOnClickListener { if (web.canGoForward()) web.goForward() }
        findViewById<View>(R.id.btnHome).setOnClickListener { finish() }
        findViewById<View>(R.id.ivLogo).setOnClickListener { finish() }
        findViewById<View>(R.id.btnDls).setOnClickListener {
            startActivity(Intent(this, MainActivity::class.java).putExtra("tab", "downloads")
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    customView != null -> exitFullscreen()
                    web.canGoBack() -> web.goBack()
                    else -> finish()
                }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else load(intent.getStringExtra("q") ?: "https://www.google.com")
    }

    private fun load(q: String) {
        val t = q.trim()
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            Util.isUrl(t) -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
    }

    private fun setUrlText(url: String) {
        if (!etUrl.hasFocus()) etUrl.setText(url)
    }

    private fun startDownload() {
        val url = web.url ?: return
        DownloadSheet(this).show(url, web.title, sniffed.toList().reversed())
    }

    /** Video wale page par Download button chamakta hai */
    private fun isVideoPage(url: String): Boolean {
        val u = url.lowercase()
        return (u.contains("youtube.com/watch") || u.contains("youtube.com/shorts/") || u.contains("youtu.be/") ||
            u.contains("instagram.com/reel") || u.contains("instagram.com/p/") || u.contains("instagram.com/tv/") ||
            u.contains("facebook.com/watch") || u.contains("/videos/") || u.contains("facebook.com/reel") || u.contains("fb.watch") ||
            (u.contains("x.com/") && u.contains("/status/")) || (u.contains("twitter.com/") && u.contains("/status/")) ||
            u.contains("dailymotion.com/video") || Regex("vimeo\\.com/\\d+").containsMatchIn(u) ||
            u.contains("sharechat.com/video") || u.contains("sharechat.com/post") || u.contains("mojapp.in/") && u.contains("video") ||
            u.contains("pinterest.") && u.contains("/pin/") || u.contains("reddit.com/r/") && u.contains("/comments/") ||
            u.contains("soundcloud.com/") && u.count { it == '/' } >= 4 || u.contains("twitch.tv/videos") || u.contains("clips.twitch.tv") ||
            u.contains("ted.com/talks/") || u.contains("bilibili.tv/") && u.contains("/video/")) || sniffed.isNotEmpty()
    }

    private fun updateFab(url: String) {
        if (customView != null) return
        fab.visibility = View.VISIBLE
        if (isVideoPage(url)) {
            fab.extend()
            fab.text = if (sniffed.isNotEmpty() && !url.contains("youtube")) "Download (${sniffed.size})" else "Download"
            startPulse()
        } else {
            fab.shrink()
            pulsing = false
        }
    }

    private fun startPulse() {
        if (pulsing) return
        pulsing = true
        fun beat() {
            if (!pulsing || isFinishing) { fab.scaleX = 1f; fab.scaleY = 1f; return }
            fab.animate().scaleX(1.08f).scaleY(1.08f).setDuration(450).setInterpolator(AccelerateDecelerateInterpolator())
                .withEndAction {
                    fab.animate().scaleX(1f).scaleY(1f).setDuration(450).withEndAction { fab.postDelayed({ beat() }, 600) }.start()
                }.start()
        }
        beat()
    }

    /** YouTube page ke andar video ke neeche laal "Download" button */
    private fun injectYouTubeButton() {
        val u = web.url ?: return
        if (!u.contains("youtube.com")) return
        val js = """
            (function(){
              if (window.__jpObs) return;
              function add(){
                if (!/\/(watch|shorts)/.test(location.pathname)) { var o=document.getElementById('jp-dl'); if(o) o.remove(); return; }
                if (document.getElementById('jp-dl')) return;
                var anchor = document.querySelector('ytm-slim-video-metadata-section-renderer, .slim-video-information-renderer, ytm-slim-video-information-renderer, #player-container-id, .player-container');
                if (!anchor) return;
                var b = document.createElement('div');
                b.id = 'jp-dl';
                b.innerHTML = '&#11015;&nbsp; Jhatpat Download';
                b.style.cssText = 'margin:10px 12px;padding:12px;border-radius:24px;text-align:center;font:bold 16px Roboto,Arial;color:#fff;background:linear-gradient(90deg,#FFC400,#FF7A00,#FF1E3C);box-shadow:0 4px 14px rgba(255,30,60,.4);position:relative;z-index:9';
                b.onclick = function(e){ e.preventDefault(); e.stopPropagation(); JhatpatBridge.download(location.href, document.title); };
                if (anchor.id === 'player-container-id' || anchor.classList.contains('player-container')) anchor.parentNode.insertBefore(b, anchor.nextSibling);
                else anchor.parentNode.insertBefore(b, anchor);
              }
              window.__jpObs = new MutationObserver(function(){ add(); });
              window.__jpObs.observe(document.body, {childList:true, subtree:true});
              add();
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun download(url: String, title: String?) {
            runOnUiThread { DownloadSheet(this@BrowserActivity).show(url, title, sniffed.toList()) }
        }
    }

    private fun exitFullscreen() {
        val v = customView ?: return
        fullContainer.removeView(v)
        fullContainer.visibility = View.GONE
        customView = null
        customCallback?.onCustomViewHidden()
        customCallback = null
        setFullscreen(false)
        updateFab(web.url ?: "")
    }

    private fun setFullscreen(on: Boolean) {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        if (on) {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            WindowCompat.setDecorFitsSystemWindows(window, true)
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    private fun updateDlCount() {
        val n = DownloadRepo.all().count { it.isActive }
        tvDlCount.visibility = if (n > 0) View.VISIBLE else View.GONE
        tvDlCount.text = n.toString()
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        DownloadRepo.addListener(dlListener)
        updateDlCount()
    }

    override fun onPause() {
        super.onPause()
        web.onPause()
        DownloadRepo.removeListener(dlListener)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onDestroy() {
        pulsing = false
        web.destroy()
        super.onDestroy()
    }
}
