package com.jhatpat.downloader

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject

/** Ek download choice (jaise 720p ya MP3) */
data class DlOption(
    val label: String,      // "720p"
    val badge: String,      // "HD"
    val kind: String,       // "video" | "audio"
    val format: String,     // yt-dlp -f selector
    val audioConv: String?, // "mp3" / "m4a" (audio ke liye)
    val sizeBytes: Long,
    val ext: String = "MP4",
    val bitrate: String? = null   // audio: "128K" etc.
)

data class MediaInfo(
    val url: String,
    val title: String,
    val thumb: String?,
    val duration: Long,
    val uploader: String?,
    val site: String,
    val options: List<DlOption>
)

/**
 * Jhatpat Engine = yt-dlp (Python) + FFmpeg phone ke andar.
 * YouTube, Instagram, Facebook, X, Dailymotion, Vimeo aur 1000+ sites.
 */
object Engine {
    @Volatile var ready = false
        private set
    @Volatile var initError: String? = null
        private set
    @Volatile var lastUpdateMsg: String = ""
    private val lock = Any()

    /**
     * YouTube "Sign in to confirm you're not a bot" se bachne ke liye:
     * WebView ke cookies (jo browser me login/visit se bante hain) ko
     * yt-dlp ke liye Netscape cookies.txt me likhte hain.
     */
    fun writeCookies(ctx: Context): String? {
        return try {
            val cm = android.webkit.CookieManager.getInstance()
            val sb = StringBuilder("# Netscape HTTP Cookie File\n")
            var any = false
            val domains = listOf(
                ".youtube.com", ".google.com", ".instagram.com", ".facebook.com",
                ".twitter.com", ".x.com", ".dailymotion.com", ".vimeo.com"
            )
            for (d in domains) {
                val raw = cm.getCookie("https://$d") ?: cm.getCookie("https://www$d") ?: continue
                for (pair in raw.split(";")) {
                    val eq = pair.indexOf('=')
                    if (eq <= 0) continue
                    val name = pair.substring(0, eq).trim()
                    val value = pair.substring(eq + 1).trim()
                    if (name.isEmpty()) continue
                    // domain  includeSub  path  secure  expiry  name  value
                    sb.append("$d\tTRUE\t/\tTRUE\t0\t$name\t$value\n")
                    any = true
                }
            }
            if (!any) return null
            val f = java.io.File(ctx.filesDir, "cookies.txt")
            f.writeText(sb.toString())
            f.absolutePath
        } catch (e: Throwable) { null }
    }

    /** Har request par YouTube bot-check tod'ne wali options */
    fun applyAntiBot(req: YoutubeDLRequest, ctx: Context, url: String) {
        // Android/iOS player client web se zyada reliable hai bot check ke liye
        // tv + android client = 720p/1080p/4K DASH formats bhi aate hain, aur bot-check nahi
        req.addOption("--extractor-args", "youtube:player_client=tv,android;formats=missing_pot;skip=translated_subs")
        // Browser jaisa User-Agent
        req.addOption("--user-agent",
            "Mozilla/5.0 (Linux; Android 13; Mobile) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
        req.addOption("--geo-bypass")
        // Cookies agar bane hain to lagao
        val cookies = writeCookies(ctx)
        if (cookies != null) req.addOption("--cookies", cookies)
    }

    fun initAsync(ctx: Context) {
        Thread {
            if (ensureInit(ctx)) {
                val prefs = ctx.getSharedPreferences("jp", Context.MODE_PRIVATE)
                val last = prefs.getLong("last_update", 0L)
                // Din me ek baar engine auto-update (YouTube changes ke liye zaroori)
                if (System.currentTimeMillis() - last > 20L * 60 * 60 * 1000) {
                    if (update(ctx)) prefs.edit().putLong("last_update", System.currentTimeMillis()).apply()
                }
            }
        }.start()
    }

    fun ensureInit(ctx: Context): Boolean {
        synchronized(lock) {
            if (ready) return true
            try {
                YoutubeDL.getInstance().init(ctx.applicationContext)
                FFmpeg.getInstance().init(ctx.applicationContext)
                ready = true
                initError = null
            } catch (e: Throwable) {
                initError = e.message ?: e.toString()
            }
            return ready
        }
    }

    /** yt-dlp ko latest version par update karta hai */
    fun update(ctx: Context): Boolean {
        if (!ensureInit(ctx)) return false
        return try {
            val status = YoutubeDL.getInstance().updateYoutubeDL(ctx.applicationContext, YoutubeDL.UpdateChannel.STABLE)
            lastUpdateMsg = "Engine: ${status ?: "OK"}"
            true
        } catch (e: Throwable) {
            lastUpdateMsg = "Update fail: ${e.message}"
            false
        }
    }

    /** Video ki details + quality list nikalna */
    fun analyze(ctx: Context, url: String): MediaInfo {
        if (!ensureInit(ctx)) throw RuntimeException("Engine start nahi hua: $initError")
        val req = YoutubeDLRequest(url)
        req.addOption("--dump-single-json")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--no-check-formats")      // har format verify mat karo = tez
        req.addOption("--extractor-retries", "1")
        req.addOption("--socket-timeout", "15")
        applyAntiBot(req, ctx, url)
        val resp = YoutubeDL.getInstance().execute(req)
        val out = resp.out
        val start = out.indexOf('{')
        if (start < 0) throw RuntimeException("Video nahi mila")
        var json = JSONObject(out.substring(start))
        // Playlist aaye to pehla video
        if (json.optString("_type") == "playlist") {
            val entries = json.optJSONArray("entries")
            if (entries != null && entries.length() > 0) json = entries.getJSONObject(0)
        }
        return parse(url, json)
    }

    private fun parse(url: String, j: JSONObject): MediaInfo {
        val title = j.optString("title", "Video").ifBlank { "Video" }
        var thumb: String? = j.optString("thumbnail", "")
        if (thumb.isNullOrBlank()) {
            val th = j.optJSONArray("thumbnails")
            thumb = if (th != null && th.length() > 0) th.getJSONObject(th.length() - 1).optString("url") else null
        }
        val duration = j.optDouble("duration", 0.0).let { if (it.isNaN()) 0L else it.toLong() }
        val site = j.optString("extractor_key", j.optString("extractor", "Web"))

        val formats = j.optJSONArray("formats")
        val videoBest = HashMap<Int, Long>()   // height -> size
        var bestAudio = 0L
        var hasAudioOnly = false
        var hasM4a = false
        var combinedOnly = true
        if (formats != null) {
            for (i in 0 until formats.length()) {
                val f = formats.optJSONObject(i) ?: continue
                val v = f.optString("vcodec", "")
                val a = f.optString("acodec", "")
                val h = f.optInt("height", 0)
                var size = f.optLong("filesize", 0L)
                if (size <= 0) size = f.optLong("filesize_approx", 0L)
                if (size <= 0) {
                    val tbr = f.optDouble("tbr", 0.0)
                    if (!tbr.isNaN() && tbr > 0 && duration > 0) size = (tbr * 1000 / 8 * duration).toLong()
                }
                val protocol = f.optString("protocol", "")
                if (protocol.contains("mhtml")) continue // storyboard images
                if (v == "none" && a != "none" && a.isNotEmpty()) {
                    hasAudioOnly = true
                    if (f.optString("ext") == "m4a") hasM4a = true
                    if (size > bestAudio) bestAudio = size
                } else if (h > 0 && v != "none") {
                    if (a == "none") combinedOnly = false
                    val cur = videoBest[h] ?: 0L
                    if (size > cur || !videoBest.containsKey(h)) videoBest[h] = size
                }
            }
        }

        val opts = ArrayList<DlOption>()
        // Vidmate jaisa: 144p se 4K tak ki poori list hamesha dikhao.
        // Jo quality mile wo download ho; JSON me na dikhe to bhi yt-dlp
        // download ke waqt usi height ki stream le aata hai.
        val maxDetected = videoBest.keys.maxOrNull() ?: 0
        // Dikhane layak upari seema: jitna mila usse upar ek rung, kam se kam 1080
        val ladder = listOf(2160, 1440, 1080, 720, 480, 360, 240, 144)
        val topShow = maxOf(1080, maxDetected)
        for (h in ladder) {
            if (h > topShow) continue
            val label = "${h}P"
            val badge = when {
                h >= 2160 -> "4K"
                h >= 1440 -> "2K"
                h >= 1080 -> "Full HD"
                h >= 720 -> "HD"
                else -> ""
            }
            // Size: us height ki detected size, warna aas-paas se andaaza
            var vs = videoBest[h] ?: 0L
            if (vs <= 0L) {
                val near = videoBest.entries.filter { it.key <= h }.maxByOrNull { it.key }
                if (near != null && near.key > 0) vs = near.value * h / near.key
            }
            val total = if (vs > 0) vs + (if (combinedOnly) 0 else bestAudio) else 0L
            // mp4 pehle; na mile to kuchh bhi best <= h; combined 18 (360) bhi chalega
            val fmt = "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h][ext=mp4]/b[height<=$h]/bv*[height<=$h]+ba/wv*+ba/b"
            opts.add(DlOption(label, badge, "video", fmt, null, total))
        }
        // Audio options (Vidmate jaisa: 48K / 128K M4A / 128K / 256K / 320K MP3)
        fun aSize(kbps: Int): Long = if (duration > 0) kbps * 1000L / 8 * duration else 0L
        opts.add(DlOption("48K", "", "audio", "ba/b", "mp3", aSize(48), "MP3", "48K"))
        if (hasAudioOnly && hasM4a) opts.add(DlOption("128K", "", "audio", "ba[ext=m4a]/ba/b", "m4a", aSize(128), "M4A", "128K"))
        opts.add(DlOption("128K", "", "audio", "ba/b", "mp3", aSize(128), "MP3", "128K"))
        opts.add(DlOption("256K", "", "audio", "ba/b", "mp3", aSize(256), "MP3", "256K"))
        opts.add(DlOption("320K", "", "audio", "ba/b", "mp3", aSize(320), "MP3", "320K"))

        return MediaInfo(
            url = j.optString("webpage_url", url).ifBlank { url },
            title = title,
            thumb = thumb,
            duration = duration,
            uploader = j.optString("uploader", "").ifBlank { null },
            site = site,
            options = opts
        )
    }
}
