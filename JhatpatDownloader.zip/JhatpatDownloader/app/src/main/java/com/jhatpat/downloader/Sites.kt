package com.jhatpat.downloader

import android.net.Uri

data class Site(val name: String, val url: String, val color: Int, val letter: String)
data class SiteGroup(val title: String, val sites: List<Site>)

object Sites {
    private fun s(n: String, u: String, c: Long, l: String) = Site(n, u, c.toInt(), l)

    val youtube = s("YouTube", "https://m.youtube.com", 0xFFFF0000, "▶")
    val whatsapp = s("WhatsApp", "https://web.whatsapp.com", 0xFF25D366, "W")
    val instagram = s("Instagram", "https://www.instagram.com", 0xFFE1306C, "IG")
    val facebook = s("Facebook", "https://m.facebook.com", 0xFF1877F2, "f")
    val google = s("Google", "https://www.google.com", 0xFF4285F4, "G")

    val top = listOf(youtube, whatsapp, instagram, facebook)

    /** 🔞 Chhupi hui list - sirf password + 18+ confirm + Restricted Mode band hone par */
    val adult = listOf(
        s("Pornhub", "https://www.pornhub.com", 0xFFFF9000, "PH"),
        s("XVideos", "https://www.xvideos.com", 0xFFDE2600, "X"),
        s("XNXX", "https://www.xnxx.com", 0xFF1F4BB4, "XN"),
        s("xHamster", "https://xhamster.com", 0xFFE34449, "xH"),
        s("RedTube", "https://www.redtube.com", 0xFFB71C1C, "RT"),
        s("YouPorn", "https://www.youporn.com", 0xFFE5185E, "YP"),
        s("SpankBang", "https://spankbang.com", 0xFFD81B60, "SB"),
        s("Eporner", "https://www.eporner.com", 0xFFC62828, "E"),
        s("Tube8", "https://www.tube8.com", 0xFF3949AB, "T8"),
        s("Thumbzilla", "https://www.thumbzilla.com", 0xFF2E7D32, "TZ"),
        s("TXXX", "https://txxx.com", 0xFF212121, "TX"),
        s("Beeg", "https://beeg.com", 0xFF8E24AA, "B"),
        s("HQporner", "https://hqporner.com", 0xFF00838F, "HQ"),
        s("Noodlemagazine", "https://noodlemagazine.com", 0xFFEF6C00, "N"),
        s("OK.XXX", "https://ok.xxx", 0xFF1565C0, "OK"),
        s("PornTrex", "https://www.porntrex.com", 0xFFAD1457, "PT")
    )

    val groups = listOf(
        SiteGroup("Video", listOf(
            youtube, google,
            s("Dailymotion", "https://www.dailymotion.com", 0xFF0066DC, "d"),
            s("Vimeo", "https://vimeo.com", 0xFF1AB7EA, "V"),
            s("TED", "https://www.ted.com", 0xFFE62B1E, "TED"),
            s("Twitch", "https://m.twitch.tv", 0xFF9146FF, "T"),
            s("Bilibili", "https://www.bilibili.tv", 0xFF00A1D6, "B"),
            s("Rumble", "https://rumble.com", 0xFF85C742, "R")
        )),
        SiteGroup("Social", listOf(
            instagram, facebook,
            s("X", "https://x.com", 0xFF333333, "X"),
            s("Threads", "https://www.threads.net", 0xFF101010, "@"),
            s("Snapchat", "https://www.snapchat.com/spotlight", 0xFFFFC107, "👻"),
            s("Pinterest", "https://in.pinterest.com", 0xFFE60023, "P"),
            s("Reddit", "https://www.reddit.com", 0xFFFF4500, "r"),
            s("Tumblr", "https://www.tumblr.com", 0xFF36465D, "t"),
            s("LinkedIn", "https://www.linkedin.com", 0xFF0A66C2, "in"),
            s("Telegram", "https://web.telegram.org", 0xFF229ED9, "✈"),
            whatsapp
        )),
        SiteGroup("Short Video", listOf(
            s("ShareChat", "https://sharechat.com", 0xFFFF6F00, "SC"),
            s("Moj", "https://mojapp.in", 0xFFFFB300, "M"),
            s("Josh", "https://share.myjosh.in", 0xFFE91E63, "J"),
            s("Chingari", "https://chingari.io", 0xFFFF5722, "C"),
            s("Snack Video", "https://www.snackvideo.com", 0xFFFFD600, "S"),
            s("Likee", "https://likee.video", 0xFFFF2D55, "L"),
            s("Kwai", "https://www.kwai.com", 0xFFFF7E00, "K"),
            s("Roposo", "https://www.roposo.com", 0xFF7C4DFF, "R")
        )),
        SiteGroup("Music", listOf(
            s("SoundCloud", "https://soundcloud.com", 0xFFFF5500, "☁"),
            s("Audiomack", "https://audiomack.com", 0xFFFFA200, "A"),
            s("Bandcamp", "https://bandcamp.com", 0xFF1DA0C3, "B"),
            s("Mixcloud", "https://www.mixcloud.com", 0xFF5000FF, "M"),
            s("JioSaavn", "https://www.jiosaavn.com", 0xFF2BC5B4, "JS")
        )),
        SiteGroup("Entertainment & News", listOf(
            s("9GAG", "https://9gag.com", 0xFF000000, "9"),
            s("IMDb", "https://m.imdb.com", 0xFFF5C518, "IMDb"),
            s("Aaj Tak", "https://www.aajtak.in/videos", 0xFFD32F2F, "AT"),
            s("NDTV", "https://www.ndtv.com/video", 0xFFE53935, "N"),
            s("ABP News", "https://www.abplive.com/videos", 0xFFB71C1C, "abp"),
            s("BBC Hindi", "https://www.bbc.com/hindi", 0xFFBB1919, "BBC")
        ))
    )
}

/** Restricted Mode: adult websites rokna */
object Filter {
    private val adult = listOf(
        "pornhub", "xvideos", "xnxx", "xhamster", "redtube", "youporn", "spankbang", "eporner",
        "txxx", "thumbzilla", "tube8", "brazzers", "onlyfans", "chaturbate", "stripchat", "xvideosxtube",
        "porn", "xxx", "sex.com", "beeg", "noodlemagazine", "hqporner", "hentai", "desi49", "desixnxx", "fsiblog", "antarvasna"
    )

    fun isAdult(url: String?): Boolean {
        if (url.isNullOrBlank()) return false
        val host = try { Uri.parse(url).host?.lowercase() ?: "" } catch (e: Exception) { "" }
        return adult.any { host.contains(it) }
    }

    fun blocked(url: String?): Boolean =
        (Prefs.filterSites || Prefs.filterBrowsing) && isAdult(url)
}
