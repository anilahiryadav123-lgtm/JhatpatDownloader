package com.jhatpat.downloader

import android.Manifest
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.PopupMenu
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButtonToggleGroup

data class Site(val name: String, val url: String, val color: Int, val letter: String)

class MainActivity : AppCompatActivity() {

    private lateinit var pageHome: View
    private lateinit var pageDownloads: View
    private lateinit var pageMe: View
    private lateinit var nav: BottomNavigationView
    private lateinit var dlAdapter: DlAdapter
    private lateinit var tvEmpty: TextView
    private var showDone = false
    private val listener: () -> Unit = { refreshDownloads() }

    private val sites = listOf(
        Site("YouTube", "https://m.youtube.com", 0xFFFF0000.toInt(), "▶"),
        Site("Google", "https://www.google.com", 0xFF4285F4.toInt(), "G"),
        Site("Instagram", "https://www.instagram.com", 0xFFE1306C.toInt(), "IG"),
        Site("Facebook", "https://m.facebook.com", 0xFF1877F2.toInt(), "f"),
        Site("X", "https://x.com", 0xFF333333.toInt(), "X"),
        Site("Dailymotion", "https://www.dailymotion.com", 0xFF0066DC.toInt(), "d"),
        Site("Vimeo", "https://vimeo.com", 0xFF1AB7EA.toInt(), "V"),
        Site("ShareChat", "https://sharechat.com", 0xFFFF6F00.toInt(), "SC"),
        Site("Moj", "https://mojapp.in", 0xFFFFB300.toInt(), "M"),
        Site("Pinterest", "https://in.pinterest.com", 0xFFE60023.toInt(), "P"),
        Site("Reddit", "https://www.reddit.com", 0xFFFF4500.toInt(), "R"),
        Site("SoundCloud", "https://soundcloud.com", 0xFFFF5500.toInt(), "☁"),
        Site("Twitch", "https://m.twitch.tv", 0xFF9146FF.toInt(), "T"),
        Site("TED", "https://www.ted.com", 0xFFE62B1E.toInt(), "TED"),
        Site("Bilibili", "https://www.bilibili.tv", 0xFF00A1D6.toInt(), "B"),
        Site("Telegram", "https://web.telegram.org", 0xFF229ED9.toInt(), "✈")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pageHome = findViewById(R.id.pageHome)
        pageDownloads = findViewById(R.id.pageDownloads)
        pageMe = findViewById(R.id.pageMe)
        nav = findViewById(R.id.bottomNav)

        nav.setOnItemSelectedListener {
            showPage(it.itemId); true
        }
        findViewById<View>(R.id.btnTopDownloads).setOnClickListener { nav.selectedItemId = R.id.nav_downloads }

        setupHome()
        setupDownloads()
        setupMe()
        askPermissions()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.getStringExtra("tab") == "downloads") nav.selectedItemId = R.id.nav_downloads
        if (i.action == Intent.ACTION_SEND) {
            val url = Util.findUrl(i.getStringExtra(Intent.EXTRA_TEXT))
            if (url != null) DownloadSheet(this).show(url, i.getStringExtra(Intent.EXTRA_SUBJECT))
            else Util.toast(this, "Link nahi mila")
            i.action = null
        }
    }

    private fun showPage(id: Int) {
        pageHome.visibility = if (id == R.id.nav_home) View.VISIBLE else View.GONE
        pageDownloads.visibility = if (id == R.id.nav_downloads) View.VISIBLE else View.GONE
        pageMe.visibility = if (id == R.id.nav_me) View.VISIBLE else View.GONE
        if (id == R.id.nav_downloads) refreshDownloads()
    }

    // ---------------- HOME ----------------
    private fun setupHome() {
        val et = findViewById<EditText>(R.id.etSearch)
        val go = {
            val q = et.text.toString().trim()
            if (q.isNotEmpty()) openBrowser(q)
        }
        findViewById<View>(R.id.btnGo).setOnClickListener { go() }
        et.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { go(); true } else false }

        findViewById<View>(R.id.btnPaste).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
            val url = Util.findUrl(text)
            if (url != null) DownloadSheet(this).show(url)
            else pasteDialog()
        }

        val rv = findViewById<RecyclerView>(R.id.rvSites)
        rv.layoutManager = GridLayoutManager(this, 4)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int) =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_site, p, false)) {}
            override fun getItemCount() = sites.size
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val s = sites[pos]
                val icon = h.itemView.findViewById<TextView>(R.id.tvIcon)
                icon.text = s.letter
                icon.textSize = if (s.letter.length > 2) 14f else 22f
                icon.background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(s.color)
                }
                h.itemView.findViewById<TextView>(R.id.tvName).text = s.name
                h.itemView.setOnClickListener { openBrowser(s.url) }
            }
        }
    }

    private fun pasteDialog() {
        val et = EditText(this)
        et.hint = "https://youtube.com/..."
        et.setPadding(48, 32, 48, 32)
        AlertDialog.Builder(this)
            .setTitle("Video link daalein")
            .setView(et)
            .setPositiveButton("Download") { _, _ ->
                val url = Util.findUrl(et.text.toString()) ?: et.text.toString().trim()
                if (url.isNotEmpty()) DownloadSheet(this).show(if (url.startsWith("http")) url else "https://$url")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    fun openBrowser(q: String) {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", q))
    }

    // ---------------- DOWNLOADS ----------------
    private fun setupDownloads() {
        tvEmpty = findViewById(R.id.tvEmpty)
        val rv = findViewById<RecyclerView>(R.id.rvDownloads)
        rv.layoutManager = LinearLayoutManager(this)
        dlAdapter = DlAdapter()
        rv.adapter = dlAdapter
        rv.itemAnimator = null
        findViewById<MaterialButtonToggleGroup>(R.id.toggleDl).addOnButtonCheckedListener { _, id, checked ->
            if (checked) { showDone = id == R.id.tabDone; refreshDownloads() }
        }
    }

    private fun refreshDownloads() {
        val list = if (showDone) DownloadRepo.done() else DownloadRepo.active()
        dlAdapter.items = list
        dlAdapter.notifyDataSetChanged()
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        val running = DownloadRepo.active().count { it.isActive }
        val badge = nav.getOrCreateBadge(R.id.nav_downloads)
        badge.isVisible = running > 0
        badge.number = running
    }

    override fun onResume() {
        super.onResume()
        DownloadRepo.addListener(listener)
        refreshDownloads()
    }

    override fun onPause() {
        super.onPause()
        DownloadRepo.removeListener(listener)
    }

    inner class DlAdapter : RecyclerView.Adapter<DlAdapter.VH>() {
        var items: List<DTask> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.ivThumb)
            val badge: TextView = v.findViewById(R.id.tvBadge)
            val title: TextView = v.findViewById(R.id.tvTitle)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val pb: ProgressBar = v.findViewById(R.id.pb)
            val a: ImageButton = v.findViewById(R.id.btnA)
            val b: ImageButton = v.findViewById(R.id.btnB)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_download, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            val ctx = this@MainActivity
            h.title.text = t.title
            h.badge.text = t.label
            if (h.thumb.tag != t.thumb) ImageLoader.load(t.thumb, h.thumb)
            h.pb.progress = t.progress.toInt()
            when (t.status) {
                DTask.RUNNING -> {
                    h.pb.visibility = View.VISIBLE
                    val total = DownloadService.sizeText[t.id] ?: Util.size(t.size)
                    val etaText = if (t.eta > 0) "  •  ${Util.duration(t.eta)} baaki" else ""
                    val totalText = if (total.isNotBlank()) "•  $total" else ""
                    h.meta.text = "${t.progress.toInt()}%  •  ${t.speed}  $totalText$etaText"
                    h.a.setImageResource(R.drawable.ic_pause)
                    h.a.setOnClickListener { DownloadService.pause(ctx, t.id) }
                }
                DTask.QUEUED -> {
                    h.pb.visibility = View.VISIBLE
                    h.meta.text = "Line me hai / shuru ho raha hai..."
                    h.a.setImageResource(R.drawable.ic_pause)
                    h.a.setOnClickListener { DownloadService.pause(ctx, t.id) }
                }
                DTask.PAUSED -> {
                    h.pb.visibility = View.VISIBLE
                    h.meta.text = "Ruka hua (${t.progress.toInt()}%) - Play dabayein"
                    h.a.setImageResource(R.drawable.ic_play)
                    h.a.setOnClickListener { DownloadService.resume(ctx, t.id) }
                }
                DTask.FAILED -> {
                    h.pb.visibility = View.GONE
                    h.meta.text = "❌ Fail: ${t.error ?: ""}"
                    h.a.setImageResource(R.drawable.ic_refresh)
                    h.a.setOnClickListener { DownloadService.resume(ctx, t.id) }
                }
                DTask.DONE -> {
                    h.pb.visibility = View.GONE
                    h.meta.text = "✓ ${Util.size(t.size)}  •  ${t.filePath?.substringBeforeLast('/')?.substringAfterLast('/') ?: ""}"
                    h.a.setImageResource(R.drawable.ic_play)
                    h.a.setOnClickListener { play(t) }
                }
            }
            h.itemView.setOnClickListener { if (t.status == DTask.DONE) play(t) }
            h.b.setOnClickListener { v -> menu(v, t) }
        }
    }

    private fun play(t: DTask) {
        startActivity(Intent(this, PlayerActivity::class.java)
            .putExtra("uri", t.fileUri).putExtra("title", t.title).putExtra("mime", t.mime))
    }

    private fun menu(v: View, t: DTask) {
        val pm = PopupMenu(this, v)
        if (t.status == DTask.DONE) {
            pm.menu.add(0, 1, 0, "Play")
            pm.menu.add(0, 2, 0, "Share")
            pm.menu.add(0, 3, 0, "Dusre app me kholein")
            pm.menu.add(0, 4, 0, "File delete karein")
            pm.menu.add(0, 5, 0, "List se hatayein")
        } else {
            pm.menu.add(0, 6, 0, "Cancel / Hatayein")
            pm.menu.add(0, 7, 0, "Link copy karein")
        }
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> play(t)
                2 -> Util.share(this, t)
                3 -> Util.openWith(this, t)
                4 -> AlertDialog.Builder(this).setTitle("Delete karein?").setMessage(t.title)
                    .setPositiveButton("Delete") { _, _ -> Util.deleteFile(this, t); DownloadRepo.remove(t.id) }
                    .setNegativeButton("Nahi", null).show()
                5 -> DownloadRepo.remove(t.id)
                6 -> DownloadService.cancel(this, t.id)
                7 -> {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(android.content.ClipData.newPlainText("url", t.url))
                    Util.toast(this, "Copied")
                }
            }
            true
        }
        pm.show()
    }

    // ---------------- ME ----------------
    private fun setupMe() {
        val prefs = getSharedPreferences("jp", MODE_PRIVATE)
        try {
            val vn = packageManager.getPackageInfo(packageName, 0).versionName
            findViewById<TextView>(R.id.tvVersion).text = "Version $vn"
        } catch (_: Exception) { }
        val tvEngine = findViewById<TextView>(R.id.tvEngine)
        findViewById<View>(R.id.btnUpdate).setOnClickListener {
            tvEngine.text = "Update ho raha hai... (1-2 min)"
            Thread {
                val ok = Engine.update(this)
                runOnUiThread { tvEngine.text = if (ok) "✓ ${Engine.lastUpdateMsg}" else Engine.lastUpdateMsg }
            }.start()
        }
        val rg = findViewById<RadioGroup>(R.id.rgParallel)
        rg.check(when (prefs.getInt("parallel", 2)) { 1 -> R.id.rp1; 3 -> R.id.rp3; else -> R.id.rp2 })
        rg.setOnCheckedChangeListener { _, id ->
            prefs.edit().putInt("parallel", when (id) { R.id.rp1 -> 1; R.id.rp3 -> 3; else -> 2 }).apply()
        }
        findViewById<View>(R.id.btnClear).setOnClickListener {
            android.webkit.WebStorage.getInstance().deleteAllData()
            android.webkit.CookieManager.getInstance().removeAllCookies(null)
            try { android.webkit.WebView(this).clearCache(true) } catch (_: Exception) { }
            Util.toast(this, "Saaf ho gaya")
        }
    }

    private fun askPermissions() {
        val need = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) need.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        if (need.isNotEmpty()) ActivityCompat.requestPermissions(this, need.toTypedArray(), 7)
    }
}
