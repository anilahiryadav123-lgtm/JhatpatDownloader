package com.jhatpat.downloader

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.appcompat.widget.PopupMenu
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.snackbar.Snackbar
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class MainActivity : BaseActivity() {

    private lateinit var pageHome: View
    private lateinit var pageDownloads: View
    private lateinit var pageMusic: View
    private lateinit var pageMe: View
    private lateinit var nav: BottomNavigationView
    private lateinit var dlAdapter: DlAdapter
    private lateinit var musicAdapter: DlAdapter
    private lateinit var tvEmpty: TextView
    private var showDone = false
    private var recent: List<DTask> = emptyList()
    private var ready = false
    private val main = Handler(Looper.getMainLooper())
    private val listener: () -> Unit = { refreshDownloads() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Prefs.onboarded) {
            startActivity(Intent(this, OnboardingActivity::class.java))
            finish()
            return
        }
        setContentView(R.layout.activity_main)
        ready = true
        pageHome = findViewById(R.id.pageHome)
        pageDownloads = findViewById(R.id.pageDownloads)
        pageMusic = findViewById(R.id.pageMusic)
        pageMe = findViewById(R.id.pageMe)
        nav = findViewById(R.id.bottomNav)
        nav.menu.findItem(R.id.nav_home).title = Lang.t("home")
        nav.menu.findItem(R.id.nav_downloads).title = Lang.t("downloads")
        nav.menu.findItem(R.id.nav_music).title = Lang.t("music")
        nav.menu.findItem(R.id.nav_me).title = Lang.t("me")
        nav.setOnItemSelectedListener { showPage(it.itemId); true }

        setupHome()
        applyHomeStyle()
        setupDownloads()
        setupMusic()
        setupMe()
        autoResume()

        if (savedInstanceState == null) {
            firstRunPermissions()
            handleIntent(intent)
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        if (ready) handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.getStringExtra("tab") == "downloads") nav.selectedItemId = R.id.nav_downloads
        when (i.getStringExtra("open")) {
            "youtube" -> openBrowser(Sites.youtube.url)
            "search" -> { nav.selectedItemId = R.id.nav_home; findViewById<View>(R.id.etSearch).requestFocus() }
            "paste" -> pasteAndDownload()
            "downloads" -> nav.selectedItemId = R.id.nav_downloads
            "sites" -> openSettings("sites")
        }
        i.removeExtra("open")
        if (i.action == Intent.ACTION_SEND) {
            val url = Util.findUrl(i.getStringExtra(Intent.EXTRA_TEXT))
            if (url != null) DownloadSheet(this).show(url, i.getStringExtra(Intent.EXTRA_SUBJECT))
            else Util.toast(this, "Link nahi mila")
            i.action = null
        }
    }

    private fun showPage(id: Int) {
        pageHome.visibility = if (id == R.id.nav_home) View.VISIBLE else View.GONE
        pageDownloads.visibility = if (id == R.id.nav_downloads) View.VISIBLE else View.GONE
        pageMusic.visibility = if (id == R.id.nav_music) View.VISIBLE else View.GONE
        pageMe.visibility = if (id == R.id.nav_me) View.VISIBLE else View.GONE
        if (id == R.id.nav_me) refreshMe()
        refreshDownloads()
    }

    // ---------------- Permissions (Vidmate jaisa) ----------------
    private fun firstRunPermissions() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 7)
        } else askStorage()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7) askStorage()
    }

    private fun askStorage() {
        if (!Prefs.askedStorage && !Util.hasAllFiles(this)) main.postDelayed({ StorageDialog.show(this) { } }, 400)
    }

    private fun autoResume() {
        val mode = Prefs.autoResume
        if (mode == "never" || (mode == "wifi" && !Util.isWifi(this))) return
        DownloadRepo.all().filter { it.interrupted }.forEach {
            it.interrupted = false
            DownloadService.resume(this, it.id)
        }
    }

    /** 5 alag home screen style */
    private fun applyHomeStyle() {
        val header = findViewById<LinearLayout>(R.id.homeHeader)
        val appName = findViewById<TextView>(R.id.tvAppName)
        val hello = findViewById<TextView>(R.id.tvHello)
        val heroBg = intArrayOf(R.drawable.hero1, R.drawable.hero2, R.drawable.hero3, R.drawable.hero4, R.drawable.hero5)
        val style = Prefs.homeStyle.coerceIn(1, 5)
        header.setBackgroundResource(heroBg[style - 1])
        // Style 2 = light header -> text dark
        val darkText = style == 2
        val tc = if (darkText) getColor(R.color.text) else 0xFFFFFFFF.toInt()
        appName.setTextColor(tc)
        hello.setTextColor(if (darkText) getColor(R.color.text2) else 0xE6FFFFFF.toInt())
        listOf(R.id.btnTopSites, R.id.btnTopDownloads).forEach {
            findViewById<ImageView>(it).imageTintList = android.content.res.ColorStateList.valueOf(tc)
        }
        // Thoda sa padding/elevation ka farq
        header.elevation = if (style == 1 || style == 4) dp(2).toFloat() else 0f

        // Bottom navigation ka design bhi badlo
        val navBg = intArrayOf(R.drawable.nav1, R.drawable.nav2, R.drawable.nav3, R.drawable.nav4, R.drawable.nav5)
        nav.setBackgroundResource(navBg[style - 1])
        val lp = nav.layoutParams as android.view.ViewGroup.MarginLayoutParams
        val side = if (style == 1 || style == 4) dp(12) else 0
        val bottom = if (style == 1 || style == 4) dp(8) else 0
        lp.setMargins(side, 0, side, bottom)
        nav.layoutParams = lp
        // Style 4 = gradient nav -> safed icons
        if (style == 4) {
            nav.itemIconTintList = getColorStateList(R.color.nav_tint_white)
            nav.itemTextColor = getColorStateList(R.color.nav_tint_white)
        } else {
            nav.itemIconTintList = getColorStateList(R.color.nav_tint)
            nav.itemTextColor = getColorStateList(R.color.nav_tint)
        }
        nav.elevation = if (style == 1 || style == 4) dp(6).toFloat() else dp(2).toFloat()
    }

    // ---------------- HOME ----------------
    private fun setupHome() {
        val et = findViewById<AutoCompleteTextView>(R.id.etSearch)
        val go = {
            val q = et.text.toString().trim()
            if (q.isNotEmpty()) { et.dismissDropDown(); openBrowser(q) }
        }
        findViewById<View>(R.id.btnGo).setOnClickListener { go() }
        et.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_GO) { go(); true } else false }
        setupSuggestions(et)
        et.setOnItemClickListener { p, _, pos, _ -> openBrowser(p.getItemAtPosition(pos).toString()) }

        findViewById<View>(R.id.btnPaste).setOnClickListener { pasteAndDownload() }
        findViewById<View>(R.id.btnTopDownloads).setOnClickListener { nav.selectedItemId = R.id.nav_downloads }
        findViewById<View>(R.id.btnTopSites).setOnClickListener { openSettings("sites") }
        findViewById<View>(R.id.btnAllSites).setOnClickListener { openSettings("sites") }

        // Upar ki line: YouTube, WhatsApp, Instagram, Facebook, Sites
        val top = findViewById<LinearLayout>(R.id.topSites)
        val topList = Sites.top + Site(Lang.t("sites"), "", 0, "")
        topList.forEach { s ->
            val cell = layoutInflater.inflate(R.layout.item_site, top, false)
            if (s.url.isEmpty()) {
                val icon = cell.findViewById<TextView>(R.id.tvIcon)
                icon.text = "⋯"
                icon.setTextColor(attrColor(R.attr.jpAccent2))
                icon.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(getColor(R.color.surface2)) }
                cell.findViewById<TextView>(R.id.tvName).text = s.name
                cell.setOnClickListener { openSettings("sites") }
            } else {
                SiteIcon.bind(cell, s)
                cell.setOnClickListener { openBrowser(s.url) }
            }
            top.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
        }

        findViewById<View>(R.id.btnRecentAll).setOnClickListener { startActivity(Intent(this, MyFilesActivity::class.java)) }
        val rvRecent = findViewById<RecyclerView>(R.id.rvRecent)
        rvRecent.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        rvRecent.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_recent, p, false)) {}
            override fun getItemCount() = recent.size
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val t = recent[pos]
                val iv = h.itemView.findViewById<ImageView>(R.id.ivThumb)
                if (iv.tag != t.thumb) ImageLoader.load(t.thumb, iv)
                h.itemView.findViewById<TextView>(R.id.tvTitle).text = t.title
                h.itemView.findViewById<TextView>(R.id.tvBadge).text = t.label
                h.itemView.setOnClickListener { Util.play(this@MainActivity, t) }
            }
        }

        val popular = Sites.groups.flatMap { it.sites }.distinctBy { it.name }.filter { it !in Sites.top }.take(12)
        val rv = findViewById<RecyclerView>(R.id.rvSites)
        rv.layoutManager = GridLayoutManager(this, 4)
        rv.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_site, p, false)) {}
            override fun getItemCount() = popular.size
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val s = popular[pos]
                SiteIcon.bind(h.itemView, s)
                h.itemView.setOnClickListener { openBrowser(s.url) }
            }
        }
    }

    /** Quick Search: Google suggestions */
    private fun setupSuggestions(et: AutoCompleteTextView) {
        val adapter = ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, ArrayList())
        et.setAdapter(adapter)
        var pending: Runnable? = null
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val q = s?.toString()?.trim() ?: ""
                pending?.let { main.removeCallbacks(it) }
                if (!Prefs.quickSearch || q.length < 2 || Util.isUrl(q)) return
                val r = Runnable {
                    Thread {
                        try {
                            val safe = if (Prefs.filterSearch) "&safe=active" else ""
                            val u = URL("https://suggestqueries.google.com/complete/search?client=firefox&hl=${Prefs.lang}$safe&q=" + URLEncoder.encode(q, "UTF-8"))
                            val c = u.openConnection() as HttpURLConnection
                            c.connectTimeout = 5000; c.readTimeout = 5000
                            val body = c.inputStream.bufferedReader().use { it.readText() }
                            val arr = JSONArray(body).getJSONArray(1)
                            val list = (0 until arr.length()).map { arr.getString(it) }
                                .filter { !(Prefs.filterSearch && Filter.isAdult("https://$it")) }.take(8)
                            runOnUiThread {
                                if (et.text.toString().trim() == q && et.hasFocus()) {
                                    adapter.clear(); adapter.addAll(list); adapter.notifyDataSetChanged()
                                    if (list.isNotEmpty()) et.showDropDown()
                                }
                            }
                        } catch (_: Exception) { }
                    }.start()
                }
                pending = r
                main.postDelayed(r, 300)
            }
        })
    }

    private fun pasteAndDownload() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
        val url = Util.findUrl(text)
        if (url != null) DownloadSheet(this).show(url) else pasteDialog()
    }

    private fun pasteDialog() {
        val et = EditText(this)
        et.hint = "https://youtube.com/..."
        et.setPadding(dp(20), dp(14), dp(20), dp(14))
        AlertDialog.Builder(this)
            .setTitle(Lang.t("paste_dl"))
            .setView(et)
            .setPositiveButton(Lang.t("download")) { _, _ ->
                val url = Util.findUrl(et.text.toString()) ?: et.text.toString().trim()
                if (url.isNotEmpty()) DownloadSheet(this).show(if (url.startsWith("http")) url else "https://$url")
            }
            .setNegativeButton(Lang.t("cancel"), null)
            .show()
    }

    /** Copied Link Detection: link copy karke app kholo -> Download button */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (!hasFocus || !ready || !Prefs.clipDetect) return
        main.postDelayed({
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString()
                val url = Util.findUrl(text) ?: return@postDelayed
                if (url == Prefs.lastClip) return@postDelayed
                Prefs.lastClip = url
                Snackbar.make(findViewById<View>(R.id.bottomNav), "${Lang.t("copied_q")}\n$url", 6000)
                    .setAnchorView(R.id.bottomNav)
                    .setAction(Lang.t("download")) { DownloadSheet(this).show(url) }
                    .show()
            } catch (_: Exception) { }
        }, 300)
    }

    fun openBrowser(q: String) {
        startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", q))
    }

    private fun openSettings(page: String) {
        startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", page))
    }

    // ---------------- DOWNLOADS ----------------
    private fun setupDownloads() {
        tvEmpty = findViewById(R.id.tvEmpty)
        val rv = findViewById<RecyclerView>(R.id.rvDownloads)
        rv.layoutManager = LinearLayoutManager(this)
        dlAdapter = DlAdapter()
        rv.adapter = dlAdapter
        rv.itemAnimator = null
        findViewById<MaterialButtonToggleGroup>(R.id.toggleDl).addOnButtonCheckedListener { _, id, checked ->
            if (checked) { showDone = id == R.id.tabDone; refreshDownloads() }
        }
    }

    private val musicUrl = "https://m.youtube.com/channel/UC-9-kyTW8ZkZNDHQJ6FgpwQ"  // YouTube Music topic
    private val trending = listOf(
        Triple("Trending Songs", "Hindi top hits", "https://music.youtube.com/search?q=trending+songs+hindi"),
        Triple("Lofi & Chill", "Relax beats", "https://music.youtube.com/search?q=lofi+hindi"),
        Triple("Old is Gold", "90s classics", "https://music.youtube.com/search?q=90s+hindi+hits"),
        Triple("Punjabi Hits", "Latest 2026", "https://music.youtube.com/search?q=punjabi+songs"),
        Triple("Bhakti", "Devotional", "https://music.youtube.com/search?q=bhajan+aarti")
    )

    private fun setupMusic() {
        val rv = findViewById<RecyclerView>(R.id.rvMusic)
        rv.layoutManager = LinearLayoutManager(this)
        musicAdapter = DlAdapter()
        rv.adapter = musicAdapter
        rv.itemAnimator = null
        findViewById<View>(R.id.btnPlayAll).setOnClickListener {
            val list = audioList()
            if (list.isEmpty()) { openBrowser("https://music.youtube.com/"); return@setOnClickListener }
            startActivity(Intent(this, PlayerActivity::class.java)
                .putStringArrayListExtra("queue", ArrayList(list.map { it.id })))
        }
        findViewById<View>(R.id.btnMusicDownloads).setOnClickListener {
            startActivity(Intent(this, MyFilesActivity::class.java).putExtra("tab", 2))
        }
        val musicSearch = "https://music.youtube.com/search?q="
        findViewById<View>(R.id.btnMusicSearch).setOnClickListener { openBrowser(musicSearch + "songs") }
        findViewById<View>(R.id.btnBrowseMusic).setOnClickListener { openBrowser("https://music.youtube.com/") }

        // Chips: Music / New releases / Charts / Moods & genres
        val chips = findViewById<LinearLayout>(R.id.musicChips)
        val chipData = listOf(
            "Music" to musicSearch + "trending+songs",
            "New releases" to musicSearch + "new+song+2026",
            "Charts" to musicSearch + "top+50+songs+india",
            "Moods & genres" to musicSearch + "bollywood+party+songs"
        )
        chipData.forEachIndexed { i, (label, url) ->
            val chip = TextView(this).apply {
                text = label; textSize = 14f
                setTextColor(if (i == 0) 0xFFFFFFFF.toInt() else getColor(R.color.text))
                setPadding(dp(18), dp(9), dp(18), dp(9))
                background = GradientDrawable().apply {
                    cornerRadius = dp(20).toFloat()
                    if (i == 0) setColor(attrColor(R.attr.jpAccent2)) else { setColor(getColor(R.color.surface2)) }
                }
                setOnClickListener { openBrowser(url) }
            }
            val lp = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
            chips.addView(chip, lp)
        }

        // Trending list
        val rvt = findViewById<RecyclerView>(R.id.rvTrending)
        rvt.layoutManager = LinearLayoutManager(this)
        rvt.isNestedScrollingEnabled = false
        rvt.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder =
                object : RecyclerView.ViewHolder(LayoutInflater.from(p.context).inflate(R.layout.item_trend, p, false)) {}
            override fun getItemCount() = trending.size
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val (title, sub, url) = trending[pos]
                h.itemView.findViewById<TextView>(R.id.tvArt).text = title.take(1)
                h.itemView.findViewById<TextView>(R.id.tvTitle).text = title
                h.itemView.findViewById<TextView>(R.id.tvSub).text = sub
                h.itemView.setOnClickListener { openBrowser(url) }
            }
        }
    }

    private fun audioList() = DownloadRepo.done().filter { (it.mime ?: "").startsWith("audio/") || it.kind == "audio" }

    private fun refreshDownloads() {
        if (!ready) return
        val list = if (showDone) DownloadRepo.done() else DownloadRepo.active()
        dlAdapter.items = list
        dlAdapter.notifyDataSetChanged()
        tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        val music = audioList()
        musicAdapter.items = music
        musicAdapter.notifyDataSetChanged()
        findViewById<View>(R.id.tvMusicEmpty).visibility = if (music.isEmpty()) View.VISIBLE else View.GONE
        recent = DownloadRepo.done().take(10)
        findViewById<View>(R.id.boxRecent).visibility = if (recent.isEmpty()) View.GONE else View.VISIBLE
        findViewById<RecyclerView>(R.id.rvRecent).adapter?.notifyDataSetChanged()
        val name = Prefs.userName.substringBefore(' ')
        findViewById<TextView>(R.id.tvHello).text = if (name.isNotBlank()) "Namaste, $name 👋" else "Koi bhi video, jhatpat download ⚡"
        val running = DownloadRepo.all().count { it.isActive }
        val badge = nav.getOrCreateBadge(R.id.nav_downloads)
        badge.isVisible = running > 0
        badge.number = running
        val tc = findViewById<TextView>(R.id.tvTopCount)
        tc.visibility = if (running > 0) View.VISIBLE else View.GONE
        tc.text = running.toString()
    }

    override fun onResume() {
        super.onResume()
        if (!ready) return
        DownloadRepo.addListener(listener)
        applyHomeStyle()
        refreshDownloads()
        refreshMe()
    }

    override fun onPause() {
        super.onPause()
        DownloadRepo.removeListener(listener)
    }

    inner class DlAdapter : RecyclerView.Adapter<DlAdapter.VH>() {
        var items: List<DTask> = emptyList()

        inner class VH(v: View) : RecyclerView.ViewHolder(v) {
            val thumb: ImageView = v.findViewById(R.id.ivThumb)
            val badge: TextView = v.findViewById(R.id.tvBadge)
            val title: TextView = v.findViewById(R.id.tvTitle)
            val meta: TextView = v.findViewById(R.id.tvMeta)
            val pb: ProgressBar = v.findViewById(R.id.pb)
            val a: ImageButton = v.findViewById(R.id.btnA)
            val b: ImageButton = v.findViewById(R.id.btnB)
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            VH(LayoutInflater.from(p.context).inflate(R.layout.item_download, p, false))

        override fun getItemCount() = items.size

        override fun onBindViewHolder(h: VH, pos: Int) {
            val t = items[pos]
            val ctx = this@MainActivity
            h.title.text = t.title
            h.badge.text = t.label
            if (h.thumb.tag != t.thumb) ImageLoader.load(t.thumb, h.thumb)
            h.pb.progress = t.progress.toInt()
            when (t.status) {
                DTask.RUNNING -> {
                    h.pb.visibility = View.VISIBLE
                    val total = DownloadService.sizeText[t.id] ?: Util.size(t.size)
                    val etaText = if (t.eta > 0) "  •  ${Util.duration(t.eta)}" else ""
                    val totalText = if (total.isNotBlank()) "•  $total" else ""
                    h.meta.text = "${t.progress.toInt()}%  •  ${t.speed}  $totalText$etaText"
                    h.a.setImageResource(R.drawable.ic_pause)
                    h.a.setOnClickListener { DownloadService.pause(ctx, t.id) }
                }
                DTask.QUEUED -> {
                    h.pb.visibility = View.VISIBLE
                    h.meta.text = "⏳ ..."
                    h.a.setImageResource(R.drawable.ic_pause)
                    h.a.setOnClickListener { DownloadService.pause(ctx, t.id) }
                }
                DTask.PAUSED -> {
                    h.pb.visibility = View.VISIBLE
                    h.meta.text = "⏸ ${t.progress.toInt()}%" + (t.error?.let { "  •  $it" } ?: "")
                    h.a.setImageResource(R.drawable.ic_play)
                    h.a.setOnClickListener { DownloadService.resume(ctx, t.id) }
                }
                DTask.FAILED -> {
                    h.pb.visibility = View.GONE
                    h.meta.text = "❌ ${t.error ?: ""}"
                    h.a.setImageResource(R.drawable.ic_refresh)
                    h.a.setOnClickListener { DownloadService.resume(ctx, t.id) }
                }
                DTask.DONE -> {
                    h.pb.visibility = View.GONE
                    h.meta.text = "✓ ${Util.size(t.size)}  •  ${t.filePath?.substringBeforeLast('/')?.substringAfterLast('/') ?: ""}"
                    h.a.setImageResource(R.drawable.ic_play)
                    h.a.setOnClickListener { Util.play(ctx, t) }
                }
            }
            h.itemView.setOnClickListener { if (t.status == DTask.DONE) Util.play(ctx, t) }
            h.itemView.setOnLongClickListener {
                if (t.status == DTask.DONE) {
                    startActivity(Intent(ctx, MyFilesActivity::class.java).putExtra("select", t.id))
                    true
                } else false
            }
            h.b.setOnClickListener { v -> menu(v, t) }
        }
    }

    private fun menu(v: View, t: DTask) {
        val pm = PopupMenu(this, v)
        if (t.status == DTask.DONE) {
            pm.menu.add(0, 1, 0, "Play")
            pm.menu.add(0, 2, 0, Lang.t("share"))
            pm.menu.add(0, 3, 0, "Open with")
            pm.menu.add(0, 4, 0, Lang.t("delete"))
            pm.menu.add(0, 5, 0, "List se hatayein")
            pm.menu.add(0, 8, 0, "🔒 Hide / Select")
        } else {
            pm.menu.add(0, 6, 0, Lang.t("cancel"))
            pm.menu.add(0, 7, 0, "Copy link")
        }
        pm.setOnMenuItemClickListener {
            when (it.itemId) {
                1 -> Util.play(this, t)
                2 -> Util.share(this, t)
                3 -> Util.openWith(this, t)
                4 -> AlertDialog.Builder(this).setTitle("${Lang.t("delete")}?").setMessage(t.title)
                    .setPositiveButton(Lang.t("delete")) { _, _ -> Util.deleteFile(this, t); DownloadRepo.remove(t.id) }
                    .setNegativeButton(Lang.t("cancel"), null).show()
                5 -> DownloadRepo.remove(t.id)
                8 -> startActivity(Intent(this, MyFilesActivity::class.java).putExtra("select", t.id))
                6 -> DownloadService.cancel(this, t.id)
                7 -> {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    Prefs.lastClip = t.url
                    cm.setPrimaryClip(ClipData.newPlainText("url", t.url))
                    Util.toast(this, "Copied")
                }
            }
            true
        }
        pm.show()
    }

    // ---------------- ME (Vidmate jaisa) ----------------
    private fun meItem(parent: LinearLayout, icon: Int, label: String, big: Boolean, onClick: () -> Unit) {
        val cell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(10), 0, dp(10))
            val tv = android.util.TypedValue()
            theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
            setBackgroundResource(tv.resourceId)
            setOnClickListener { onClick() }
        }
        val iv = ImageView(this).apply {
            setImageResource(icon)
            imageTintList = android.content.res.ColorStateList.valueOf(
                if (big) attrColor(R.attr.jpAccent3) else getColor(R.color.text)
            )
        }
        val s = if (big) dp(36) else dp(30)
        cell.addView(iv, LinearLayout.LayoutParams(s, s))
        cell.addView(TextView(this).apply {
            text = label; textSize = if (big) 15f else 14f
            setTextColor(getColor(R.color.text)); gravity = Gravity.CENTER
            setPadding(dp(2), dp(8), dp(2), 0); maxLines = 1
        })
        parent.addView(cell, LinearLayout.LayoutParams(0, -2, 1f))
    }

    private fun setupMe() {
        findViewById<View>(R.id.btnSignIn).setOnClickListener { signInDialog() }
        findViewById<View>(R.id.boxProfile).setOnClickListener {
            val google = Prefs.googleSignedIn && Util.isGoogleSignedIn()
            if (google) {
                AlertDialog.Builder(this).setTitle("Google Account")
                    .setMessage("Aap YouTube/Google account se signed in hain. Ab HD video bina rok-tok download honge.")
                    .setPositiveButton(Lang.t("sign_out")) { _, _ -> Util.googleSignOut(this); refreshMe() }
                    .setNegativeButton(Lang.t("cancel"), null).show()
            } else {
                AlertDialog.Builder(this).setTitle(Prefs.userName).setMessage(Prefs.userContact)
                    .setPositiveButton(Lang.t("sign_out")) { _, _ -> Prefs.userName = ""; Prefs.userContact = ""; refreshMe() }
                    .setNeutralButton("Edit") { _, _ -> startActivity(Intent(this, SignInActivity::class.java)) }
                    .setNegativeButton(Lang.t("cancel"), null).show()
            }
        }
        findViewById<View>(R.id.btnDayNight).setOnClickListener {
            val night = Prefs.nightMode == 2 ||
                (Prefs.nightMode == -1 && (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) == android.content.res.Configuration.UI_MODE_NIGHT_YES)
            Prefs.nightMode = if (night) 1 else 2
            AppCompatDelegate.setDefaultNightMode(Prefs.nightMode)
        }

        val row1 = findViewById<LinearLayout>(R.id.meRow1)
        meItem(row1, R.drawable.ic_download, Lang.t("my_files"), true) {
            startActivity(Intent(this, MyFilesActivity::class.java))
        }
        meItem(row1, R.drawable.ic_history, Lang.t("history"), true) { openSettings("history") }
        meItem(row1, R.drawable.ic_bookmark, Lang.t("bookmarks"), true) { openSettings("bookmarks") }
        meItem(row1, R.drawable.ic_playlist, Lang.t("playlist"), true) { nav.selectedItemId = R.id.nav_music }

        val grid = findViewById<LinearLayout>(R.id.meGrid)
        val r1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val r2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        grid.addView(r1); grid.addView(r2)
        meItem(r1, R.drawable.ic_share, Lang.t("share"), false) { shareApp() }
        meItem(r1, R.drawable.ic_palette, Lang.t("theme"), false) { ThemePicker.show(this) }
        meItem(r1, R.drawable.ic_update, Lang.t("update"), false) { updateEngine() }
        meItem(r1, R.drawable.ic_feedback, Lang.t("feedback"), false) { feedback() }
        meItem(r2, R.drawable.ic_help, Lang.t("help"), false) {
            AlertDialog.Builder(this).setTitle(Lang.t("how_title")).setMessage(Lang.t("how_body"))
                .setPositiveButton(Lang.t("ok"), null).show()
        }
        meItem(r2, R.drawable.ic_settings, Lang.t("settings"), false) { openSettings("main") }
        meItem(r2, R.drawable.ic_clean, Lang.t("junk_clean"), false) { junkClean() }
        meItem(r2, R.drawable.ic_speed, Lang.t("boost"), false) { boost() }

        val vn = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        findViewById<TextView>(R.id.tvVersion).text = "Jhatpat Downloader v$vn\n${Lang.t("made_in_india")}  •  by Anil Yadav"
        refreshMe()
    }

    private fun signInDialog() {
        AlertDialog.Builder(this)
            .setTitle(Lang.t("sign_in"))
            .setItems(arrayOf("🔴  Sign in with Google (YouTube)", "👤  Quick sign in (naam se)")) { _, which ->
                if (which == 0) {
                    Prefs.googleSignedIn = true
                    Util.toast(this, "Google me login karein — phir back aayein")
                    startActivity(Intent(this, BrowserActivity::class.java)
                        .putExtra("q", "https://accounts.google.com/ServiceLogin?continue=https://m.youtube.com/"))
                } else startActivity(Intent(this, SignInActivity::class.java))
            }.show()
    }

    private fun refreshMe() {
        if (!ready) return
        val google = Prefs.googleSignedIn && Util.isGoogleSignedIn()
        val signed = Prefs.signedIn || google
        findViewById<View>(R.id.btnSignIn).visibility = if (signed) View.GONE else View.VISIBLE
        findViewById<View>(R.id.boxProfile).visibility = if (signed) View.VISIBLE else View.GONE
        findViewById<View>(R.id.spacer).visibility = if (signed) View.GONE else View.VISIBLE
        if (signed) {
            if (google && !Prefs.signedIn) {
                findViewById<TextView>(R.id.tvAvatar).text = "G"
                findViewById<TextView>(R.id.tvName).text = "Google Account"
                findViewById<TextView>(R.id.tvContact).text = "YouTube se signed in ✓"
            } else {
                findViewById<TextView>(R.id.tvAvatar).text = Prefs.userName.take(1).uppercase().ifBlank { "G" }
                findViewById<TextView>(R.id.tvName).text = Prefs.userName.ifBlank { "Google Account" }
                findViewById<TextView>(R.id.tvContact).text = if (google) "YouTube se signed in ✓" else Prefs.userContact
            }
        }
        val night = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
            android.content.res.Configuration.UI_MODE_NIGHT_YES
        val sun = findViewById<ImageView>(R.id.ivSun)
        val moon = findViewById<ImageView>(R.id.ivMoon)
        val on = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(if (night) 0xFF3A3A48.toInt() else 0xFFFFC400.toInt()) }
        sun.background = if (night) null else on
        moon.background = if (night) on else null
        sun.imageTintList = android.content.res.ColorStateList.valueOf(if (night) 0xFF8888AA.toInt() else 0xFFFFFFFF.toInt())
        moon.imageTintList = android.content.res.ColorStateList.valueOf(if (night) 0xFFFFE082.toInt() else 0xFFB0B0C8.toInt())
    }

    private fun shareApp() {
        AlertDialog.Builder(this)
            .setTitle("Share Jhatpat Downloader")
            .setItems(arrayOf("📦  Share App (APK file)", "🔗  Share Message")) { _, which ->
                if (which == 0) shareApk() else shareText()
            }.show()
    }

    private fun shareText() {
        val i = Intent(Intent.ACTION_SEND).setType("text/plain")
            .putExtra(Intent.EXTRA_TEXT, "⚡ Jhatpat Downloader se YouTube, Instagram, Facebook ke video aur MP3 jhatpat download karein!")
        startActivity(Intent.createChooser(i, Lang.t("share")))
    }

    /** VidMate jaisa: apni APK file dost ko bhejo (bina Play Store) */
    private fun shareApk() {
        try {
            val src = java.io.File(applicationInfo.sourceDir)
            val out = java.io.File(cacheDir, "JhatpatDownloader.apk")
            src.copyTo(out, overwrite = true)
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", out)
            val i = Intent(Intent.ACTION_SEND)
                .setType("application/vnd.android.package-archive")
                .putExtra(Intent.EXTRA_STREAM, uri)
                .putExtra(Intent.EXTRA_TEXT, "Jhatpat Downloader - video & MP3 downloader")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share APK via"))
        } catch (e: Exception) {
            Util.toast(this, "APK share nahi ho payi, Message se bhejein")
            shareText()
        }
    }

    private fun feedback() {
        val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:"))
            .putExtra(Intent.EXTRA_SUBJECT, "Jhatpat Downloader Feedback")
        try { startActivity(i) } catch (_: Exception) { Util.toast(this, "Email app nahi mila") }
    }

    private fun updateEngine() {
        val d = AlertDialog.Builder(this).setTitle(Lang.t("update"))
            .setMessage("Checking for updates...").setCancelable(false).show()
        Thread {
            val ok = Engine.update(this)
            runOnUiThread {
                d.dismiss()
                val msg = if (ok) "✓ Jhatpat Downloader is up to date.\nDownload engine refreshed successfully."
                          else "Could not check right now. Please try again later."
                AlertDialog.Builder(this).setTitle(Lang.t("update"))
                    .setMessage(msg)
                    .setPositiveButton(Lang.t("ok"), null).show()
            }
        }.start()
    }

    private fun junkClean() {
        startActivity(Intent(this, JunkActivity::class.java))
    }

    private fun boost() {
        startActivity(Intent(this, BoostActivity::class.java))
    }
}
