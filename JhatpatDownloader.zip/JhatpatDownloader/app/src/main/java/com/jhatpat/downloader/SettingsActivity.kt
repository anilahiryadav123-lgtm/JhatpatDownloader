package com.jhatpat.downloader

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import java.io.File

/**
 * Vidmate jaisi saari settings:
 * main, content, download, notifications, widgets, others, about, history, bookmarks, sites
 */
class SettingsActivity : BaseActivity() {

    private lateinit var box: LinearLayout
    private var page = "main"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        box = findViewById(R.id.box)
        page = intent.getStringExtra("page") ?: "main"
        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        build()
    }

    override fun onResume() {
        super.onResume()
        if (::box.isInitialized && (page == "download" || page == "history" || page == "bookmarks")) build()
    }

    private fun setHeader(t: String) { findViewById<TextView>(R.id.tvTitle).text = t }

    private fun build() {
        box.removeAllViews()
        findViewById<TextView>(R.id.btnAction).visibility = View.GONE
        when (page) {
            "content" -> content()
            "download" -> download()
            "notifications" -> notifications()
            "widgets" -> widgets()
            "others" -> others()
            "about" -> about()
            "history" -> links("history")
            "bookmarks" -> links("bookmarks")
            "sites" -> sites()
            "private_sites" -> privateSites()
            "adult" -> adult()
            else -> main()
        }
    }

    // ---------------- Pages ----------------
    private fun main() {
        setHeader(Lang.t("settings"))
        gap()
        row(R.drawable.ic_globe, Lang.t("content"), Lang.t("content_d")) { openPage("content") }
        row(R.drawable.ic_download, Lang.t("download_s"), Lang.t("download_d")) { openPage("download") }
        row(R.drawable.ic_bell, Lang.t("notifications"), Lang.t("notifications_d")) { openPage("notifications") }
        row(R.drawable.ic_widgets, Lang.t("widgets"), Lang.t("widgets_d")) { openPage("widgets") }
        row(R.drawable.ic_settings, Lang.t("others"), Lang.t("others_d")) { openPage("others") }
        gap()
        row(R.drawable.ic_info, Lang.t("about"), null) { openPage("about") }
    }

    private fun content() {
        setHeader(Lang.t("content"))
        gap()
        val cur = Lang.all.firstOrNull { it.code == Prefs.lang }?.native ?: "हिंदी"
        row(null, Lang.t("language"), null, cur) {
            choose(Lang.t("language"), Lang.all.map { it.code to "${it.native}  (${it.english})" }, Prefs.lang) {
                Prefs.lang = it; recreate()
            }
        }
        val locs = listOf("India", "Nepal", "Bangladesh", "Sri Lanka", "Pakistan", "UAE", "Saudi Arabia", "USA", "UK", "Other")
        row(null, Lang.t("location"), null, Prefs.location) {
            choose(Lang.t("location"), locs.map { it to it }, Prefs.location) { Prefs.location = it; build() }
        }
        header(Lang.t("restricted"))
        switchRow(Lang.t("f_rec"), Lang.t("f_rec_d"), Prefs.filterRecommend) { Prefs.filterRecommend = it }
        switchRow(Lang.t("f_browse"), Lang.t("f_browse_d"), Prefs.filterBrowsing) { Prefs.filterBrowsing = it }
        switchRow(Lang.t("f_search"), Lang.t("f_search_d"), Prefs.filterSearch) { Prefs.filterSearch = it }
        switchRow(Lang.t("f_sites"), Lang.t("f_sites_d"), Prefs.filterSites) { Prefs.filterSites = it }
        gap()
        row(R.drawable.ic_lock, "🔞 18+ Sites (Hidden)", "Password + 18+ confirm ke baad hi dikhengi") { openAdult() }
    }

    /** 18+ section kholne ka raasta: filter band -> 18+ confirm -> password */
    private fun openAdult() {
        if (Prefs.filterSites || Prefs.filterBrowsing) {
            AlertDialog.Builder(this)
                .setTitle("Restricted Mode chalu hai")
                .setMessage("18+ sites dekhne ke liye 'Sites Filter' aur 'Browsing Content Filter' band karne honge.")
                .setPositiveButton("Band karo") { _, _ ->
                    Prefs.filterSites = false; Prefs.filterBrowsing = false
                    build(); openAdult()
                }
                .setNegativeButton(Lang.t("cancel"), null).show()
            return
        }
        if (!Prefs.adultOk) {
            AlertDialog.Builder(this)
                .setTitle("🔞 Sirf 18+ ke liye")
                .setMessage("Is section me adult (18+) websites hain.\nKya aapki umar 18 saal ya usse zyada hai?")
                .setPositiveButton("Haan, main 18+ hoon") { _, _ -> Prefs.adultOk = true; openAdult() }
                .setNegativeButton("Nahi", null).show()
            return
        }
        val go = { openPage("adult") }
        if (Vault.unlocked) go()
        else if (Vault.hasPin) PinDialog(this, "check") { go() }.show()
        else PinDialog(this, "set") { go() }.show()
    }

    private fun adult() {
        setHeader("🔞 18+ Sites")
        if (!Vault.unlocked || !Prefs.adultOk || Prefs.filterSites || Prefs.filterBrowsing) {
            box.addView(text("🔒 Locked\nSettings → Content → 18+ Sites se kholein", 15f, false, R.color.text2).apply {
                gravity = Gravity.CENTER; setPadding(0, dp(80), 0, 0)
            })
            return
        }
        box.addView(text("Yeh list chhupi hui hai - Home ya Sites me nahi dikhegi.\nApp band karte hi phir se lock ho jaati hai.", 13f, false, R.color.text2).apply {
            setPadding(dp(18), dp(14), dp(18), dp(6))
        })
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        Sites.adult.forEach { s ->
            val cell = layoutInflater.inflate(R.layout.item_site, grid, false)
            SiteIcon.bind(cell, s)
            cell.setOnClickListener { startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", s.url)) }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(cell, lp)
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), 0, dp(8), 0) })
    }

    private fun download() {
        setHeader(Lang.t("download_s"))
        gap()
        row(null, Lang.t("dl_path"), Util.pathLabel(this), null) {
            choose(Lang.t("dl_path"), listOf(
                "jhatpat" to "Phone storage / JhatpatDownloader",
                "gallery" to "Gallery: Movies + Music / JhatpatDownloader",
                "download" to "Download / JhatpatDownloader"
            ), Prefs.pathMode) {
                if (it == "jhatpat" && !Util.hasAllFiles(this)) {
                    StorageDialog.show(this) { }
                }
                Prefs.pathMode = it; build()
            }
        }
        switchRow(Lang.t("wifi_only"), null, Prefs.wifiOnly) { Prefs.wifiOnly = it }
        row(null, Lang.t("max_tasks"), null, Prefs.maxTasks.toString()) {
            choose(Lang.t("max_tasks"), (1..5).map { it.toString() to it.toString() }, Prefs.maxTasks.toString()) {
                Prefs.maxTasks = it.toInt(); build()
            }
        }
        switchRow(Lang.t("fast_dl"), Lang.t("fast_dl_d"), Prefs.fastDownload) { Prefs.fastDownload = it }
        val resumeOpts = listOf("always" to Lang.t("always"), "wifi" to Lang.t("wifi"), "never" to Lang.t("never"))
        row(null, Lang.t("auto_resume"), null, resumeOpts.first { it.first == Prefs.autoResume }.second) {
            choose(Lang.t("auto_resume"), resumeOpts, Prefs.autoResume) { Prefs.autoResume = it; build() }
        }
        val subOpts = listOf("off" to Lang.t("off"), "system" to Lang.t("system_lang"), "en" to "English", "hi" to "हिंदी")
        row(null, Lang.t("subtitle"), null, subOpts.first { it.first == Prefs.subtitle }.second) {
            choose(Lang.t("subtitle"), subOpts, Prefs.subtitle) { Prefs.subtitle = it; build() }
        }
        val mq = listOf("low" to "${Lang.t("low")} (128 kbps)", "medium" to "${Lang.t("medium")} (192 kbps)", "high" to "${Lang.t("high")} (320 kbps)")
        row(null, Lang.t("music_q"), null, mq.first { it.first == Prefs.musicQuality }.second.substringBefore(" (")) {
            choose(Lang.t("music_q"), mq, Prefs.musicQuality) { Prefs.musicQuality = it; build() }
        }
        gap()
        switchRow(Lang.t("clip_detect"), Lang.t("clip_detect_d"), Prefs.clipDetect) { Prefs.clipDetect = it }
        gap()
        switchRow(Lang.t("notify_done"), null, Prefs.notifyDone) { Prefs.notifyDone = it }
    }

    private fun notifications() {
        setHeader(Lang.t("notifications"))
        gap()
        switchRow(Lang.t("notify_progress"), null, Prefs.notifyProgress) { Prefs.notifyProgress = it }
        switchRow(Lang.t("notify_done"), null, Prefs.notifyDone) { Prefs.notifyDone = it }
        gap()
        row(R.drawable.ic_bell, "Android notification settings", null) {
            val i = Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            try { startActivity(i) } catch (_: Exception) { }
        }
    }

    private fun widgets() {
        setHeader(Lang.t("widgets"))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.card_bg)
            setPadding(dp(16), dp(16), dp(16), dp(16))
        }
        val lp = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(14), dp(14), dp(14), 0) }
        // Chhota preview
        val preview = layoutInflater.inflate(R.layout.widget_quick, card, false)
        card.addView(preview)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(text("Quick Actions", 19f, true, R.color.text))
        texts.addView(text("One-tap: YouTube, Search, Paste link, Downloads", 14f, false, R.color.text2))
        row.addView(texts, LinearLayout.LayoutParams(0, -2, 1f))
        val add = text(Lang.t("add"), 17f, true, R.color.white).apply {
            setBackgroundResource(R.drawable.grad_main)
            gravity = Gravity.CENTER
            setPadding(dp(26), dp(10), dp(26), dp(10))
            setOnClickListener { pinWidget() }
        }
        row.addView(add)
        card.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        box.addView(card, lp)
        box.addView(text("Widget ko home screen par lamba daba kar bhi add kar sakte hain (Widgets → Jhatpat Downloader).", 13f, false, R.color.text2).apply {
            setPadding(dp(18), dp(14), dp(18), 0)
        })
    }

    private fun pinWidget() {
        if (Build.VERSION.SDK_INT >= 26) {
            val m = getSystemService(AppWidgetManager::class.java)
            if (m != null && m.isRequestPinAppWidgetSupported) {
                m.requestPinAppWidget(ComponentName(this, QuickWidget::class.java), null, null)
                return
            }
        }
        Util.toast(this, "Home screen par lamba dabaein → Widgets → Jhatpat Downloader")
    }

    private fun others() {
        setHeader(Lang.t("others"))
        gap()
        row(R.drawable.ic_palette, Lang.t("theme_color"), null, Themes.current().name) { ThemePicker.show(this) }
        val homeNames = listOf("1" to "Gradient (default)", "2" to "Clean White", "3" to "Dark Fade", "4" to "Corner Glow", "5" to "Diagonal")
        row(R.drawable.ic_home, "Home & Navigation Style", "Home header + bottom bar ka design", homeNames.first { it.first == Prefs.homeStyle.toString() }.second) {
            choose("Home & Navigation Style", homeNames, Prefs.homeStyle.toString()) { Prefs.homeStyle = it.toInt(); build(); Util.toast(this, "Home par dekhein ✓") }
        }
        val nm = listOf("1" to "☀ Day", "2" to "🌙 Night", "-1" to "📱 System")
        row(R.drawable.ic_moon, Lang.t("dark_mode"), null, nm.first { it.first == Prefs.nightMode.toString() }.second) {
            choose(Lang.t("dark_mode"), nm, Prefs.nightMode.toString()) {
                Prefs.nightMode = it.toInt()
                AppCompatDelegate.setDefaultNightMode(it.toInt())
            }
        }
        gap()
        val players = listOf("jhatpat" to "Jhatpat Player", "other" to "Other app")
        row(null, Lang.t("play_video"), null, players.first { it.first == Prefs.playVideoWith }.second) {
            choose(Lang.t("play_video"), players, Prefs.playVideoWith) { Prefs.playVideoWith = it; build() }
        }
        row(null, Lang.t("play_audio"), null, players.first { it.first == Prefs.playAudioWith }.second) {
            choose(Lang.t("play_audio"), players, Prefs.playAudioWith) { Prefs.playAudioWith = it; build() }
        }
        switchRow(Lang.t("auto_play"), Lang.t("auto_play_d"), Prefs.autoPlay) { Prefs.autoPlay = it }
        switchRow(Lang.t("quick_search"), Lang.t("quick_search_d"), Prefs.quickSearch) { Prefs.quickSearch = it }
        gap()
        val br = if (Prefs.brightness < 0) "Auto" else "${Prefs.brightness}%"
        row(R.drawable.ic_brightness, Lang.t("brightness"), Lang.t("brightness_d"), br) { brightnessDialog() }
        gap()
        row(R.drawable.ic_update, "Update Downloader", "YouTube theek se chale iske liye") {
            Util.toast(this, "Update ho raha hai...")
            Thread {
                val ok = Engine.update(this)
                runOnUiThread { Util.toast(this, if (ok) "✓ Up to date" else "Try again later"); build() }
            }.start()
        }
        row(R.drawable.ic_lock, if (Vault.hasPin) "Change Private Password" else "Set Private Password", "Private folder ka 4 ank ka password") {
            if (Vault.hasPin) PinDialog(this, "check") { PinDialog(this, "set") { build() }.show() }.show()
            else PinDialog(this, "set") { build() }.show()
        }
        row(R.drawable.ic_clean, Lang.t("clear_cache"), null) {
            val freed = Util.cleanJunk(this)
            Util.toast(this, "${Lang.t("freed")}: ${Util.size(freed).ifBlank { "0 KB" }}")
        }
    }

    private fun brightnessDialog() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(10), dp(20), 0) }
        val slider = Slider(this).apply {
            valueFrom = 0f; valueTo = 100f; stepSize = 5f
            value = if (Prefs.brightness < 0) 60f else Prefs.brightness.toFloat().coerceIn(0f, 100f)
        }
        wrap.addView(slider)
        AlertDialog.Builder(this)
            .setTitle(Lang.t("brightness"))
            .setView(wrap)
            .setPositiveButton(Lang.t("ok")) { _, _ -> Prefs.brightness = slider.value.toInt().coerceAtLeast(5); build() }
            .setNeutralButton("Auto") { _, _ -> Prefs.brightness = -1; build() }
            .show()
    }

    private fun about() {
        setHeader(Lang.t("about"))
        val v = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(20), dp(30), dp(20), dp(20)) }
        val logo = ImageView(this).apply { setImageResource(R.drawable.logo) }
        v.addView(logo, LinearLayout.LayoutParams(dp(120), dp(120)))
        v.addView(text("Jhatpat Downloader", 22f, true, R.color.text).apply { setPadding(0, dp(12), 0, 0) })
        val vn = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "1.0" }
        v.addView(text("Version $vn", 14f, false, R.color.text2))
        v.addView(text("\n${Lang.t("made_in_india")}\nby Anil Yadav\n\nPowered by yt-dlp + FFmpeg (open source)\n\nSirf apne ya permission wale videos download karein.\nCopyright wala content bina ijazat share na karein.", 14f, false, R.color.text2).apply { gravity = Gravity.CENTER })
        box.addView(v)
    }

    private fun links(key: String) {
        setHeader(Lang.t(if (key == "history") "history" else "bookmarks"))
        val items = if (key == "history") Prefs.history() else Prefs.bookmarks()
        val act = findViewById<TextView>(R.id.btnAction)
        act.visibility = if (items.isEmpty()) View.GONE else View.VISIBLE
        act.text = "Clear"
        act.setOnClickListener {
            AlertDialog.Builder(this).setTitle("Sab hata dein?")
                .setPositiveButton(Lang.t("delete")) { _, _ -> Prefs.clear(key); build() }
                .setNegativeButton(Lang.t("cancel"), null).show()
        }
        if (items.isEmpty()) {
            box.addView(text(if (key == "history") "Abhi koi history nahi" else "Browser me ⋮ → Subscribe/Bookmark dabakar site save karein", 15f, false, R.color.text2).apply {
                gravity = Gravity.CENTER; setPadding(dp(30), dp(80), dp(30), 0)
            })
            return
        }
        gap()
        items.forEach { o ->
            val title = o.optString("title").ifBlank { o.optString("url") }
            val url = o.optString("url")
            val r = row(if (key == "history") R.drawable.ic_history else R.drawable.ic_bookmark, title, url) {
                startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", url))
            }
            r.setOnLongClickListener {
                Prefs.removeItem(key, url); build(); true
            }
        }
    }

    private fun sites() {
        setHeader(Lang.t("sites"))
        Sites.groups.forEach { g ->
            header(g.title)
            val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), 0, dp(8), dp(8)) }
            g.sites.forEach { s ->
                val cell = layoutInflater.inflate(R.layout.item_site, grid, false)
                SiteIcon.bind(cell, s)
                cell.setOnClickListener { startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", s.url)) }
                val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
                lp.width = 0
                grid.addView(cell, lp)
            }
            box.addView(grid, LinearLayout.LayoutParams(-1, -2))
        }
    }

    /** Password ke peeche apni sites */
    private fun privateSites() {
        setHeader("🔒 Private Sites")
        if (!Vault.unlocked) {
            box.addView(text("Password daal kar kholein", 15f, false, R.color.text2).apply { gravity = Gravity.CENTER; setPadding(0, dp(80), 0, 0) })
            if (Vault.hasPin) PinDialog(this, "check") { build() }.show() else PinDialog(this, "set") { build() }.show()
            return
        }
        val act = findViewById<TextView>(R.id.btnAction)
        act.visibility = View.VISIBLE
        act.text = "+ Add"
        act.setOnClickListener { addPrivateSite() }
        row(null, "🔞 18+ Sites", "Chhupi hui list kholein", null) { openAdult() }
        box.addView(text("Yahan apni pasand ki sites save karein - sirf password se dikhengi.\nKoi site na khule to Settings → Content → Restricted Mode filters band karein.", 13f, false, R.color.text2).apply {
            setPadding(dp(18), dp(14), dp(18), dp(6))
        })
        val list = Prefs.privateSites()
        if (list.isEmpty()) {
            box.addView(text("Abhi koi site nahi. Upar '+ Add' dabayein.", 15f, false, R.color.text2).apply { gravity = Gravity.CENTER; setPadding(0, dp(60), 0, 0) })
            return
        }
        val grid = GridLayout(this).apply { columnCount = 4; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        list.forEach { o ->
            val name = o.optString("title"); val url = o.optString("url")
            val cell = layoutInflater.inflate(R.layout.item_site, grid, false)
            SiteIcon.bind(cell, Site(name, url, 0xFF6D28D9.toInt(), name.take(1).uppercase()))
            cell.setOnClickListener { startActivity(Intent(this, BrowserActivity::class.java).putExtra("q", url)) }
            cell.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("$name hatayein?")
                    .setPositiveButton(Lang.t("delete")) { _, _ -> Prefs.removeItem("private_sites", url); build() }
                    .setNegativeButton(Lang.t("cancel"), null).show()
                true
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(cell, lp)
        }
        box.addView(grid, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addPrivateSite() {
        val wrap = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        val n = android.widget.EditText(this).apply { hint = "Naam" }
        val u = android.widget.EditText(this).apply { hint = "Website (example.com)"; inputType = android.text.InputType.TYPE_TEXT_VARIATION_URI }
        wrap.addView(n); wrap.addView(u)
        AlertDialog.Builder(this).setTitle("Private Site jodein").setView(wrap)
            .setPositiveButton(Lang.t("add")) { _, _ ->
                var url = u.text.toString().trim()
                if (url.isEmpty()) return@setPositiveButton
                if (!url.startsWith("http")) url = "https://$url"
                val name = n.text.toString().trim().ifBlank { Uri.parse(url).host ?: url }
                Prefs.addPrivateSite(name, url); build()
            }
            .setNegativeButton(Lang.t("cancel"), null).show()
    }

    override fun onDestroy() {
        if (page == "private_sites" || page == "adult") Vault.unlocked = false
        super.onDestroy()
    }

    // ---------------- Helpers ----------------
    private fun openPage(p: String) = startActivity(Intent(this, SettingsActivity::class.java).putExtra("page", p))

    private fun text(s: String, size: Float, bold: Boolean, color: Int) = TextView(this).apply {
        text = s; textSize = size
        setTextColor(getColor(color))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun gap() {
        box.addView(View(this), LinearLayout.LayoutParams(-1, dp(10)))
    }

    private fun header(t: String) {
        box.addView(text(t, 16f, true, R.color.text).apply { setPadding(dp(18), dp(20), dp(18), dp(8)) })
    }

    private fun baseRow(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setBackgroundColor(getColor(R.color.surface))
        minimumHeight = dp(64)
        setPadding(dp(18), dp(12), dp(16), dp(12))
        isClickable = true
        val tv = android.util.TypedValue()
        context.theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        foreground = context.getDrawable(tv.resourceId)
    }

    private fun texts(title: String, sub: String?): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        addView(text(title, 17f, false, R.color.text).apply { maxLines = 2 })
        if (!sub.isNullOrBlank()) addView(text(sub, 13.5f, false, R.color.text2).apply { maxLines = 3 })
    }

    private fun row(icon: Int?, title: String, sub: String?, value: String? = null, onClick: () -> Unit): View {
        val r = baseRow()
        if (icon != null) {
            val iv = ImageView(this).apply {
                setImageResource(icon)
                imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text))
            }
            r.addView(iv, LinearLayout.LayoutParams(dp(26), dp(26)).apply { marginEnd = dp(22) })
        }
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        if (value != null) r.addView(text(value, 14.5f, false, R.color.text2).apply { setPadding(dp(8), 0, 0, 0); maxLines = 1 })
        else if (icon != null) {
            val ch = ImageView(this).apply {
                setImageResource(R.drawable.ic_chevron)
                imageTintList = android.content.res.ColorStateList.valueOf(getColor(R.color.text2))
            }
            r.addView(ch, LinearLayout.LayoutParams(dp(20), dp(20)))
        }
        r.setOnClickListener { onClick() }
        box.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 1 })
        return r
    }

    private fun switchRow(title: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
        val r = baseRow()
        r.addView(texts(title, sub), LinearLayout.LayoutParams(0, -2, 1f))
        val sw = MaterialSwitch(this)
        sw.isChecked = checked
        sw.setOnCheckedChangeListener { _, b -> onChange(b) }
        r.addView(sw)
        r.setOnClickListener { sw.toggle() }
        box.addView(r, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 1 })
    }

    private fun choose(title: String, opts: List<Pair<String, String>>, current: String, onPick: (String) -> Unit) {
        val idx = opts.indexOfFirst { it.first == current }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setSingleChoiceItems(opts.map { it.second }.toTypedArray(), idx) { d, which ->
                d.dismiss(); onPick(opts[which].first)
            }
            .setNegativeButton(Lang.t("cancel"), null)
            .show()
    }
}

/** Site ka gol rangin icon */
object SiteIcon {
    fun bind(cell: View, s: Site) {
        val icon = cell.findViewById<TextView>(R.id.tvIcon)
        icon.text = s.letter
        icon.textSize = if (s.letter.length > 2) 13f else 22f
        icon.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(s.color)
        }
        cell.findViewById<TextView>(R.id.tvName).text = s.name
        // Asli website ka logo (favicon) - jaise browser dikhata hai
        val fav = cell.findViewById<ImageView>(R.id.ivFav)
        fav.visibility = View.INVISIBLE
        val host = try { Uri.parse(s.url).host } catch (e: Exception) { null }
        if (!host.isNullOrBlank()) {
            ImageLoader.load("https://www.google.com/s2/favicons?domain=$host&sz=128", fav, 0) {
                fav.visibility = View.VISIBLE
            }
        }
    }
}

/** Rang chunne wala dialog */
object ThemePicker {
    fun show(act: BaseActivity) {
        val grid = GridLayout(act).apply { columnCount = 5; setPadding(act.dp(16), act.dp(16), act.dp(16), act.dp(8)) }
        var dialog: AlertDialog? = null
        Themes.all.forEach { t ->
            val cell = LinearLayout(act).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(0, act.dp(6), 0, act.dp(6)) }
            val dot = TextView(act).apply {
                gravity = Gravity.CENTER
                text = if (t.key == Prefs.theme) "✓" else ""
                setTextColor(0xFFFFFFFF.toInt()); textSize = 20f
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(t.color) }
            }
            cell.addView(dot, LinearLayout.LayoutParams(act.dp(46), act.dp(46)))
            cell.addView(TextView(act).apply { text = t.name; textSize = 11f; gravity = Gravity.CENTER; setTextColor(act.getColor(R.color.text2)) })
            cell.setOnClickListener {
                Prefs.theme = t.key
                dialog?.dismiss()
                act.recreate()
            }
            val lp = GridLayout.LayoutParams(GridLayout.spec(GridLayout.UNDEFINED), GridLayout.spec(GridLayout.UNDEFINED, 1f))
            lp.width = 0
            grid.addView(cell, lp)
        }
        dialog = AlertDialog.Builder(act).setTitle(Lang.t("theme_color")).setView(grid).show()
    }
}
