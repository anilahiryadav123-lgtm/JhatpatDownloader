# Jhatpat Downloader — Authorized Media Server

Yeh server sirf un video/audio files ko list aur serve karta hai jo operator ne `server/media/` folder mein khud rakhi hain aur jinhe distribute karne ka adhikar uske paas hai. Yeh YouTube link extractor/proxy nahi hai aur YouTube ki restrictions ko bypass nahi karta.

## Local setup

1. Node.js 20+ install karein.
2. `server/.env.example` ko copy karke `.env` banayein.
3. `MEDIA_API_KEY` ko `openssl rand -hex 32` se bane secret se replace karein.
4. Authorized `.mp4`, `.webm`, `.mov`, `.mkv`, `.mp3` ya supported media files `server/media/` mein rakhein.
5. Server folder se run karein: `set -a; . ./.env; set +a; node server.js` (Linux/macOS shell).
6. HTTPS reverse proxy ke peeche deploy karein; API ko public internet par plain HTTP se expose na karein.

## API

- `GET /health` — health check.
- `GET /v1/media` — `Authorization: Bearer <MEDIA_API_KEY>` ke saath file list.
- `GET /v1/media/:id` — authenticated media download; HTTP Range/resume supported.

Files upload karne ka public endpoint jaanbujhkar nahi diya gaya. SSH/SFTP ya trusted hosting file manager se files add karein. Isse open-upload abuse aur arbitrary URL/SSRF risks kam hote hain.

## Android integration status

Yeh backend scaffold hai; is ZIP mein Android UI se server browse/download flow abhi wired nahi hai. Use connect karne ke liye deployed HTTPS base URL aur secret ko Android app mein securely configure karna hoga. API key ko public APK/source mein hard-code karna production ke liye secure nahi hai; per-user auth ya short-lived tokens use karein.
