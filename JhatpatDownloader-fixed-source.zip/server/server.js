'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const PORT = Number(process.env.PORT || 8080);
const API_KEY = process.env.MEDIA_API_KEY || '';
const MEDIA_DIR = path.resolve(process.env.MEDIA_DIR || path.join(__dirname, 'media'));
const ALLOWED_EXTENSIONS = new Set(['.mp4', '.m4v', '.webm', '.mov', '.mkv', '.mp3', '.m4a', '.aac', '.wav', '.ogg']);
const MIME = {
  '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime',
  '.mkv': 'video/x-matroska', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.aac': 'audio/aac',
  '.wav': 'audio/wav', '.ogg': 'audio/ogg'
};

function send(res, status, data) {
  const body = Buffer.from(JSON.stringify(data));
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': body.length, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}
function authorized(req) {
  if (!API_KEY) return false;
  const value = req.headers.authorization || '';
  const expected = `Bearer ${API_KEY}`;
  const a = Buffer.from(value); const b = Buffer.from(expected);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
function listMedia() {
  fs.mkdirSync(MEDIA_DIR, { recursive: true });
  return fs.readdirSync(MEDIA_DIR, { withFileTypes: true })
    .filter(entry => entry.isFile() && ALLOWED_EXTENSIONS.has(path.extname(entry.name).toLowerCase()))
    .map(entry => {
      const fullPath = path.join(MEDIA_DIR, entry.name);
      const stat = fs.statSync(fullPath);
      const id = crypto.createHash('sha256').update(entry.name).digest('hex').slice(0, 32);
      return { id, name: entry.name, bytes: stat.size, mimeType: MIME[path.extname(entry.name).toLowerCase()] || 'application/octet-stream' };
    });
}
function safeName(name) {
  return name.replace(/[\r\n"\\]/g, '_').replace(/[^\x20-\x7E]/g, '_').slice(0, 180) || 'media';
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') return send(res, 200, { ok: true, service: 'jhatpat-authorized-media-server' });
  if (!authorized(req)) return send(res, API_KEY ? 401 : 503, { error: API_KEY ? 'unauthorized' : 'server_not_configured' });
  if (req.method === 'GET' && url.pathname === '/v1/media') {
    try { return send(res, 200, { items: listMedia() }); }
    catch (_) { return send(res, 500, { error: 'media_index_failed' }); }
  }
  const match = url.pathname.match(/^\/v1\/media\/([a-f0-9]{32})$/);
  if (req.method === 'GET' && match) {
    let item;
    try { item = listMedia().find(candidate => candidate.id === match[1]); }
    catch (_) { return send(res, 500, { error: 'media_index_failed' }); }
    if (!item) return send(res, 404, { error: 'media_not_found' });
    const fullPath = path.resolve(MEDIA_DIR, item.name);
    if (path.dirname(fullPath) !== MEDIA_DIR) return send(res, 400, { error: 'invalid_path' });
    let stat;
    try { stat = fs.statSync(fullPath); } catch (_) { return send(res, 404, { error: 'media_not_found' }); }
    const headers = {
      'Content-Type': item.mimeType, 'Accept-Ranges': 'bytes', 'Cache-Control': 'private, no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Disposition': `attachment; filename="${safeName(item.name)}"`
    };
    const range = req.headers.range;
    if (range) {
      const parsed = /^bytes=(\d*)-(\d*)$/.exec(range);
      if (!parsed || (!parsed[1] && !parsed[2])) return send(res, 416, { error: 'invalid_range' });
      let start = parsed[1] ? Number(parsed[1]) : Math.max(0, stat.size - Number(parsed[2]));
      let end = parsed[2] && parsed[1] ? Number(parsed[2]) : stat.size - 1;
      if (start < 0 || end < start || start >= stat.size) {
        res.writeHead(416, { 'Content-Range': `bytes */${stat.size}` }); return res.end();
      }
      end = Math.min(end, stat.size - 1);
      headers['Content-Range'] = `bytes ${start}-${end}/${stat.size}`;
      headers['Content-Length'] = end - start + 1;
      res.writeHead(206, headers);
      return fs.createReadStream(fullPath, { start, end }).pipe(res);
    }
    headers['Content-Length'] = stat.size;
    res.writeHead(200, headers);
    return fs.createReadStream(fullPath).pipe(res);
  }
  return send(res, 404, { error: 'not_found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Jhatpat authorized media API listening on port ${PORT}`);
  if (!API_KEY) console.warn('WARNING: MEDIA_API_KEY is missing; protected endpoints are disabled.');
});
