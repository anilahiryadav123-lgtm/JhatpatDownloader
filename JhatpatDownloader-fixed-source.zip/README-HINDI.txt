JHATPAT DOWNLOADER - APK kaise banayein (sirf phone se, free)
=============================================================

1) github.com par login karein -> "+" -> New repository
   Naam: JhatpatDownloader  -> Public -> Create

2) "Add file" -> "Upload files" -> JhatpatDownloader.zip upload karein -> Commit

3) "Add file" -> "Create new file"
   Naam me likhein:   .github/workflows/build.yml
   Andar build.yml ka poora text paste karein -> Commit

4) "Actions" tab kholein -> build chalega (8-15 minute)
   Hara (green) tick aaye to -> repo ke "Releases" me jaayein
   - JhatpatDownloader-arm64.apk        -> naye phone (zyadatar yahi)
   - JhatpatDownloader-old-phones.apk   -> purane 32-bit phone

5) APK install karein ("Unknown apps" allow karein)

APP KAISE CHALAYEIN
- Home par YouTube / Google / Instagram... kholein
- Video chalayein -> laal "Download" button (neeche) ya video ke neeche
  "Jhatpat Download" button dabayein -> quality chunein (144p - 4K / MP3)
- YouTube app me: Share -> Jhatpat Downloader
- Link copy karke: Home -> "Link Paste karke Download"
- Files: Movies/JhatpatDownloader aur Music/JhatpatDownloader (Gallery me dikhengi)
- Pehli baar app kholne par engine set hone me 10-20 sec lagte hain.
- Agar source analysis fail ho, app ab fake 720p/1080p choices nahi dikhayega; asli available formats hi dikhayega.
- 720p/1080p tabhi milega jab source us quality ka downloadable format expose karta ho aur required audio/video streams merge ho sakein.

SERVER
- `server/README-HINDI.md` mein authorized media server ka setup diya hai.
- Server filhaal independent scaffold hai; Android app se server browsing/download integration abhi connect nahi hai.
- Server YouTube restrictions ko bypass nahi karta. Sirf apne ya permission wale media files host karein.

BUILD / SIGNING SECURITY
- Release signing ke liye trusted build environment mein `JHATPAT_KEYSTORE`, `JHATPAT_STORE_PASSWORD`, `JHATPAT_KEY_ALIAS`, `JHATPAT_KEY_PASSWORD` environment variables set karein.
- Keystore ya passwords ko GitHub repository/source ZIP mein commit na karein. Agar purani signing key pehle public ho chuki hai, use compromised samjhein aur signing-key migration ka plan banayein.

Note: App ka build is environment mein Android SDK/Gradle wrapper ke bina verify nahi ho saka.
