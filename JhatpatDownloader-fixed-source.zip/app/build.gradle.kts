plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jhatpat.downloader"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.jhatpat.downloader"
        minSdk = 24
        targetSdk = 34
        versionCode = 45
        versionName = "6.4"
    }

    // Keep signing secrets out of source control. Configure these environment variables
    // in a trusted build runner to sign release APKs with your existing private key.
    val releaseKeystorePath = System.getenv("JHATPAT_KEYSTORE")
    val releaseStorePassword = System.getenv("JHATPAT_STORE_PASSWORD")
    val releaseKeyAlias = System.getenv("JHATPAT_KEY_ALIAS")
    val releaseKeyPassword = System.getenv("JHATPAT_KEY_PASSWORD")
    if (!releaseKeystorePath.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
        !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
        signingConfigs {
            create("jhatpat") {
                storeFile = file(releaseKeystorePath)
                storePassword = releaseStorePassword
                keyAlias = releaseKeyAlias
                keyPassword = releaseKeyPassword
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            if (!releaseKeystorePath.isNullOrBlank() && !releaseStorePassword.isNullOrBlank() &&
                !releaseKeyAlias.isNullOrBlank() && !releaseKeyPassword.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("jhatpat")
            }
        }
        debug {
            // Android Gradle Plugin signs debug builds with its standard debug key.
        }
    }

    // Har phone ke liye alag chhota APK (arm64 = naye phone, armeabi-v7a = purane phone)
    splits {
        abi {
            isEnable = true
            reset()
            include("arm64-v8a", "armeabi-v7a")
            isUniversalApk = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")

    // Download engine (yt-dlp) + FFmpeg - YouTube aur 1000+ sites support
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
